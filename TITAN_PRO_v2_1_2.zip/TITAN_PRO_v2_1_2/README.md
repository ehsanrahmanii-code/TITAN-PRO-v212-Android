# TITAN PRO v2.1.0 — Glass Autopilot

موتور تصمیم **Central Governor** از خانواده TITAN PRO با رابط شیشه‌ای حرفه‌ای و گرافیکی.

نسخه ۱.۸.۰ = داشبورد شیشه‌ای نورانی + ۴۸ کندل آینده + زمان‌بندی کامل هر کندل + بازه اعتبار الگوها + داده فقط در YYY/

## چه چیزی واقعی است؟

| لایه | منبع |
|------|------|
| Central Governor (لبه، حاشیه، اعتماد، وتو، پشتیبانی، تضاد، R:R) | منطق PRO V84 + سخت‌سازی V84.3 |
| یادگیری سبک وزن‌ها | siglog outcomes → reliability tilt (بدون SQLite) |
| وزن‌های HTF/MTF/Structure/Pattern/DataTrust | PRO calibrated + adaptive |
| آستانه‌های نامتقارن SHORT | V84 edge_lab |
| UI شیشه‌ای حرفه‌ای + نوارهای نورانی + شماتیک | Glass-Pro terminal |
| شاخص‌ها، Grade، x10/x11/x12، SMC | یکپارچه با Governor |

## تصمیم‌گیری

فقط **Governor** اجازه انتشار LONG/SHORT می‌دهد:

1. شواهد چندتایم‌فریم (HTF قوی‌تر)
2. مومنتوم و ساختار + volume_flow / pattern / x_layer
3. derivatives + context
4. حداقل لبه / حاشیه / اعتماد (SHORT سخت‌گیرانه‌تر)
5. حداقل ۲ خانواده شواهد مستقل هم‌جهت + تضاد < ۶۲٪
6. R:R قابل قبول (≥ ۱.۰۸)
7. وتوی درجه پایین، نقدینگی، کیفیت x10، تعارض timing

## ویژگی‌های UI جدید

- هر کندل (گذشته و پیش‌بینی) با **تاریخ + ساعت کامل** در محور و کراس‌هیر
- **۴۸ کندل آینده** برای هر تایم‌فریم
- الگوها و پیش‌بینی دارای `valid_from` / `valid_until` / `valid_bars` / `range_label`
- نوارهای نورانی، نمادهای شماتیک، chip و meter گرافیکی
- تب‌بندی و زیربخش‌ها تمیزتر

## اجرا

```bash
pip install -r requirements.txt
python run.py
```

داده فقط در `YYY/` — کلید Gemini: `YYY/secret/gemini_api_key.txt`

## هشدار

سیگنال احتمالاتی است. قبل از پول واقعی حتماً فوروارد‌تست کاغذی بگیرید.


## v2.0 — Autopilot & learning
The paper exchange registers the best ideas automatically; every result is analysed (why it won/lost) and turned into rules so the same mistake is not repeated. See tab **معامله ▸ یادگیری از اشتباه** and **تحلیل ▸ روند**. Data: `postmortem.json` in the data folder.


## v2.1 — رابط یکپارچه، ثبت خودکار و یادگیری
- اجرا: `pip install -r requirements.txt && python run.py` → http://127.0.0.1:8080 (بدون اینترنت: `python tools/sim_server.py`)
- **ظاهر:** منوی «ظاهر» = استودیوی شخصی‌سازی (۲۱۵ گزینه، ۱۷ تم، چیدمان‌ساز). **یادگیری:** کالبدشکافی معاملات و قانون‌های جلوگیری از تکرار اشتباه. **تحلیل ارز ▸ روند:** وضعیت روند با اطمینان و دلیل.
- ثبت خودکار روی صرافی آزمایشی روشن است (از تب معاملات قابل خاموش‌شدن). داده‌ها فقط در پوشهٔ `YYY/`.
- تست‌ها: `python tests/test_core.py` · `python tests/static_check.py` · رابط (نیاز به playwright): `python tests/ui_smoke.py`
