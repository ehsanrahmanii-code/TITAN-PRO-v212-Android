"""Offline market simulator (no network): replaces app.data.market fetchers with deterministic synthetic data.
Used by tests and by `python tools/sim_server.py` to look at the dashboard without any exchange access."""
from __future__ import annotations
import time, zlib
import numpy as np
import pandas as pd

IV = {"1m": 60, "5m": 300, "15m": 900, "30m": 1800, "1h": 3600, "4h": 14400, "1d": 86400}
BASE = {"BTCUSDT": 98000, "ETHUSDT": 3400, "BNBUSDT": 640, "XRPUSDT": 2.4, "SOLUSDT": 190, "ADAUSDT": 0.9, "DOGEUSDT": 0.33, "SHIBUSDT": 0.000022, "PEPEUSDT": 0.000011}


def _seed(sym: str) -> int:
    return zlib.crc32(sym.encode()) & 0x7FFFFFFF


def klines(sym: str, iv: str, limit: int = 300) -> pd.DataFrame:
    sec = IV[iv]
    rng = np.random.default_rng(_seed(sym) + sec)
    n = max(limit, 300)
    base = BASE.get(sym, 5 + (_seed(sym) % 900) / 10)
    vol = 0.004 * (sec / 3600) ** 0.5 + 0.0015
    drift = ((_seed(sym) % 7) - 3) * 0.0006 * (sec / 3600) ** 0.5
    # regime switching drift so that patterns and trends appear
    reg = np.sign(np.sin(np.arange(n) / 37.0 + (_seed(sym) % 10))) * drift * 2
    r = rng.normal(0, vol, n) + reg
    c = base * np.exp(np.cumsum(r) - r.sum() * 0.0)
    o = np.r_[c[0] * (1 - r[0]), c[:-1]]
    h = np.maximum(o, c) * (1 + np.abs(rng.normal(0, vol / 2, n)))
    l = np.minimum(o, c) * (1 - np.abs(rng.normal(0, vol / 2, n)))
    now = int(time.time())
    t_last = now // sec * sec                         # open of the forming candle
    ot = pd.to_datetime([t_last - (n - 1 - i) * sec for i in range(n)], unit="s")
    v = rng.uniform(100, 200, n) * (1 + np.abs(r) * 60) * (base ** 0.3)
    return pd.DataFrame({"open_time": ot, "open": o, "high": h, "low": l, "close": c, "volume": v}).tail(limit).reset_index(drop=True)


def install() -> None:
    from app.data import market as m

    def fetch_klines(symbol, interval="1h", limit=300):
        df = klines(symbol.upper().replace("/", ""), interval, max(limit, 300))
        df.attrs["stale"] = False
        return df

    def _tk(sym):
        df = klines(sym, "1h", 300)
        px = float(df["close"].iloc[-1]); op = float(df["close"].iloc[-25])
        return {"symbol": sym, "price": px, "change_pct": round((px / op - 1) * 100, 3), "high": px * 1.03, "low": px * 0.97,
                "volume": 1e6, "quote_volume": 5e7 * (1 + (_seed(sym) % 9)), "source": "sim"}

    def fetch_tickers(symbols=None, max_age=None):
        syms = symbols or list(BASE)
        return {s: _tk(s) for s in syms}

    m.fetch_klines = fetch_klines
    m.fetch_tickers = fetch_tickers
    m.fetch_ticker = lambda s: _tk(s.upper().replace("/", ""))
    m.fetch_prices = lambda symbols=None: {k: v["price"] for k, v in fetch_tickers(symbols).items()}
    m.fetch_depth = lambda s, limit=10: {"ok": True, "spread_pct": 0.02, "bid_usd_1pct": 2.4e6, "ask_usd_1pct": 1.9e6, "imb_1pct": 0.12}
    m.fetch_derivs = lambda s: {"ok": True, "funding_apr": 18.0, "ls_buy": 0.55, "oi_chg_24h": 3.1, "oi_usd": 1.2e9, "basis_pct": 0.05}
    m.fetch_global = lambda: {"fng": 61, "fng_label": "Greed", "btc_dom": 56.1, "mcap_chg_24h": 1.2}
