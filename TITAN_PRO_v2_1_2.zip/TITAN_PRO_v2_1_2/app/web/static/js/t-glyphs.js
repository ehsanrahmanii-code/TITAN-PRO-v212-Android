/* TITAN · pattern pictograms: every candlestick / structural pattern gets a small schematic drawing. */
(function (W) {
  'use strict';
  const T = W.TT;
  // candles as [open, high, low, close] on a 0..100 price scale (higher = higher price)
  const CG = {
    doji: [[50, 74, 26, 51]], dragonfly: [[72, 74, 14, 71]], gravestone: [[26, 86, 24, 27]], longleg: [[50, 90, 10, 51]],
    hammer: [[34, 42, 6, 44]], hanging: [[62, 72, 34, 66]], invhammer: [[34, 76, 30, 40]], shooting: [[62, 94, 58, 56]],
    marubozu_bull: [[22, 80, 20, 80]], marubozu_bear: [[80, 82, 20, 22]], spinning: [[46, 72, 28, 54]],
    engulf_bull: [[58, 62, 38, 42], [36, 70, 32, 66]], engulf_bear: [[42, 66, 38, 58], [64, 70, 30, 34]],
    piercing: [[72, 74, 30, 34], [24, 62, 20, 58]], darkcloud: [[30, 74, 28, 70], [78, 80, 40, 44]],
    harami_bull: [[78, 80, 30, 32], [50, 58, 44, 54]], harami_bear: [[30, 80, 28, 76], [60, 66, 48, 52]],
    tweezer_bottom: [[70, 72, 24, 28], [28, 66, 24, 62]], tweezer_top: [[28, 78, 26, 74], [72, 78, 30, 34]],
    morning_star: [[82, 84, 40, 42], [34, 40, 26, 32], [38, 84, 36, 80]], evening_star: [[24, 70, 22, 66], [72, 80, 66, 74], [70, 72, 18, 22]],
    soldiers: [[20, 44, 18, 42], [40, 64, 38, 62], [60, 86, 58, 84]], crows: [[84, 86, 60, 62], [64, 66, 40, 42], [44, 46, 18, 20]],
    three_in_up: [[78, 80, 30, 32], [50, 62, 46, 58], [54, 88, 50, 84]], three_in_dn: [[30, 80, 28, 78], [60, 64, 46, 50], [56, 60, 14, 18]],
    inside: [[26, 86, 22, 78], [44, 60, 40, 56]], outside: [[50, 60, 40, 54], [38, 92, 8, 84]],
    rising3: [[20, 80, 18, 78], [66, 72, 56, 58], [60, 66, 50, 52], [54, 60, 44, 46], [48, 98, 46, 92]],
    falling3: [[80, 82, 20, 22], [34, 44, 28, 42], [40, 50, 34, 48], [46, 56, 40, 54], [52, 54, 2, 8]],
    absorb_bull: [[56, 62, 6, 60]], absorb_bear: [[46, 96, 40, 40]]
  };
  T.candleGlyph = function (k, size, bias) {
    const cs = CG[k] || [[40, 70, 30, 60]], s = size || 62, n = cs.length, step = s / (n + 0.6), cw = Math.min(14, step * 0.55);
    const y = v => s - 5 - v / 100 * (s - 10);
    let g = '';
    cs.forEach((c, i) => {
      const x = step * (i + 0.8), bull = c[3] >= c[0], col = bull ? T.col.bull : T.col.bear;
      g += `<line x1="${x}" x2="${x}" y1="${y(c[1])}" y2="${y(c[2])}" stroke="${col}" stroke-width="1.8" stroke-linecap="round"/>
        <rect x="${x - cw / 2}" y="${Math.min(y(c[0]), y(c[3]))}" width="${cw}" height="${Math.max(2.5, Math.abs(y(c[0]) - y(c[3])))}" rx="2.5" fill="${col}" fill-opacity=".85" style="filter:drop-shadow(0 0 5px ${col})"/>`;
    });
    return `<svg width="${s}" height="${s}" viewBox="0 0 ${s} ${s}">${g}</svg>`;
  };
  // structures: polyline price path + dashed neck/boundary lines + arrow of the expected move
  const SG = {
    double_top: { p: [[6, 70], [22, 16], [38, 52], [54, 16], [70, 74], [92, 90]], d: [[6, 52, 94, 52]], a: [78, 56, 90, 90] },
    double_bottom: { p: [[6, 30], [22, 84], [38, 48], [54, 84], [70, 26], [92, 10]], d: [[6, 48, 94, 48]], a: [78, 44, 90, 10] },
    hs: { p: [[4, 70], [16, 36], [26, 62], [40, 12], [54, 62], [64, 36], [76, 66], [94, 92]], d: [[4, 62, 94, 62]], a: [80, 66, 92, 92] },
    ihs: { p: [[4, 30], [16, 64], [26, 38], [40, 88], [54, 38], [64, 64], [76, 34], [94, 8]], d: [[4, 38, 94, 38]], a: [80, 34, 92, 8] },
    asc_tri: { p: [[6, 82], [20, 24], [32, 66], [48, 24], [58, 52], [74, 24]], d: [[6, 24, 92, 24], [6, 82, 80, 36]], a: [80, 26, 92, 6] },
    desc_tri: { p: [[6, 18], [20, 76], [32, 34], [48, 76], [58, 48], [74, 76]], d: [[6, 76, 92, 76], [6, 18, 80, 64]], a: [80, 74, 92, 94] },
    sym_tri: { p: [[6, 14], [20, 84], [34, 28], [48, 72], [60, 40], [72, 58]], d: [[6, 14, 90, 52], [6, 84, 90, 52]], a: [80, 54, 94, 30] },
    rising_wedge: { p: [[6, 86], [18, 62], [30, 74], [44, 44], [56, 58], [72, 32]], d: [[6, 76, 80, 24], [6, 92, 80, 46]], a: [78, 40, 92, 82] },
    falling_wedge: { p: [[6, 14], [18, 38], [30, 26], [44, 56], [56, 42], [72, 68]], d: [[6, 24, 80, 76], [6, 8, 80, 54]], a: [78, 62, 92, 18] },
    asc_channel: { p: [[6, 86], [20, 56], [32, 70], [48, 38], [60, 52], [78, 20]], d: [[6, 66, 90, 6], [6, 96, 90, 36]], a: null },
    desc_channel: { p: [[6, 14], [20, 44], [32, 30], [48, 62], [60, 48], [78, 80]], d: [[6, 4, 90, 64], [6, 34, 90, 94]], a: null },
    range: { p: [[6, 70], [20, 24], [34, 72], [48, 22], [62, 70], [78, 28]], d: [[6, 24, 94, 24], [6, 72, 94, 72]], a: null }
  };
  T.structGlyph = function (k, bias, size) {
    const g = SG[k]; if (!g) return '';
    const s = size || 70, col = bias > 0 ? T.col.bull : bias < 0 ? T.col.bear : T.col.warn, f = v => (v / 100 * (s - 10) + 5).toFixed(1);
    const path = g.p.map((p, i) => (i ? 'L' : 'M') + f(p[0]) + ' ' + f(100 - p[1])).join('');
    const dl = g.d.map(l => `<line x1="${f(l[0])}" y1="${f(100 - l[1])}" x2="${f(l[2])}" y2="${f(100 - l[3])}" stroke="${T.col.info}" stroke-width="1.4" stroke-dasharray="3 3" opacity=".9"/>`).join('');
    const ar = g.a ? `<line x1="${f(g.a[0])}" y1="${f(100 - g.a[1])}" x2="${f(g.a[2])}" y2="${f(100 - g.a[3])}" stroke="${col}" stroke-width="2.4" stroke-linecap="round" stroke-dasharray="1 5"/><circle cx="${f(g.a[2])}" cy="${f(100 - g.a[3])}" r="3.4" fill="${col}"/>` : '';
    return `<svg width="${s}" height="${s}" viewBox="0 0 ${s} ${s}">${dl}<path d="${path}" fill="none" stroke="${col}" stroke-width="2.2" stroke-linejoin="round" stroke-linecap="round" style="filter:drop-shadow(0 0 5px ${col})"/>${ar}</svg>`;
  };
})(window);
