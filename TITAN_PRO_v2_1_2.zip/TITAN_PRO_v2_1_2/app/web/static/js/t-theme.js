/* TITAN · Style Studio engine: ~150 options (colours, background, glass, neon/FX, type, layout, components, chart, logo)
   + 16 presets + layout composer (dashboard blocks, analysis tabs, navigation order) + export / import / randomise.
   Every option is stored server-side (YYY/settings.json → ui.st) and applied through CSS variables / <html data-*>. */
(function (W) {
  'use strict';
  const T = W.TT, S = T.S, esc = T.esc, R = document.documentElement;

  /* ── option builders ── */
  const G = [];            // groups
  let cg = null;
  const grp = (id, n, ic) => { cg = { id, n, ic, opts: [] }; G.push(cg); };
  const C = (k, n, d, v) => cg.opts.push({ k, n, t: 'color', d, v });
  const Rg = (k, n, min, max, step, d, v, u, m) => cg.opts.push({ k, n, t: 'range', min, max, step, d, v, u: u || '', m });
  const Sl = (k, n, d, ch, a, v) => cg.opts.push({ k, n, t: 'select', d, ch, a, v });
  const Sw = (k, n, d, a) => cg.opts.push({ k, n, t: 'switch', d, a });
  const Tx = (k, n, d) => cg.opts.push({ k, n, t: 'text', d });

  const FONTS = [['vazir', 'وزیرمتن / پیش‌فرض', '"Vazirmatn","IRANSans","Segoe UI",Tahoma,system-ui,-apple-system,sans-serif'], ['tahoma', 'تاهوما', 'Tahoma,"Segoe UI",system-ui,sans-serif'], ['system', 'سیستم', 'system-ui,-apple-system,"Segoe UI",Roboto,sans-serif'], ['mono', 'تک‌فاصله (ترمینال)', 'ui-monospace,"SF Mono",Menlo,Consolas,"Courier New",monospace'], ['serif', 'سریف', 'Georgia,"Times New Roman","Noto Naskh Arabic",serif'], ['rounded', 'گرد', '"Trebuchet MS","Segoe UI",Tahoma,sans-serif'], ['narrow', 'باریک', '"Arial Narrow","Segoe UI",Tahoma,sans-serif'], ['impact', 'درشت', 'Impact,"Arial Black",Tahoma,sans-serif']];

  grp('colors', 'رنگ‌ها', 'spark');
  C('bull', 'رنگ صعودی / خرید', '#35f2c1', '--bull'); C('bear', 'رنگ نزولی / فروش', '#ff5a86', '--bear'); C('warn', 'رنگ هشدار / انتظار', '#ffc861', '--warn');
  C('info', 'رنگ اطلاعات', '#62b0ff', '--info'); C('ai', 'رنگ هوش مصنوعی', '#a88bff', '--ai'); C('gold', 'رنگ طلایی', '#ffd98a', '--gold');
  C('acc', 'رنگ اصلی (دکمه‌ها و تب فعال)', '#35f2c1', '--acc'); C('acc2', 'رنگ دوم گرادیان', '#8dffe3', '--acc2'); C('onacc', 'رنگ متن روی رنگ اصلی', '#03221a', '--on-acc');
  C('ink', 'رنگ متن اصلی', '#e9efff', '--ink'); C('ink2', 'رنگ متن دوم', '#a9b6e0', '--ink2'); C('mut', 'رنگ متن کمرنگ', '#7482b3', '--mut');
  C('bg0', 'رنگ زمینهٔ اصلی', '#050918', '--bg0'); C('bg1', 'رنگ زمینهٔ دوم', '#0a1130', '--bg1'); C('deep', 'رنگ سطوح تیره (ورودی‌ها)', '#0b1230', '--deep'); C('deep2', 'رنگ سطوح روشن‌تر (دکمهٔ موبایل/پاپ‌آپ)', '#18235a', '--deep2');
  Sl('scheme', 'حالت روشن/تیره', 'auto', [['auto', 'خودکار'], ['dark', 'تیره'], ['light', 'روشن']], 'scheme');

  grp('bg', 'پس‌زمینه', 'layers');
  Sl('bgmode', 'نوع پس‌زمینه', 'aurora', [['aurora', 'شفق متحرک'], ['mesh', 'مش گرادیان'], ['gradient', 'گرادیان خطی'], ['grid', 'شبکهٔ فنی'], ['waves', 'موج'], ['solid', 'تخت'], ['image', 'تصویر (آدرس)']], 'bg');
  C('bgA', 'رنگ لکهٔ ۱', '#2f5bff', '--bgA'); C('bgB', 'رنگ لکهٔ ۲', '#00e0b0', '--bgB'); C('bgC', 'رنگ لکهٔ ۳', '#b13cff', '--bgC');
  Sl('blobs', 'نمایش لکه‌های نور', '1', [['1', 'روشن'], ['0', 'خاموش']], 'blobs'); Rg('blobblur', 'محوشدگی لکه‌ها', 20, 200, 5, 90, '--blobblur', 'px'); Rg('blobop', 'شدت لکه‌ها', 0, 100, 2, 34, '--blobop', '', v => v / 100);
  Sw('bganim', 'حرکت پس‌زمینه', true, 'bganim'); Rg('bgang', 'زاویهٔ گرادیان', 0, 360, 5, 160, '--bgang', 'deg');
  Sw('gridon', 'شبکهٔ زیر همهٔ حالت‌ها', false, 'gridon'); Rg('gridsz', 'اندازهٔ خانه‌های شبکه', 16, 120, 2, 42, '--gridsz', 'px'); Rg('gridop', 'شدت خطوط شبکه', 1, 30, 1, 6, '--gridop', '');
  Tx('imgurl', 'آدرس تصویر پس‌زمینه (https://… یا data:)', ''); Rg('imgdim', 'تیرگی روی تصویر', 0, 95, 5, 55, '--imgdim', '');
  Sw('grain', 'نویز فیلم (grain)', false, 'grain'); Rg('grainop', 'شدت نویز', 1, 30, 1, 7, '--grainop', '', v => v / 100);
  Sw('vig', 'تاریکی گوشه‌ها (vignette)', false, 'vig'); Rg('vigop', 'شدت vignette', 10, 95, 5, 50, '--vigop', '', v => v / 100);
  Sw('scan', 'خطوط اسکن CRT', false, 'scan'); Rg('scanop', 'شدت خطوط اسکن', 2, 50, 1, 16, '--scanop', '', v => v / 100);

  grp('glass', 'شیشه و سطوح', 'cube');
  Sl('glass', 'سبک کارت‌ها', 'frosted', [['frosted', 'شیشهٔ مات'], ['crystal', 'کریستال'], ['neon', 'نئونی'], ['matte', 'مات تیره'], ['outline', 'فقط خط دور'], ['solid', 'تخت'], ['paper', 'کاغذی (برای تم روشن)']], 'glass');
  Rg('blur', 'میزان تاری شیشه', 0, 60, 1, 24, '--blur', 'px'); Rg('sat', 'اشباع پشت شیشه', 50, 260, 5, 150, '--sat', '%');
  Rg('gop', 'غلظت شیشه', 0, 40, 1, 8.5, '--g1', '', v => `color-mix(in srgb,var(--wh) ${v}%,transparent)`);
  Rg('gop2', 'غلظت گرادیان شیشه (انتها)', 0, 30, 1, 2.8, '--g2', '', v => `color-mix(in srgb,var(--wh) ${v}%,transparent)`);
  Rg('gbord', 'شفافیت لبه', 0, 60, 1, 13, '--gl', '', v => `color-mix(in srgb,var(--wh) ${v}%,transparent)`);
  Rg('bw', 'ضخامت لبه', 0, 4, 0.5, 1, '--bw', 'px'); Rg('r1', 'گردی کارت‌ها', 0, 40, 1, 22, '--r1', 'px'); Rg('r2', 'گردی عناصر میانی', 0, 28, 1, 14, '--r2', 'px'); Rg('r3', 'گردی عناصر کوچک', 0, 20, 1, 9, '--r3', 'px'); Rg('rbtn', 'گردی دکمه‌ها', 0, 30, 1, 12, '--rbtn', 'px');
  Sw('shadow', 'سایهٔ کارت‌ها', true, 'shadow'); Sw('hl', 'برق لبهٔ بالا (highlight)', true, 'hl'); C('wh', 'رنگ سایهٔ شیشه (سفید در تیره)', '#ffffff', '--wh');

  grp('neon', 'نئون و افکت‌ها', 'bolt');
  Rg('glow', 'شدت درخشش نئون', 0, 3, 0.1, 1, '--glow', ''); Sw('ntext', 'درخشش متن عنوان‌ها و اعداد', false, 'ntext'); Sl('nborder', 'لبهٔ نئونی کارت‌ها', '0', [['0', 'خاموش'], ['1', 'ثابت'], ['2', 'چرخان (گرادیان)']], 'nborder');
  Sw('shine', 'برق عبوری روی کارت‌ها', false, 'shine'); Sw('pulse', 'نبض سیگنال‌های فعال', false, 'pulse'); Sw('flicker', 'سوسوی نئون (لوگو و عنوان)', false, 'flicker'); Sw('hlink', 'خط جداکنندهٔ گرادیانی', false, 'hlink');
  Sw('spot', 'نور دنبال‌کنندهٔ ماوس', false, 'spot'); Rg('spotsz', 'اندازهٔ نور ماوس', 120, 900, 20, 380, '--spotsz', 'px'); Rg('spotop', 'شدت نور ماوس', 2, 50, 1, 16, '--spotop', '');
  Sw('ripple', 'موج هنگام کلیک', false, null); Sw('tilt', 'کج‌شدن سه‌بعدی کارت ارزها', false, 'tilt'); Sw('lift', 'بالا آمدن کارت هنگام هاور', true, 'lift'); Sw('rise', 'انیمیشن ورود بخش‌ها', true, 'rise');
  Sl('fxmode', 'ذرات متحرک روی زمینه', 'none', [['none', 'هیچ'], ['particles', 'ذرات شناور'], ['net', 'شبکهٔ ذرات'], ['stars', 'ستاره'], ['matrix', 'باران ماتریکس'], ['snow', 'برف'], ['bubbles', 'حباب'], ['embers', 'جرقه']], null);
  Rg('fxcount', 'تعداد ذرات', 10, 300, 5, 70, null); Rg('fxspeed', 'سرعت ذرات', 0.1, 4, 0.1, 1, null); Rg('fxsize', 'اندازهٔ ذرات', 0.5, 6, 0.1, 1.6, null); Rg('fxop', 'شفافیت ذرات', 5, 100, 5, 60, null); C('fxcolor', 'رنگ ذرات', '#62b0ff', null);
  Rg('anim', 'سرعت همهٔ انیمیشن‌ها (کمتر = سریع‌تر)', 0.2, 4, 0.1, 1, '--anim', '');

  grp('type', 'فونت و متن', 'book');
  Sl('font', 'خانوادهٔ فونت', 'vazir', FONTS.map(f => [f[0], f[1]]), null); Rg('fs', 'اندازهٔ پایهٔ متن', 11, 20, 0.5, 14, '--fs', 'px'); Rg('lh', 'فاصلهٔ خطوط', 1.2, 2.4, 0.05, 1.7, '--lh', '');
  Rg('fw', 'ضخامت متن', 300, 700, 100, 400, '--fw', ''); Rg('ls', 'فاصلهٔ حروف', -1, 3, 0.1, 0, '--ls', 'px'); Rg('h1', 'اندازهٔ عنوان بالای صفحه', 12, 30, 1, 17, '--h1', 'px');
  Rg('pxs', 'اندازهٔ قیمت در کارت‌ها', 14, 32, 1, 19, '--pxs', 'px'); Rg('kpis', 'اندازهٔ عدد کارت‌های آمار', 14, 40, 1, 22, '--kpis', 'px'); Rg('smallsc', 'اندازهٔ متن‌های کوچک (درصد)', 80, 140, 5, 100, '--sscale', '%', v => v / 100);
  Sl('numfont', 'فونت اعداد', 'mono', [['mono', 'تک‌فاصله'], ['same', 'همان فونت متن']], 'numfont'); Sl('upper', 'حروف لاتین', 'normal', [['normal', 'عادی'], ['upper', 'بزرگ']], 'upper');

  grp('layout', 'چیدمان و ناوبری', 'grid');
  Sl('nav', 'جای منوی اصلی', 'rail-r', [['rail-r', 'ستون سمت راست'], ['rail-l', 'ستون سمت چپ'], ['top', 'نوار بالا'], ['float', 'شناور'], ['dock', 'داک پایین'], ['hidden', 'مخفی']], 'nav');
  Sl('navlab', 'برچسب منو', 'on', [['on', 'آیکون + نام'], ['off', 'فقط آیکون'], ['only', 'فقط نام']], 'navlab'); Sl('navsh', 'شکل دکمه‌های منو', 'round', [['round', 'گرد'], ['square', 'مربع'], ['circle', 'دایره'], ['pill', 'قرص']], 'navsh');
  Rg('rail', 'پهنای ستون منو', 60, 150, 2, 92, '--rail', 'px'); Sl('topbar', 'نوار بالای صفحه', 'glass', [['glass', 'شیشه‌ای'], ['solid', 'تخت'], ['clear', 'بی‌رنگ'], ['hidden', 'مخفی']], 'topbar');
  Sw('sticky', 'نوار بالا ثابت بماند', true, 'sticky'); Sw('clock', 'نمایش ساعت بالای صفحه', true, 'clock'); Sw('scanpill', 'نمایش وضعیت اسکن', true, 'scanpill'); Sw('sub', 'زیرنویس عنوان صفحه', true, 'sub');
  Rg('pad', 'حاشیهٔ صفحه', 4, 56, 2, 22, '--pad', 'px'); Rg('gap', 'فاصلهٔ بین کارت‌ها', 4, 36, 1, 14, '--gap', 'px'); Rg('maxw', 'حداکثر عرض محتوا (۰ = کامل)', 0, 2400, 50, 0, '--maxw', 'px', v => v ? v + 'px' : 'none');
  Rg('cardmin', 'حداقل عرض کارت‌های شبکه‌ای', 200, 560, 10, 330, '--cardmin', 'px'); Rg('dashcols', 'تعداد ستون‌های داشبورد', 1, 6, 1, 4, '--dashcols', '');
  Sl('dens', 'تراکم نمایش', 'cozy', [['compact', 'فشرده'], ['cozy', 'متعادل'], ['comfy', 'راحت']], 'dens');

  grp('comp', 'اجزا و کنترل‌ها', 'shapes');
  Sl('btn', 'سبک دکمه‌ها', 'gradient', [['gradient', 'گرادیان'], ['flat', 'تخت'], ['outline', 'خط‌دار'], ['neon', 'نئونی'], ['pill', 'قرصی'], ['sharp', 'تیز']], 'btn'); Sl('tabs', 'سبک تب‌ها', 'pill', [['pill', 'قرصی'], ['underline', 'زیرخط'], ['glow', 'درخشان'], ['block', 'بلوکی']], 'tabs');
  Sl('table', 'سبک جدول', 'rows', [['rows', 'ردیف‌های جدا'], ['lines', 'خطی'], ['zebra', 'راه‌راه'], ['compact', 'فشرده']], 'table'); Sl('heat', 'شکل سلول‌های نقشهٔ حرارتی', 'round', [['round', 'گرد'], ['square', 'مربع'], ['circle', 'دایره'], ['flat', 'تخت بدون سایه']], 'heat');
  Rg('hcell', 'ارتفاع سلول نقشهٔ حرارتی', 22, 80, 2, 40, '--hcell', 'px'); Rg('hgap', 'فاصلهٔ سلول‌های نقشه', 0, 16, 1, 6, '--hgap', 'px');
  Sl('bar', 'سبک نوارها', 'neon', [['neon', 'نئونی'], ['flat', 'تخت'], ['segments', 'قطعه‌قطعه'], ['thick', 'ضخیم']], 'bar'); Rg('barh', 'ضخامت نوارها', 3, 20, 1, 8, '--barh', 'px');
  Rg('icw', 'ضخامت خط آیکون‌ها', 1, 3.2, 0.1, 1.9, '--icw', ''); Sl('gstyle', 'سبک گیج‌های دایره‌ای', 'ring', [['ring', 'حلقه'], ['thin', 'باریک'], ['thick', 'ضخیم']], null); Rg('gsize', 'اندازهٔ گیج‌ها (٪)', 60, 160, 5, 100, null);
  Sl('side', 'سبک نشان خرید/فروش', 'solid', [['solid', 'توپر'], ['soft', 'ملایم'], ['outline', 'خط‌دار']], 'side'); Sl('coin', 'کارت ارزها', 'rich', [['rich', 'کامل'], ['compact', 'فشرده']], 'coin');
  Sw('tipon', 'راهنمای شناور (tooltip)', true, null);

  grp('chart', 'نمودار', 'candles');
  Sl('ch_style', 'نوع کندل', 'solid', [['solid', 'توپر'], ['hollow', 'توخالی'], ['bars', 'میله‌ای OHLC'], ['line', 'خطی'], ['area', 'ناحیه‌ای'], ['heikin', 'هایکین‌آشی']], null);
  C('ch_up', 'رنگ کندل صعودی (خالی = رنگ صعودی)', '', null); C('ch_dn', 'رنگ کندل نزولی (خالی = رنگ نزولی)', '', null);
  Rg('ch_wick', 'ضخامت سایه', 0.5, 4, 0.5, 1.5, null); Rg('ch_body', 'عرض بدنهٔ کندل (٪)', 30, 95, 5, 70, null); Rg('ch_glow', 'درخشش کندل‌ها', 0, 3, 0.5, 1, null);
  Sl('ch_grid', 'شبکهٔ نمودار', 'lines', [['lines', 'خطوط'], ['dots', 'نقطه‌ای'], ['none', 'هیچ']], null); Rg('ch_gridop', 'شدت شبکه', 0, 30, 1, 5.5, null);
  Rg('ch_h', 'ارتفاع نمودار', 280, 820, 10, 480, null); C('ch_ema1', 'رنگ EMA21', '#ffc861', null); C('ch_ema2', 'رنگ EMA50', '#a88bff', null); Rg('ch_lw', 'ضخامت خطوط (ضریب)', 0.5, 3, 0.1, 1, null);
  Sl('ch_cone', 'مخروط احتمال', 'fill', [['fill', 'پر'], ['lines', 'فقط خط'], ['glow', 'درخشان']], null); Sl('ch_fut', 'کندل‌های آینده', 'ghost', [['ghost', 'نیمه‌شفاف'], ['solid', 'توپر'], ['outline', 'خط‌دار']], null);
  Sl('ch_cross', 'نشانگر', 'full', [['full', 'خطوط کامل'], ['dot', 'نقطه‌ای'], ['off', 'خاموش']], null); Sw('ch_sr', 'سطوح حمایت/مقاومت خوشه‌ای', true, null); Sw('ch_srlab', 'برچسب سطوح', true, null);
  Sl('ch_bg', 'زمینهٔ نمودار', 'dark', [['dark', 'تیره'], ['clear', 'شفاف'], ['grad', 'گرادیان']], null); Sw('ch_last', 'خط قیمت آخر', true, null);

  grp('logo', 'لوگو و نام', 'crown');
  Sl('logomode', 'نوع لوگو', 'svg', [['svg', 'نمودار نئونی'], ['text', 'متن'], ['badge', 'نشان با حرف'], ['image', 'تصویر خودم'], ['none', 'بدون لوگو']], null);
  Tx('logotext', 'متن لوگو', 'TITAN'); Tx('logoletter', 'حرف نشان', 'T'); Tx('logoimg', 'تصویر لوگو (data/URL)', ''); Rg('logosz', 'اندازهٔ لوگو', 24, 80, 2, 44, '--logosz', 'px');
  C('logo1', 'رنگ ۱ لوگو', '#35f2c1', null); C('logo2', 'رنگ ۲ لوگو', '#62b0ff', null); Sw('logolab', 'نام زیر لوگو', true, null); Tx('title', 'عنوان سامانه (برای تب مرورگر)', 'TITAN PRO · GOV');

  grp('time', 'زمان و نمایش', 'clock');
  Sw('secs', 'نمایش ثانیه در ساعت', true, null); Sw('wday', 'نمایش نام روز هفته', true, null); Sw('pers', 'ارقام فارسی در برچسب‌ها', true, null); Sw('rel', 'نمایش «چند ساعت پیش/دیگر»', true, null);
  Sw('toastpos', 'اعلان‌ها در سمت چپ (خاموش = راست)', true, null); Rg('toastms', 'مدت نمایش اعلان (ثانیه)', 2, 12, 1, 4, null);

  /* ── presets ── */
  const P = (n, ic, o) => ({ n, ic, o });
  const PRESETS = {
    neon: P('نئون سایبر', 'bolt', {}),
    aurora: P('شفق شیشه‌ای', 'layers', { bg0: '#060b1f', bg1: '#0d1740', bgA: '#3a6bff', bgB: '#22e6c8', bgC: '#c24bff', acc: '#7aa8ff', acc2: '#b9d2ff', onacc: '#08122e', glass: 'crystal', blur: 34, glow: 1.2, bgmode: 'mesh', nborder: '0' }),
    synth: P('سینت‌ویو', 'wave', { bg0: '#12041f', bg1: '#220a3d', bull: '#3ef2ff', bear: '#ff3d9a', warn: '#ffd166', info: '#7aa2ff', ai: '#d28bff', acc: '#ff3d9a', acc2: '#ffa6d6', onacc: '#2a0018', bgA: '#ff2d95', bgB: '#2d6bff', bgC: '#a100ff', glass: 'neon', glow: 1.6, ntext: true, nborder: '2', scan: true, scanop: 10, fxmode: 'stars', bgmode: 'grid', gridon: true }),
    matrix: P('ماتریکس', 'cpu', { bg0: '#000a04', bg1: '#021a0c', ink: '#c8ffd9', ink2: '#7fd69b', mut: '#4a8a62', bull: '#2dff7a', bear: '#ff4b5c', warn: '#e8ff5a', info: '#38e8c6', ai: '#8bffb0', acc: '#2dff7a', acc2: '#a2ffc4', onacc: '#00210d', bgA: '#00a851', bgB: '#006b3c', bgC: '#00ff9d', glass: 'matte', font: 'mono', glow: 1.4, ntext: true, scan: true, fxmode: 'matrix', fxcolor: '#2dff7a', fxcount: 90, bgmode: 'solid', btn: 'sharp', r1: 6, r2: 4 }),
    crimson: P('شب سرخ', 'alert', { bg0: '#0d0305', bg1: '#220810', bull: '#4dffb0', bear: '#ff3b57', warn: '#ffb347', acc: '#ff3b57', acc2: '#ff9aa8', onacc: '#2a0008', bgA: '#ff2040', bgB: '#7a0b2a', bgC: '#ff6a00', glass: 'frosted', glow: 1.3, fxmode: 'embers', fxcolor: '#ff6a3d' }),
    ocean: P('اقیانوس', 'globe', { bg0: '#03121f', bg1: '#062a44', bull: '#35f2d0', bear: '#ff6f91', info: '#5ad1ff', acc: '#39c6ff', acc2: '#a8ecff', onacc: '#032033', bgA: '#0a6cff', bgB: '#00d1c1', bgC: '#5d8bff', bgmode: 'waves', fxmode: 'bubbles', fxcolor: '#7fdcff', glass: 'crystal' }),
    gold: P('طلای شب', 'crown', { bg0: '#0b0803', bg1: '#1d1507', ink: '#fff3d6', ink2: '#d9c395', mut: '#9c8553', bull: '#a6f27a', bear: '#ff6b5e', warn: '#ffd24d', acc: '#ffc83d', acc2: '#ffe9a6', onacc: '#271a00', bgA: '#ffb300', bgB: '#8a5a00', bgC: '#ff7a00', glass: 'frosted', glow: 1.1, fxmode: 'particles', fxcolor: '#ffd24d' }),
    ink: P('جوهر تک‌رنگ', 'ruler', { bg0: '#0a0a0c', bg1: '#141418', ink: '#f2f2f4', ink2: '#b5b5bd', mut: '#7a7a84', bull: '#d9d9e0', bear: '#8a8a96', warn: '#c9c9d2', info: '#e8e8ee', ai: '#bdbdc8', acc: '#f2f2f4', acc2: '#bdbdc8', onacc: '#0a0a0c', bgA: '#555', bgB: '#333', bgC: '#777', glass: 'matte', glow: 0.3, bgmode: 'solid', ch_up: '#f2f2f4', ch_dn: '#6a6a74', ch_style: 'hollow' }),
    pearl: P('مروارید (روشن)', 'eye', { scheme: 'light', bg0: '#eef2fb', bg1: '#dfe7f7', ink: '#14213d', ink2: '#3d4b6e', mut: '#6d7aa0', bull: '#0e9f6e', bear: '#d6336c', warn: '#c77d00', info: '#1d6fe0', ai: '#7048e8', gold: '#b8860b', acc: '#1d6fe0', acc2: '#6aa5ff', onacc: '#ffffff', deep: '#ffffff', deep2: '#dbe6ff', bgA: '#9ec1ff', bgB: '#a8f0dc', bgC: '#d6bcff', glass: 'paper', glow: 0.2, blobop: 55, wh: '#3a4a7a', gop: 5, gop2: 2, gbord: 12 }),
    sakura: P('ساکورا (روشن)', 'spark', { scheme: 'light', bg0: '#fff3f6', bg1: '#ffe3ec', ink: '#3b1d2b', ink2: '#6b4558', mut: '#9a7488', bull: '#0f9e74', bear: '#e0245e', warn: '#d98200', info: '#3b82f6', ai: '#a855f7', acc: '#e0245e', acc2: '#ff9ab8', onacc: '#ffffff', deep: '#ffffff', deep2: '#ffe3ec', bgA: '#ffb3c9', bgB: '#ffd9a8', bgC: '#e6b8ff', glass: 'paper', glow: 0.2, blobop: 60, wh: '#7a3a55', gop: 5, gop2: 2, gbord: 12 }),
    dusk: P('غروب بنفش', 'moon', { bg0: '#0c0820', bg1: '#1a1040', bull: '#58f5c9', bear: '#ff6aa2', acc: '#a88bff', acc2: '#d6c6ff', onacc: '#150a33', bgA: '#6a3dff', bgB: '#ff4fa0', bgC: '#2dd4ff', bgmode: 'mesh', glass: 'crystal', glow: 1.2 }),
    forest: P('جنگل', 'layers', { bg0: '#04100a', bg1: '#0a2216', bull: '#7dffb0', bear: '#ff7a6e', warn: '#e8d95a', acc: '#4fe08a', acc2: '#b4ffd0', onacc: '#03200f', bgA: '#12a150', bgB: '#0b5d3a', bgC: '#7cb518', fxmode: 'particles', fxcolor: '#9dffb8', glass: 'matte' }),
    ice: P('یخ قطبی', 'globe', { bg0: '#04101c', bg1: '#0a2540', bull: '#6ef5e0', bear: '#ff7ea1', acc: '#8fd4ff', acc2: '#e0f4ff', onacc: '#062033', bgA: '#5ab8ff', bgB: '#b3ecff', bgC: '#7aa2ff', fxmode: 'snow', fxcolor: '#ffffff', glass: 'crystal', blur: 40 }),
    holo: P('هولوگرام', 'cube', { bg0: '#050612', bg1: '#0c0f2a', bull: '#52ffd6', bear: '#ff5cae', acc: '#52ffd6', acc2: '#a58bff', onacc: '#04141a', bgA: '#00f0ff', bgB: '#ff00c8', bgC: '#7a00ff', glass: 'crystal', nborder: '2', shine: true, ntext: true, glow: 1.5, fxmode: 'net', fxcolor: '#7fe9ff' }),
    amber: P('ترمینال کهربایی', 'cpu', { bg0: '#0a0600', bg1: '#1c1000', ink: '#ffd9a0', ink2: '#d49a50', mut: '#8a6430', bull: '#ffb020', bear: '#ff5a3c', warn: '#ffe14d', info: '#ffc266', ai: '#ff9f5a', acc: '#ffb020', acc2: '#ffd98a', onacc: '#241500', bgA: '#ff9500', bgB: '#7a3d00', bgC: '#ffcc00', glass: 'matte', font: 'mono', scan: true, grain: true, vig: true, btn: 'sharp', glow: 1.2, bgmode: 'solid', r1: 4, r2: 3 }),
    blood: P('ماه خونین', 'moon', { bg0: '#080204', bg1: '#1a050c', bull: '#c3ffd4', bear: '#ff2b4a', acc: '#ff2b4a', acc2: '#ff8ea0', onacc: '#210006', bgA: '#b0001d', bgB: '#400010', bgC: '#ff4d00', glass: 'neon', glow: 1.7, nborder: '1', vig: true, vigop: 70, flicker: true, scan: true, scanop: 8 }),
    minimal: P('ساده و سبک', 'ruler', { bgmode: 'solid', glass: 'solid', glow: 0, blur: 0, nborder: '0', shadow: false, hl: false, rise: false, anim: 0.4, fxmode: 'none', btn: 'flat', bar: 'flat', heat: 'flat', r1: 12, r2: 8, rbtn: 8 }),
  };

  /* ── state ── */
  const DEFS = {}; let TOTAL = 0;
  G.forEach(g => g.opts.forEach(o => { DEFS[o.k] = o.d; TOTAL++; }));
  const DASH_BLOCKS = [['mood', 'حال‌وهوای بازار'], ['clock', 'ساعت و تازگی داده'], ['health', 'سلامت سیستم'], ['best', 'بهترین فرصت'], ['trend', 'روند ارز انتخاب‌شده'], ['learn', 'یادگیری از اشتباه (خلاصه)'], ['opps', 'فرصت‌های فعال'], ['heat', 'ماتریس ارز × تایم‌فریم'], ['market', 'وضعیت بازار'], ['log', 'آخرین سیگنال‌ها']];
  const WORK_TABS = [['trend', 'روند'], ['signal', 'سیگنال نهایی'], ['forecast', 'پیش‌بینی ۴۸ کندل'], ['patterns', 'الگوها'], ['timeline', 'زمان‌بندی'], ['levels', 'سطوح و ساختار'], ['indicators', 'اندیکاتورها'], ['micro', 'بازار خرد'], ['ai', 'هوش مصنوعی و گزارش']];
  const NAV_ITEMS = [['dash', 'داشبورد'], ['market', 'بازار'], ['work', 'تحلیل ارز'], ['signals', 'سیگنال‌ها'], ['trade', 'معاملات'], ['learn', 'یادگیری'], ['core', 'هسته'], ['style', 'ظاهر'], ['settings', 'تنظیمات']];
  const DEF_DASH = () => ({ order: DASH_BLOCKS.map(b => b[0]), hide: {}, span: { mood: 1, clock: 1, health: 1, best: 1, trend: 2, learn: 2, opps: 4, heat: 4, market: 4, log: 4 } });
  const DEF_LIST = (arr) => ({ order: arr.map(b => b[0]), hide: {} });

  T.theme = { G, PRESETS, DEFS, TOTAL, DASH_BLOCKS, WORK_TABS, NAV_ITEMS, count() { return TOTAL + DASH_BLOCKS.length * 3 + WORK_TABS.length * 2 + NAV_ITEMS.length * 2 + 3; } };
  T.st = k => { const c = S.cfg.st; return c && c[k] !== undefined ? c[k] : DEFS[k]; };
  T.layout = (what) => { const c = S.cfg, d = what === 'dash' ? DEF_DASH() : DEF_LIST(what === 'work' ? WORK_TABS : NAV_ITEMS); const u = c[what] || {}; const all = d.order; const ord = (u.order || []).filter(x => all.includes(x)); all.forEach(x => { if (!ord.includes(x)) ord.push(x); }); return { order: ord, hide: u.hide || {}, span: Object.assign(d.span || {}, u.span || {}) }; };

  /* ── colour helpers ── */
  const hex2rgb = h => { h = String(h || '').replace('#', ''); if (h.length === 3) h = h.split('').map(x => x + x).join(''); const n = parseInt(h.slice(0, 6), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
  const lum = h => { const [r, g, b] = hex2rgb(h); return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255; };
  T.rgb = hex => hex2rgb(hex);
  T.rgba = (hex, a) => { const [r, g, b] = hex2rgb(hex); return `rgba(${r},${g},${b},${a})`; };
  T.col = { bull: '#35f2c1', bear: '#ff5a86', warn: '#ffc861', info: '#62b0ff', ai: '#a88bff', mut: '#7482b3', gold: '#ffd98a', ink: '#e9efff' };

  /* ── apply ── */
  const ensureLayers = () => {
    if (document.getElementById('bg')) return;
    const bg = document.createElement('div'); bg.id = 'bg'; bg.setAttribute('aria-hidden', 'true'); bg.innerHTML = '<div class="aurora"><i></i><i></i><i></i></div>';
    const old = document.querySelector('body>.aurora'); if (old) old.remove();
    document.body.prepend(bg);
    const fx = document.createElement('canvas'); fx.id = 'fx'; document.body.insertBefore(fx, document.getElementById('shell'));
    const ov = document.createElement('div'); ov.id = 'ov'; ov.setAttribute('aria-hidden', 'true'); ov.innerHTML = '<i class="o-scan"></i><i class="o-grain"></i><i class="o-vig"></i><i class="o-spot"></i>'; document.body.appendChild(ov);
  };
  const subs = [];
  T.theme.onChange = fn => subs.push(fn);
  let applyT = 0;
  T.theme.apply = function () {
    ensureLayers();
    const st = Object.assign({}, DEFS, S.cfg.st || {}), s = R.style;
    G.forEach(g => g.opts.forEach(o => {
      let v = st[o.k];
      if (o.v) { let val = o.m ? o.m(v) : v; if (o.t === 'range' && !o.m) val = v + o.u; if (o.t === 'select') val = v; s.setProperty(o.v, String(val)); }
      if (o.a) R.setAttribute('data-' + o.a, o.t === 'switch' ? (v ? '1' : '0') : String(v));
    }));
    // derived palette
    const mix = (c, pct, w) => `color-mix(in srgb,${c} ${pct}%,${w})`;
    s.setProperty('--bull2', mix(st.bull, 72, '#000')); s.setProperty('--bull3', mix(st.bull, 55, '#fff')); s.setProperty('--bear2', mix(st.bear, 72, '#000')); s.setProperty('--bear3', mix(st.bear, 55, '#fff'));
    s.setProperty('--warn2', mix(st.warn, 78, '#000')); s.setProperty('--info2', mix(st.info, 75, '#000')); s.setProperty('--ai2', mix(st.ai, 75, '#000'));
    // scheme
    const light = st.scheme === 'light' || (st.scheme === 'auto' && lum(st.bg0) > 0.55);
    R.setAttribute('data-scheme', light ? 'light' : 'dark');
    if (light) { s.setProperty('--tipbg', '#ffffff'); } else s.removeProperty('--tipbg');
    // density presets
    const dn = { compact: [0.86, 0.7], cozy: [1, 1], comfy: [1.1, 1.25] }[st.dens] || [1, 1];
    s.setProperty('--dens', dn[0]);
    // typography
    const f = FONTS.find(x => x[0] === st.font) || FONTS[0]; s.setProperty('--f', f[2]);
    R.setAttribute('data-font', st.font);
    // grid dots
    // background image
    if (st.imgurl) s.setProperty('--bgimg', `url("${String(st.imgurl).replace(/"/g, '%22')}")`); else s.removeProperty('--bgimg');
    if (st.bgmode === 'image' && !st.imgurl) R.setAttribute('data-bg', 'aurora');
    document.title = st.title || 'TITAN PRO';
    const tm = document.querySelector('meta[name=theme-color]'); if (tm) tm.setAttribute('content', st.bg0);
    // T.col (canvas / SVG attribute consumers)
    ['bull', 'bear', 'warn', 'info', 'ai', 'gold', 'mut', 'ink'].forEach(k => { T.col[k] = st[k]; });
    T.col.up = st.ch_up || st.bull; T.col.dn = st.ch_dn || st.bear;
    fxStart(st); spotInit(st); rippleInit(st); tiltInit(st);
    T.drawLogo && T.drawLogo();
    clearTimeout(applyT); applyT = setTimeout(() => subs.forEach(fn => { try { fn(st); } catch (e) { /* ignore */ } }), 30);
  };
  T.theme.set = function (k, v, silent) {
    S.cfg.st = S.cfg.st || {}; S.cfg.st[k] = v; T.theme.apply(); T.saveCfg();
  };
  T.theme.preset = function (id) { const p = PRESETS[id]; if (!p) return; S.cfg.st = Object.assign({}, p.o); S.cfg.preset = id; T.theme.apply(); T.saveCfg(); };
  T.theme.reset = function (gid) {
    if (!gid) { S.cfg.st = {}; S.cfg.dash = null; S.cfg.work = null; S.cfg.nav = null; S.cfg.preset = 'neon'; }
    else { const g = G.find(x => x.id === gid); if (g) g.opts.forEach(o => { delete (S.cfg.st || {})[o.k]; }); }
    T.theme.apply(); T.saveCfg();
  };
  T.theme.export = () => JSON.stringify({ v: 2, st: S.cfg.st || {}, dash: S.cfg.dash, work: S.cfg.work, nav: S.cfg.nav }, null, 1);
  T.theme.import = function (txt) {
    const j = JSON.parse(txt); if (!j || typeof j !== 'object') throw new Error('bad json');
    S.cfg.st = j.st || {}; ['dash', 'work', 'nav'].forEach(k => { S.cfg[k] = j[k] || null; }); T.theme.apply(); T.saveCfg();
  };
  T.theme.random = function () {
    const h = Math.floor(Math.random() * 360), hc = (o) => `hsl(${(h + o) % 360} 90% 60%)`;
    const toHex = c => { const x = document.createElement('canvas').getContext('2d'); x.fillStyle = c; return x.fillStyle; };
    const dark = Math.random() > 0.15;
    const st = { bg0: toHex(`hsl(${h} 60% ${dark ? 5 : 94}%)`), bg1: toHex(`hsl(${(h + 20) % 360} 55% ${dark ? 12 : 88}%)`), bull: toHex(hc(140)), bear: toHex(hc(330)), warn: toHex(hc(50)), info: toHex(hc(210)), ai: toHex(hc(270)), acc: toHex(hc(0)), acc2: toHex(`hsl(${(h + 30) % 360} 90% 78%)`), bgA: toHex(hc(0)), bgB: toHex(hc(120)), bgC: toHex(hc(240)),
      glass: ['frosted', 'crystal', 'neon', 'matte'][Math.floor(Math.random() * 4)], glow: +(0.6 + Math.random() * 1.2).toFixed(1), bgmode: ['aurora', 'mesh', 'waves', 'grid'][Math.floor(Math.random() * 4)], nborder: ['0', '1', '2'][Math.floor(Math.random() * 3)],
      fxmode: ['none', 'particles', 'net', 'stars'][Math.floor(Math.random() * 4)], r1: 8 + Math.floor(Math.random() * 24), ntext: Math.random() > 0.5, shine: Math.random() > 0.6 };
    if (!dark) { st.scheme = 'light'; st.ink = '#14213d'; st.ink2 = '#3d4b6e'; st.mut = '#6d7aa0'; st.glass = 'paper'; st.deep = '#ffffff'; st.deep2 = '#dbe6ff'; st.wh = '#3a4a7a'; st.onacc = '#ffffff'; } else st.onacc = '#04141a';
    S.cfg.st = st; S.cfg.preset = 'random'; T.theme.apply(); T.saveCfg();
  };

  /* ── logo ── */
  T.drawLogo = function () {
    const el = document.querySelector('#rail .logo'); if (!el) return;
    const m = T.st('logomode'), c1 = T.st('logo1'), c2 = T.st('logo2'), sz = T.st('logosz'), txt = esc(T.st('logotext') || 'TITAN'), lab = T.st('logolab') ? `<b>${txt}</b>` : '';
    let h;
    if (m === 'none') h = '';
    else if (m === 'text') h = `<span class="lg-txt">${txt}</span>`;
    else if (m === 'badge') h = `<div class="lg-badge" style="width:${sz}px;height:${sz}px;border-radius:${Math.round(sz * .3)}px">${esc((T.st('logoletter') || 'T').slice(0, 2))}</div>${lab}`;
    else if (m === 'image' && T.st('logoimg')) h = `<img alt="" src="${esc(T.st('logoimg'))}" style="width:${sz}px;height:${sz}px">${lab}`;
    else h = `<svg viewBox="0 0 48 48" style="width:${sz}px;height:${sz}px"><defs><linearGradient id="lg" x1="0" x2="1" y1="0" y2="1"><stop offset="0" stop-color="${c1}"/><stop offset="1" stop-color="${c2}"/></linearGradient></defs><rect x="3" y="3" width="42" height="42" rx="13" fill="${T.st('deep')}" stroke="url(#lg)" stroke-width="1.5"/><path d="M10 31l6-15 8 10 5-14 9 19" fill="none" stroke="url(#lg)" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>${lab}`;
    el.innerHTML = h;
  };

  /* ── FX canvas (particles) ── */
  let fxRaf = 0, fxP = [], fxMode = '', fxLast = 0;
  function fxStart(st) {
    const cv = document.getElementById('fx'); if (!cv) return;
    const mode = st.fxmode; cancelAnimationFrame(fxRaf); fxRaf = 0;
    const ctx = cv.getContext('2d');
    if (mode === 'none') { ctx.clearRect(0, 0, cv.width, cv.height); return; }
    const resize = () => { cv.width = innerWidth; cv.height = innerHeight; }; resize(); if (!cv._rs) { cv._rs = 1; addEventListener('resize', () => { resize(); fxP = []; }); }
    const n = st.fxcount, col = st.fxcolor || '#62b0ff', sp = st.fxspeed, sz = st.fxsize, op = st.fxop / 100;
    const mk = () => ({ x: Math.random() * cv.width, y: Math.random() * cv.height, vx: (Math.random() - .5) * sp, vy: mode === 'snow' ? (0.4 + Math.random()) * sp : mode === 'bubbles' || mode === 'embers' ? -(0.3 + Math.random()) * sp : (Math.random() - .5) * sp, r: (0.4 + Math.random()) * sz, ph: Math.random() * 6.28, ch: String.fromCharCode(0x30A0 + Math.random() * 90 | 0) });
    if (fxMode !== mode + n || !fxP.length) { fxP = Array.from({ length: mode === 'matrix' ? Math.ceil(cv.width / 16) : n }, mk); fxMode = mode + n; if (mode === 'matrix') fxP.forEach(p => { p.y = Math.random() * cv.height; p.x = 0; }); }
    const loop = ts => {
      fxRaf = requestAnimationFrame(loop); if (document.hidden || ts - fxLast < 33) return; fxLast = ts;
      const W_ = cv.width, H = cv.height; const [r, g, b] = hex2rgb(col);
      if (mode === 'matrix') { ctx.fillStyle = 'rgba(0,0,0,.12)'; ctx.globalCompositeOperation = 'destination-out'; ctx.fillRect(0, 0, W_, H); ctx.globalCompositeOperation = 'source-over'; ctx.font = '15px monospace'; fxP.forEach((p, i) => { p.y += 14 * sp; if (p.y > H + 20 && Math.random() > .975) p.y = -20; ctx.fillStyle = `rgba(${r},${g},${b},${op})`; ctx.fillText(String.fromCharCode(0x30A0 + Math.random() * 90 | 0), i * 16, p.y); }); return; }
      ctx.clearRect(0, 0, W_, H);
      fxP.forEach(p => {
        p.x += p.vx; p.y += p.vy; p.ph += 0.03;
        if (mode === 'snow') p.x += Math.sin(p.ph) * 0.4; if (mode === 'bubbles') p.x += Math.sin(p.ph) * 0.5;
        if (p.x < -10) p.x = W_ + 10; if (p.x > W_ + 10) p.x = -10; if (p.y < -10) p.y = H + 10; if (p.y > H + 10) p.y = -10;
        let a = op; if (mode === 'stars') a = op * (0.4 + 0.6 * Math.abs(Math.sin(p.ph)));
        ctx.beginPath(); ctx.fillStyle = `rgba(${r},${g},${b},${a})`;
        if (mode === 'bubbles') { ctx.strokeStyle = `rgba(${r},${g},${b},${a})`; ctx.lineWidth = 1; ctx.arc(p.x, p.y, p.r * 3.2, 0, 6.28); ctx.stroke(); }
        else { ctx.shadowColor = col; ctx.shadowBlur = mode === 'embers' ? 10 : 4; ctx.arc(p.x, p.y, p.r, 0, 6.28); ctx.fill(); ctx.shadowBlur = 0; }
      });
      if (mode === 'net') { for (let i = 0; i < fxP.length; i++) for (let j = i + 1; j < fxP.length; j++) { const dx = fxP[i].x - fxP[j].x, dy = fxP[i].y - fxP[j].y, d = dx * dx + dy * dy; if (d < 14000) { ctx.strokeStyle = `rgba(${r},${g},${b},${(1 - d / 14000) * op * .7})`; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(fxP[i].x, fxP[i].y); ctx.lineTo(fxP[j].x, fxP[j].y); ctx.stroke(); } } }
    };
    fxRaf = requestAnimationFrame(loop);
  }
  /* spotlight / ripple / tilt */
  let spotOn = false, rippleOn = false, tiltOn = false;
  function spotInit(st) { spotOn = !!st.spot; if (!spotInit.b) { spotInit.b = 1; addEventListener('pointermove', e => { if (!spotOn) return; R.style.setProperty('--spot-x', e.clientX + 'px'); R.style.setProperty('--spot-y', e.clientY + 'px'); }, { passive: true }); } }
  function rippleInit(st) { rippleOn = !!st.ripple; if (!rippleInit.b) { rippleInit.b = 1; addEventListener('pointerdown', e => { if (!rippleOn) return; const d = document.createElement('i'); d.className = 'rip'; d.style.left = e.clientX + 'px'; d.style.top = e.clientY + 'px'; d.style.width = d.style.height = '90px'; document.body.appendChild(d); setTimeout(() => d.remove(), 800); }, { passive: true }); } }
  function tiltInit(st) {
    tiltOn = !!st.tilt;
    if (!tiltInit.b) {
      tiltInit.b = 1;
      document.addEventListener('pointermove', e => { if (!tiltOn) return; const c = e.target.closest && e.target.closest('.glass.coin'); if (!c) return; const r = c.getBoundingClientRect(), x = (e.clientX - r.left) / r.width - 0.5, y = (e.clientY - r.top) / r.height - 0.5; c.style.transform = `perspective(700px) rotateY(${(-x * 10).toFixed(1)}deg) rotateX(${(y * 10).toFixed(1)}deg) translateY(-3px)`; }, { passive: true });
      document.addEventListener('pointerout', e => { const c = e.target.closest && e.target.closest('.glass.coin'); if (c) c.style.transform = ''; }, { passive: true });
    }
  }

  /* ── Style Studio view ── */
  const swatch = (k, cols, cur) => `<div class="swatches">${cols.map(c => `<i data-k="${k}" data-v="${c}" class="${cur && cur.toLowerCase() === c ? 'on' : ''}" style="background:${c};color:${c}"></i>`).join('')}</div>`;
  const ACC = ['#35f2c1', '#62b0ff', '#a88bff', '#ff5a86', '#ffc861', '#ff8a3d', '#2dff7a', '#ff3d9a', '#52ffd6', '#f2f2f4', '#e0245e', '#1d6fe0'];
  function ctl(o) {
    const v = T.st(o.k), id = 'o_' + o.k;
    if (o.t === 'color') return `<div class="ctl"><input type="color" id="${id}" data-o="${o.k}" value="${/^#[0-9a-f]{6}$/i.test(v) ? v : '#888888'}"><span class="mono xs mut" id="${id}_v">${esc(v || 'خودکار')}</span>${['ch_up', 'ch_dn'].includes(o.k) ? `<button class="btn sm" data-clr="${o.k}">پیش‌فرض</button>` : ''}</div>`;
    if (o.t === 'range') return `<div class="ctl"><input type="range" id="${id}" data-o="${o.k}" min="${o.min}" max="${o.max}" step="${o.step}" value="${v}"><span class="rv mono" id="${id}_v">${v}${o.u || ''}</span></div>`;
    if (o.t === 'select') return `<div class="ctl"><select class="inp" id="${id}" data-o="${o.k}" style="width:100%">${o.ch.map(([a, n]) => `<option value="${a}" ${String(a) === String(v) ? 'selected' : ''}>${esc(n)}</option>`).join('')}</select></div>`;
    if (o.t === 'switch') return `<div class="ctl"><div class="sw ${v ? 'on' : ''}" data-sw="${o.k}" role="switch" aria-checked="${!!v}" tabindex="0"></div><span class="swl">${v ? 'روشن' : 'خاموش'}</span></div>`;
    return `<div class="ctl"><input class="inp" id="${id}" data-o="${o.k}" value="${esc(v || '')}" style="width:100%"></div>`;
  }
  const optRow = o => `<div class="opt"><label for="o_${o.k}">${esc(o.n)}</label>${ctl(o)}</div>`;
  function layoutList(what, items, withSpan) {
    const L = T.layout(what), nm = Object.fromEntries(items);
    return `<div class="st-laylist" data-lay="${what}">${L.order.map((id, i) => `<div class="lay-item ${L.hide[id] ? 'off' : ''}" data-id="${id}"><span class="ln">${T.fa(i + 1)}</span><b class="lt">${esc(nm[id])}</b>
      ${withSpan ? `<select class="inp" data-span="${id}" aria-label="پهنا">${[1, 2, 3, 4, 5, 6].map(n => `<option value="${n}" ${(L.span[id] || 1) == n ? 'selected' : ''}>${T.fa(n)} ستون</option>`).join('')}</select>` : ''}
      <span class="lb"><button type="button" class="btn sm" data-mv="-1" aria-label="بالا">▲</button><button type="button" class="btn sm" data-mv="1" aria-label="پایین">▼</button></span>
      <div class="sw ${L.hide[id] ? '' : 'on'}" data-vis="${id}" role="switch" aria-checked="${!L.hide[id]}" tabindex="0"></div></div>`).join('')}</div>`;
  }
  const V = T.V;
  const TITLES = { presets: ['تم‌های آماده', 'spark', 'انتخاب با یک کلیک'], compose: ['چیدمان و جاگذاری', 'grid', 'ترتیب و نمایش بخش‌ها'], tools: ['ابزارها و پشتیبان', 'db', 'خروجی، ورودی، تصادفی'] };
  V.style = {
    g: 'presets',
    mount() {
      T.$('#view').innerHTML = '<div id="st-root"></div>';
      this.root = T.$('#st-root');
      this.bind(this.root);                       // bound ONCE per visit (the old code re-bound on every render → clicks fired twice and cancelled)
      this.render();
    },
    nav() {
      const items = [['presets', ...TITLES.presets, Object.keys(PRESETS).length], ['compose', ...TITLES.compose, DASH_BLOCKS.length + WORK_TABS.length + NAV_ITEMS.length]]
        .concat(G.map(g => [g.id, g.n, g.ic, '', g.opts.length])).concat([['tools', ...TITLES.tools, 5]]);
      return `<nav class="glass st-nav" aria-label="بخش‌های استودیو">${items.map(([id, n, ic, , c]) => `<button type="button" data-g="${id}" class="${this.g === id ? 'on' : ''}"><span class="si">${T.ic(ic)}</span><span class="sn">${esc(n)}</span><span class="sc">${T.fa(c)}</span></button>`).join('')}</nav>`;
    },
    section(title, ic, sub, body, tools) {
      return `<section class="glass pn st-sec"><header class="st-h"><span class="si">${T.ic(ic)}</span><div class="st-t"><b>${esc(title)}</b>${sub ? `<small>${sub}</small>` : ''}</div>${tools || ''}</header>${body}</section>`;
    },
    render() {
      const root = this.root; if (!root) return;
      const view = T.$('#view'), y = view.scrollTop; let body = '';
      if (this.g === 'presets') {
        const cur = S.cfg.preset || 'neon';
        body = this.section('تم‌های آماده', 'spark', 'با یک کلیک رنگ‌ها، پس‌زمینه، شیشه و افکت‌ها عوض می‌شود · ' + T.fa(Object.keys(PRESETS).length) + ' تم',
          `<div class="st-presets">${Object.entries(PRESETS).map(([id, p]) => { const o = Object.assign({}, DEFS, p.o); return `<button type="button" class="preset ${cur === id ? 'on' : ''}" data-preset="${id}" style="background:linear-gradient(150deg,${o.bg1},${o.bg0});color:${o.ink}"><span class="pv" style="background:radial-gradient(100px 60px at 20% 0,${o.bgA}66,transparent),${o.bg0}"><i style="height:40%;background:${o.bull}"></i><i style="height:70%;background:${o.bear}"></i><i style="height:55%;background:${o.acc}"></i><i style="height:85%;background:${o.info}"></i><i style="height:35%;background:${o.ai}"></i></span><span class="pt"><span class="pi">${T.ic(p.ic)}</span><b>${esc(p.n)}</b>${cur === id ? '<em>فعال</em>' : ''}</span></button>`; }).join('')}</div>`)
          + this.section('رنگ‌های سریع', 'spark', 'رنگ اصلی، صعودی و نزولی را با یک کلیک عوض کنید',
            `<div class="opt"><label>رنگ اصلی (دکمه‌ها و تب فعال)</label>${swatch('acc', ACC, T.st('acc'))}</div><div class="opt"><label>رنگ صعودی</label>${swatch('bull', ['#35f2c1', '#2dff7a', '#52ffd6', '#7dffb0', '#4dffb0', '#a6f27a', '#00e5ff', '#d9d9e0'], T.st('bull'))}</div><div class="opt"><label>رنگ نزولی</label>${swatch('bear', ['#ff5a86', '#ff3b57', '#ff6f91', '#ff3d9a', '#ff7a6e', '#ff9f5a', '#c084fc', '#8a8a96'], T.st('bear'))}</div>`);
      } else if (this.g === 'compose') {
        body = this.section('چیدمان و جاگذاری', 'grid', 'ترتیب، پهنا و نمایش بخش‌ها؛ هر تغییر همان لحظه اعمال می‌شود', `<div class="st-lay"><div><h4>بخش‌های داشبورد</h4>${layoutList('dash', DASH_BLOCKS, true)}</div><div><h4>تب‌های تحلیل ارز</h4>${layoutList('work', WORK_TABS, false)}</div><div><h4>منوی اصلی</h4>${layoutList('nav', NAV_ITEMS, false)}</div></div><div class="xs mut" style="margin-top:12px">منوی «تنظیمات» قابل پنهان‌شدن نیست.</div>`);
      } else if (this.g === 'tools') {
        body = this.section('ابزارها', 'db', 'تم تصادفی، خروجی و ورودی تنظیمات',
          `<div class="row wrap" style="gap:8px"><button class="btn pri" id="st-rand">${T.ic('spark')}تم تصادفی</button><button class="btn" id="st-exp">${T.ic('db')}خروجی JSON</button><button class="btn" id="st-imp">${T.ic('plus')}وارد کردن JSON</button><button class="btn dng" id="st-reset">${T.ic('trash')}بازنشانی همه</button></div><textarea class="inp" id="st-json" style="width:100%;height:150px;margin-top:12px;font-family:var(--mono);font-size:11px" placeholder="برای وارد کردن، JSON را اینجا بچسبانید…"></textarea>`)
          + this.section('تم‌های ذخیره‌شدهٔ من', 'crown', 'تنظیمات فعلی را با یک نام نگه دارید',
            `<div class="row" style="gap:8px"><input class="inp" id="st-name" placeholder="نام تم" style="flex:1"><button class="btn" id="st-save">ذخیره</button></div><div class="row wrap" style="gap:6px;margin-top:10px">${Object.keys(S.cfg.themes || {}).map(n => `<span class="chip info">${esc(n)} <button class="btn sm" data-lt="${esc(n)}">اعمال</button><button class="btn sm dng" data-dt="${esc(n)}">✕</button></span>`).join('') || '<span class="mut xs">هنوز تمی ذخیره نکرده‌اید</span>'}</div>`);
      } else {
        const g = G.find(x => x.id === this.g) || G[0];
        body = this.section(g.n, g.ic, T.fa(g.opts.length) + ' گزینه', g.opts.map(optRow).join('') + (g.id === 'logo' ? '<div class="opt"><label>بارگذاری تصویر لوگو از دستگاه</label><div class="ctl"><input type="file" id="st-file" accept="image/*"></div></div>' : ''),
          `<button type="button" class="btn sm" data-rg="${g.id}">بازنشانی این بخش</button>`);
      }
      root.innerHTML = `<header class="st-top"><div class="st-ti"><span class="si big">${T.ic('spark')}</span><div class="st-t"><b>استودیوی ظاهر</b><small>${T.fa(T.theme.count())} گزینهٔ شخصی‌سازی · تغییرات زنده اعمال و ذخیره می‌شود</small></div></div><div class="row" style="gap:8px"><button type="button" class="btn" id="st-rand2">${T.ic('spark')}تصادفی</button><button type="button" class="btn dng" id="st-reset2">بازنشانی</button></div></header>
        <div class="studio">${this.nav()}<div id="st-body" class="st-body">${body}</div></div>`;
      view.scrollTop = y;
      const on = root.querySelector('.st-nav button.on'); if (on && on.scrollIntoView && innerWidth <= 900) on.scrollIntoView({ inline: 'center', block: 'nearest' });
    },
    bind(root) {
      const find = k => G.flatMap(g => g.opts).find(x => x.k === k);
      const re = () => this.render();
      T.on(root, '[data-g]', 'click', (e, b) => { this.g = b.dataset.g; this.render(); T.$('#view').scrollTop = 0; });
      T.on(root, '[data-preset]', 'click', (e, b) => { T.theme.preset(b.dataset.preset); re(); });
      T.on(root, '.swatches i', 'click', (e, b) => { T.theme.set(b.dataset.k, b.dataset.v); if (b.dataset.k === 'acc') { const l = lum(b.dataset.v), rg = hex2rgb(b.dataset.v); T.theme.set('onacc', l > 0.55 ? '#03121a' : '#ffffff'); T.theme.set('acc2', '#' + rg.map(c => Math.round(c * 0.55 + 255 * 0.45).toString(16).padStart(2, '0')).join('')); } re(); });
      root.addEventListener('input', e => { const t = e.target, o = t.dataset && t.dataset.o && find(t.dataset.o); if (!o || t.tagName === 'SELECT') return; let v = t.value; if (o.t === 'range') v = parseFloat(v); const lab = T.$('#o_' + o.k + '_v'); if (lab) lab.textContent = o.t === 'range' ? v + (o.u || '') : v; if (o.k === 'logoimg') return; T.theme.set(o.k, v); });
      root.addEventListener('change', e => {
        const t = e.target;
        if (t.id === 'st-file' && t.files && t.files[0]) { const f = t.files[0]; if (f.size > 120000) { T.toast('تصویر باید کمتر از ۱۲۰ کیلوبایت باشد', 'err'); return; } const rd = new FileReader(); rd.onload = () => { T.theme.set('logoimg', rd.result); T.theme.set('logomode', 'image'); T.toast('لوگو اعمال شد', 'ok'); re(); }; rd.readAsDataURL(f); return; }
        if (t.dataset && t.dataset.o && t.tagName === 'SELECT') { const o = find(t.dataset.o); if (o) T.theme.set(o.k, t.value); }
        if (t.dataset && t.dataset.o === 'logoimg') { T.theme.set('logoimg', t.value.trim()); if (t.value.trim()) T.theme.set('logomode', 'image'); }
        if (t.dataset && t.dataset.span) { const L = T.layout('dash'); S.cfg.dash = { order: L.order, hide: L.hide, span: Object.assign({}, L.span, { [t.dataset.span]: +t.value }) }; T.saveCfg(); }
      });
      T.on(root, '[data-sw]', 'click', (e, b) => { const k = b.dataset.sw, nv = !T.st(k); b.classList.toggle('on', nv); b.setAttribute('aria-checked', String(nv)); const l = b.parentElement.querySelector('.swl'); if (l) l.textContent = nv ? 'روشن' : 'خاموش'; T.theme.set(k, nv); });
      root.addEventListener('keydown', e => { if ((e.key === ' ' || e.key === 'Enter') && e.target.classList && e.target.classList.contains('sw')) { e.preventDefault(); e.target.click(); } });
      T.on(root, '[data-clr]', 'click', (e, b) => { T.theme.set(b.dataset.clr, ''); re(); });
      T.on(root, '[data-rg]', 'click', (e, b) => { e.preventDefault(); T.theme.reset(b.dataset.rg); re(); });
      T.on(root, '[data-vis]', 'click', (e, b) => { const w = b.closest('[data-lay]').dataset.lay, id = b.dataset.vis; if (w === 'nav' && id === 'settings') { T.toast('منوی تنظیمات قابل پنهان‌شدن نیست', 'err'); return; } const L = T.layout(w); S.cfg[w] = { order: L.order, hide: Object.assign({}, L.hide, { [id]: !L.hide[id] }), span: L.span }; T.saveCfg(); T.drawNavNow && T.drawNavNow(); re(); });
      T.on(root, '[data-mv]', 'click', (e, b) => { const row = b.closest('.lay-item'), w = row.parentElement.dataset.lay, id = row.dataset.id, L = T.layout(w), i = L.order.indexOf(id), j = i + +b.dataset.mv; if (j < 0 || j >= L.order.length) return; const o = L.order.slice(); [o[i], o[j]] = [o[j], o[i]]; S.cfg[w] = { order: o, hide: L.hide, span: L.span }; T.saveCfg(); T.drawNavNow && T.drawNavNow(); re(); });
      T.on(root, '#st-rand,#st-rand2', 'click', () => { T.theme.random(); re(); });
      T.on(root, '#st-reset,#st-reset2', 'click', () => { if (confirm('همهٔ تنظیمات ظاهر به پیش‌فرض برگردد؟')) { T.theme.reset(); T.drawNavNow && T.drawNavNow(); re(); } });
      T.on(root, '#st-exp', 'click', () => { T.$('#st-json').value = T.theme.export(); });
      T.on(root, '#st-imp', 'click', () => { try { T.theme.import(T.$('#st-json').value); T.drawNavNow && T.drawNavNow(); T.toast('تم وارد شد', 'ok'); re(); } catch (e) { T.toast('JSON معتبر نیست', 'err'); } });
      T.on(root, '#st-save', 'click', () => { const n = (T.$('#st-name').value || '').trim(); if (!n) return; S.cfg.themes = Object.assign({}, S.cfg.themes, { [n]: { st: S.cfg.st || {}, dash: S.cfg.dash, work: S.cfg.work, nav: S.cfg.nav } }); T.saveCfg(); T.toast('تم ذخیره شد', 'ok'); re(); });
      T.on(root, '[data-lt]', 'click', (e, b) => { const t = (S.cfg.themes || {})[b.dataset.lt]; if (t) { S.cfg.st = Object.assign({}, t.st); S.cfg.dash = t.dash || null; S.cfg.work = t.work || null; S.cfg.nav = t.nav || null; T.theme.apply(); T.saveCfg(); T.drawNavNow && T.drawNavNow(); re(); } });
      T.on(root, '[data-dt]', 'click', (e, b) => { const th = Object.assign({}, S.cfg.themes); delete th[b.dataset.dt]; S.cfg.themes = th; T.saveCfg(); re(); });
    },
    tick() { }
  };
})(window);
