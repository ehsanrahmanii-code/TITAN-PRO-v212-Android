/* TITAN · chart. Every candle — past, forming and future — carries its own date/time (axis, crosshair, tooltip).
   Layers: candles, EMA, volume, 48-candle projection + probability cone, trade levels, S/R zones, patterns with validity windows. */
(function (W) {
  'use strict';
  const T = W.TT; let BULL = '#35f2c1', BEAR = '#ff5a86', INFO = '#62b0ff', WARN = '#ffc861', AI = '#a88bff', UP = BULL, DN = BEAR, E1 = WARN, E2 = AI, LW = 1;
  const pal = () => { const c = T.col; BULL = c.bull; BEAR = c.bear; INFO = c.info; WARN = c.warn; AI = c.ai; UP = c.up || BULL; DN = c.dn || BEAR; E1 = T.st('ch_ema1') || WARN; E2 = T.st('ch_ema2') || AI; LW = T.st('ch_lw') || 1; };

  const FA = /[\u0600-\u06FF]/;
  function put(c, str, x, y, align) { c.direction = FA.test(str) ? 'rtl' : 'ltr'; c.textAlign = align || 'left'; c.fillText(str, x, y); c.direction = 'ltr'; }
  function ema(arr, n) { const k = 2 / (n + 1); let e = arr[0]; return arr.map((v, i) => (e = i ? v * k + e * (1 - k) : v)); }
  function nice(x) { const e = Math.pow(10, Math.floor(Math.log10(x))), f = x / e; return (f < 1.5 ? 1 : f < 3 ? 2 : f < 7 ? 5 : 10) * e; }
  function rgba(hex, a) { const n = parseInt(hex.slice(1), 16); return `rgba(${n >> 16},${(n >> 8) & 255},${n & 255},${a})`; }

  class Chart {
    constructor(host) {
      this.host = host; this.cv = document.createElement('canvas'); this.ctx = this.cv.getContext('2d');
      this.tipEl = document.createElement('div'); this.tipEl.className = 'ctip'; this.tipEl.hidden = true;
      host.appendChild(this.cv); host.appendChild(this.tipEl);
      this.d = null; this.layers = Object.assign({}, T.S.cfg.layers); this.vs = 0; this.bw = 8; this.mouse = null; this.drag = null; this.ptrs = new Map();
      this.pad = { l: 8, r: 74, t: 26, b: 42 };
      this.ro = new ResizeObserver(() => this.resize()); this.ro.observe(host);
      const c = this.cv;
      c.addEventListener('pointerdown', e => this.down(e)); c.addEventListener('pointermove', e => this.move(e));
      c.addEventListener('pointerup', e => this.up(e)); c.addEventListener('pointercancel', e => this.up(e));
      c.addEventListener('pointerleave', () => { if (!this.drag) { this.mouse = null; this.tipEl.hidden = true; this.draw(); } });
      c.addEventListener('wheel', e => { e.preventDefault(); this.zoomAt(e.deltaY < 0 ? 1.12 : 1 / 1.12, this.localX(e)); }, { passive: false });
      c.addEventListener('dblclick', () => this.fit());
      this.resize();
    }
    get h() { return T.st('ch_h') || 480; }
    destroy() { this.ro.disconnect(); this.host.innerHTML = ''; }
    localX(e) { return e.clientX - this.cv.getBoundingClientRect().left; }
    resize() {
      const w = this.host.clientWidth || 600, h = this.h, dpr = Math.min(2, devicePixelRatio || 1);
      this.W = w; this.cv.width = Math.round(w * dpr); this.cv.height = Math.round(h * dpr); this.cv.style.height = h + 'px';
      this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0); this.pw = w - this.pad.l - this.pad.r;
      if (this.d && !this._fitted) this.fit(); else this.draw();
    }
    /** data: {klines, fc, tf, bar_ms, plan, zones, pats, structs, now} */
    set(d) {
      const first = !this.d || this.d.sym !== d.sym || this.d.tf !== d.tf;
      this.d = d; this.prep();
      if (first) { this._fitted = false; this.fit(); } else this.draw();
    }
    prep() {
      const d = this.d, ks = d.klines || [], ms = d.bar_ms || T.tfMs(d.tf);
      this.ms = ms; this.n = ks.length; this.T0 = ks.length ? ks[0].t : 0;
      this.idx = t => (t - this.T0) / ms; this.tAt = i => this.T0 + i * ms;
      const cl = ks.map(k => k.c); this.e21 = ema(cl, 21); this.e50 = ema(cl, 50);
      const fc = (d.fc && d.fc.candles) || [], lastT = ks.length ? ks[ks.length - 1].t : 0;
      this.fut = fc.filter(c => c.t > lastT);                      // true future candles (the forming one is the real last candle)
      this.fcAll = fc; this.total = this.n + this.fut.length;
    }
    fit() {
      if (!this.d) return; this._fitted = true;
      const nf = this.fut.length, show = Math.min(this.n, this.W < 640 ? 46 : 84), tot = show + nf + 3;
      this.bw = T.clamp(this.pw / tot, 2.2, 22); this.vs = Math.max(-2, this.n - show); this.draw();
    }
    goNow() { this.vs = this.n - Math.floor(this.pw / this.bw * 0.55); this.draw(); }
    zoom(f) { this.zoomAt(f, this.pad.l + this.pw / 2); }
    zoomAt(f, x) { const a = this.vs + (x - this.pad.l) / this.bw; this.bw = T.clamp(this.bw * f, 2, 40); this.vs = a - (x - this.pad.l) / this.bw; this.clampVs(); this.draw(); }
    clampVs() { const vis = this.pw / this.bw; this.vs = T.clamp(this.vs, -vis * 0.5, this.total - vis * 0.45); }
    down(e) {
      this.cv.setPointerCapture(e.pointerId); this.ptrs.set(e.pointerId, e.clientX);
      this.drag = { x: e.clientX, vs: this.vs, moved: false, pinch: null };
      if (this.ptrs.size === 2) { const v = [...this.ptrs.values()]; this.drag.pinch = { d: Math.abs(v[0] - v[1]), bw: this.bw }; }
    }
    move(e) {
      const x = this.localX(e), y = e.clientY - this.cv.getBoundingClientRect().top;
      if (this.ptrs.has(e.pointerId)) this.ptrs.set(e.pointerId, e.clientX);
      if (this.drag && this.ptrs.size === 2 && this.drag.pinch) {
        const v = [...this.ptrs.values()], dd = Math.abs(v[0] - v[1]) || 1; this.bw = T.clamp(this.drag.pinch.bw * dd / this.drag.pinch.d, 2, 40); this.clampVs(); this.draw(); return;
      }
      if (this.drag && this.ptrs.size === 1 && (e.pointerType !== 'mouse' || e.buttons)) {
        const dx = e.clientX - this.drag.x; if (Math.abs(dx) > 3) this.drag.moved = true;
        if (this.drag.moved) { this.vs = this.drag.vs - dx / this.bw; this.clampVs(); this.tipEl.hidden = true; this.draw(); return; }
      }
      this.mouse = { x, y }; this.draw(); this.showTip();
    }
    up(e) { this.ptrs.delete(e.pointerId); if (!this.ptrs.size) this.drag = null; }

    /* ── geometry ── */
    X(i) { return this.pad.l + (i - this.vs + 0.5) * this.bw; }
    Y(p) { return this.pt + (this.hi - p) / (this.hi - this.lo) * this.ph; }
    range() {
      const d = this.d, a = Math.max(0, Math.floor(this.vs)), b = Math.min(this.n - 1, Math.ceil(this.vs + this.pw / this.bw));
      let lo = Infinity, hi = -Infinity;
      for (let i = a; i <= b; i++) { const k = d.klines[i]; if (k) { lo = Math.min(lo, k.l); hi = Math.max(hi, k.h); } }
      if (!isFinite(lo)) { const k = d.klines[this.n - 1]; lo = k.l; hi = k.h; }
      const L = this.layers;
      if (L.fc && this.fut.length) {
        const b2 = (d.fc && d.fc.bands) || {};
        if (L.cone && b2.p10) { lo = Math.min(lo, ...b2.p10.slice(0, 60)); hi = Math.max(hi, ...b2.p90.slice(0, 60)); }
        else this.fut.forEach(c => { lo = Math.min(lo, c.low); hi = Math.max(hi, c.high); });
      }
      const span = (hi - lo) || hi * 0.01;
      if (L.lv && d.plan && d.plan.side && d.plan.side !== 'WAIT') [d.plan.stop, d.plan.tp1, d.plan.tp2, d.plan.entry].forEach(v => { if (v && v > lo - span * 0.5 && v < hi + span * 0.5) { lo = Math.min(lo, v); hi = Math.max(hi, v); } });
      const pad = (hi - lo) * 0.07; this.lo = lo - pad; this.hi = hi + pad;
    }
    draw() {
      if (!this.d || !this.n) return;
      pal(); const c = this.ctx, W_ = this.W, H = this.h, p = this.pad, L = this.layers, d = this.d;
      if (this.host.parentElement) this.host.parentElement.setAttribute('data-chbg', T.st('ch_bg'));
      if (this.cv.style.height !== H + 'px') this.resize();
      c.clearRect(0, 0, W_, H);
      const volH = L.vol ? Math.round((H - p.t - p.b) * 0.15) : 0;
      this.pt = p.t; this.ph = H - p.t - p.b - volH - (volH ? 8 : 0); this.vy0 = this.pt + this.ph + 8; this.vh = volH;
      this.range();
      const a = Math.floor(this.vs) - 1, b = Math.ceil(this.vs + this.pw / this.bw) + 1;
      c.save(); c.beginPath(); c.rect(p.l, 0, this.pw, H); c.clip();
      this.drawGrid(a, b); this.drawZones(); this.drawSR(); this.drawFutureBg(); this.drawPatternBoxes(); this.drawCone();
      if (L.lv) this.drawPosition(); this.drawEma(a, b); this.drawCandles(a, b); this.drawFutureCandles(); this.drawMarkers(); this.drawStructs();
      if (L.vol) this.drawVolume(a, b);
      this.drawLast(); this.drawNow(); c.restore();
      this.drawAxes(a, b); this.drawLevelTags(); this.drawHeader(); this.drawCross();
    }
    drawGrid(a, b) {
      const c = this.ctx, p = this.pad, step = nice((this.hi - this.lo) / 6);
      const gk = T.st('ch_grid'), go = T.st('ch_gridop') / 100; c.lineWidth = 1; c.strokeStyle = T.rgba(T.col.ink, go); c.beginPath();
      if (gk !== 'none') for (let v = Math.ceil(this.lo / step) * step; v < this.hi; v += step) { const y = Math.round(this.Y(v)) + .5; if (gk === 'dots') { for (let x = p.l; x < p.l + this.pw; x += 8) c.rect(x, y, 1.2, 1.2); } else { c.moveTo(p.l, y); c.lineTo(p.l + this.pw, y); } }
      gk === 'dots' ? (c.fillStyle = T.rgba(T.col.ink, go * 2), c.fill()) : c.stroke();
      // day boundaries
      c.strokeStyle = 'rgba(255,255,255,.07)'; c.setLineDash([2, 4]); c.beginPath();
      let prev = null;
      for (let i = a; i <= b; i++) {
        const t = this.tAt(i), day = T.jnum(t);
        if (prev && day !== prev && this.ms < 864e5) { const x = Math.round(this.X(i) - this.bw / 2) + .5; c.moveTo(x, this.pt); c.lineTo(x, this.pt + this.ph); }
        prev = day;
      }
      c.stroke(); c.setLineDash([]);
    }
    drawZones() {
      const z = this.d.zones || [], c = this.ctx, p = this.pad;
      if (!this.layers.zones) return;
      z.forEach(o => {
        if (o.p < this.lo || o.p > this.hi) return; const y = this.Y(o.p), col = o.kind === 'R' ? BEAR : BULL, h = Math.max(3, o.n * 1.6);
        c.fillStyle = rgba(col, .07); c.fillRect(p.l, y - h, this.pw, h * 2); c.strokeStyle = rgba(col, .35); c.setLineDash([1, 5]); c.beginPath(); c.moveTo(p.l, y); c.lineTo(p.l + this.pw, y); c.stroke(); c.setLineDash([]);
      });
    }
    /* v2.1 · clustered support/resistance lines (strength = touches), drawn from their first touch */
    drawSR() {
      const sr = this.d.sr; if (!T.st('ch_sr') || !sr || !sr.length) return; const c = this.ctx, p = this.pad, lab = T.st('ch_srlab');
      sr.slice(0, 7).forEach(z => {
        if (!isFinite(z.p) || z.p < this.lo || z.p > this.hi) return;
        const col = z.kind === 'R' ? BEAR : BULL, y = Math.round(this.Y(z.p)) + .5, x0 = z.t0 ? Math.max(p.l, this.X(this.idx(z.t0))) : p.l;
        c.save(); c.globalAlpha = .35 + .5 * (z.strength || .3); c.strokeStyle = col; c.lineWidth = (1 + (z.touches >= 4 ? 1 : 0)) * LW; c.setLineDash([2, 3]); c.beginPath(); c.moveTo(x0, y); c.lineTo(p.l + this.pw, y); c.stroke(); c.restore();
        if (lab) { c.fillStyle = T.rgba(col, .95); c.font = '700 9.5px system-ui,sans-serif'; put(c, `${z.kind === 'R' ? 'مقاومت' : 'حمایت'} ${T.fa(z.touches)}×${z.flipped ? ' ⇄' : ''}`, p.l + this.pw - 4, y - 3, 'right'); }
      });
    }
    drawFutureBg() {
      if (!this.layers.fc || !this.fut.length) return;
      const c = this.ctx, x0 = this.X(this.idx(this.fut[0].t)) - this.bw / 2, x1 = this.X(this.idx(this.fut[this.fut.length - 1].t)) + this.bw / 2;
      const g = c.createLinearGradient(x0, 0, x1, 0); g.addColorStop(0, 'rgba(98,176,255,.09)'); g.addColorStop(1, 'rgba(168,139,255,.03)');
      c.fillStyle = g; c.fillRect(x0, this.pt, x1 - x0, this.ph);
      c.strokeStyle = 'rgba(98,176,255,.35)'; c.setLineDash([6, 5]); c.beginPath(); c.moveTo(x0, this.pt); c.lineTo(x0, this.pt + this.ph); c.stroke(); c.setLineDash([]);
      c.fillStyle = 'rgba(160,200,255,.8)'; c.font = '600 11px system-ui,sans-serif'; c.textAlign = 'left';
      const te = this.fut[this.fut.length - 1].t_close || this.fut[this.fut.length - 1].t;
      put(c, `${T.fa(this.fut.length)} کندل آینده · تا ${T.date(te)} ${T.time(te)}`, Math.max(x0 + 8, this.pad.l + 8), this.pt + this.ph - 8, 'left');
    }
    drawCone() {
      const L = this.layers, f = this.d.fc; if (!L.fc || !L.cone || !f || !f.bands || !f.bands.p10) return;
      const c = this.ctx, cs = this.fcAll, up = [], dn = [], mid = [];
      cs.forEach((k, j) => { const x = this.X(this.idx(k.t)); up.push([x, this.Y(f.bands.p90[j])]); dn.push([x, this.Y(f.bands.p10[j])]); mid.push([x, this.Y(f.bands.p50[j])]); });
      if (up.length < 2) return;
      const g = c.createLinearGradient(up[0][0], 0, up[up.length - 1][0], 0); g.addColorStop(0, 'rgba(98,176,255,.22)'); g.addColorStop(1, 'rgba(168,139,255,.08)');
      c.beginPath(); up.forEach((q, i) => i ? c.lineTo(q[0], q[1]) : c.moveTo(q[0], q[1])); dn.slice().reverse().forEach(q => c.lineTo(q[0], q[1])); c.closePath(); if (T.st('ch_cone') !== 'lines') { c.fillStyle = g; c.fill(); }
      c.lineWidth = 1; c.strokeStyle = 'rgba(98,176,255,.5)'; [up, dn].forEach(arr => { c.beginPath(); arr.forEach((q, i) => i ? c.lineTo(q[0], q[1]) : c.moveTo(q[0], q[1])); c.stroke(); });
      c.lineWidth = 1.8; c.strokeStyle = 'rgba(255,255,255,.75)'; c.setLineDash([5, 4]); c.shadowColor = INFO; c.shadowBlur = 8; c.beginPath(); mid.forEach((q, i) => i ? c.lineTo(q[0], q[1]) : c.moveTo(q[0], q[1])); c.stroke(); c.setLineDash([]); c.shadowBlur = 0;
    }
    drawPosition() {
      const pl = this.d.plan; if (!pl || !pl.side || pl.side === 'WAIT' || !pl.entry) return;
      const c = this.ctx, x0 = this.X(this.n - 1), x1 = this.pad.l + this.pw, ye = this.Y(pl.entry);
      const ys = this.Y(pl.stop), yt = this.Y(pl.tp3 || pl.tp2 || pl.tp1);
      c.fillStyle = 'rgba(255,90,134,.10)'; c.fillRect(x0, Math.min(ye, ys), x1 - x0, Math.abs(ys - ye));
      c.fillStyle = 'rgba(53,242,193,.09)'; c.fillRect(x0, Math.min(ye, yt), x1 - x0, Math.abs(yt - ye));
      const ln = (v, col, dash, w) => { if (!v) return; const y = Math.round(this.Y(v)) + .5; c.strokeStyle = col; c.lineWidth = w || 1.2; c.setLineDash(dash || []); c.shadowColor = col; c.shadowBlur = 6; c.beginPath(); c.moveTo(this.pad.l, y); c.lineTo(x1, y); c.stroke(); c.shadowBlur = 0; c.setLineDash([]); };
      ln(pl.entry, INFO, [7, 4], 1.6); ln(pl.stop, BEAR, [3, 3], 1.4); ln(pl.tp1, BULL, [3, 3]); ln(pl.tp2, BULL, [3, 3]); ln(pl.tp3, BULL, [3, 3]);
    }
    drawEma(a, b) {
      if (!this.layers.ema) return; const c = this.ctx;
      [[this.e21, E1], [this.e50, E2]].forEach(([arr, col]) => {
        c.beginPath(); c.lineWidth = 1.4 * LW; c.strokeStyle = rgba(col, .85); let st = false;
        for (let i = Math.max(0, a); i <= Math.min(this.n - 1, b); i++) { const x = this.X(i), y = this.Y(arr[i]); st ? c.lineTo(x, y) : c.moveTo(x, y); st = true; }
        c.stroke();
      });
    }
    drawCandles(a, b) {
      const c = this.ctx, bw = this.bw, st = T.st('ch_style'), bodyR = T.st('ch_body') / 100, w = Math.max(1, Math.min(bw * bodyR, 20)), glow = T.st('ch_glow'), wk = T.st('ch_wick') * LW;
      const ks = this.d.klines, lo = Math.max(0, a), hi = Math.min(this.n - 1, b);
      if (st === 'line' || st === 'area') {
        c.beginPath(); for (let i = lo; i <= hi; i++) { const x = this.X(i), y = this.Y(ks[i].c); i === lo ? c.moveTo(x, y) : c.lineTo(x, y); }
        c.strokeStyle = UP; c.lineWidth = 2 * LW; c.shadowColor = UP; c.shadowBlur = 8 * glow; c.stroke(); c.shadowBlur = 0;
        if (st === 'area') { c.lineTo(this.X(hi), this.pt + this.ph); c.lineTo(this.X(lo), this.pt + this.ph); c.closePath(); const g = c.createLinearGradient(0, this.pt, 0, this.pt + this.ph); g.addColorStop(0, T.rgba(UP, .35)); g.addColorStop(1, T.rgba(UP, 0)); c.fillStyle = g; c.fill(); }
        return;
      }
      let po = null, pc = null;
      for (let i = lo; i <= hi; i++) {
        let k = ks[i], o = k.o, cl = k.c, h = k.h, l = k.l;
        if (st === 'heikin') { const hc = (k.o + k.h + k.l + k.c) / 4, ho = po == null ? (k.o + k.c) / 2 : (po + pc) / 2; o = ho; cl = hc; h = Math.max(k.h, ho, hc); l = Math.min(k.l, ho, hc); po = ho; pc = hc; }
        const up = cl >= o, col = up ? UP : DN, x = this.X(i), live = i === this.n - 1 && this.d.forming !== false;
        c.strokeStyle = col; c.fillStyle = col; c.lineWidth = Math.max(1, Math.min(wk, bw / 3)) * (st === 'bars' ? 1.4 : 1);
        c.beginPath(); c.moveTo(Math.round(x) + .5, this.Y(h)); c.lineTo(Math.round(x) + .5, this.Y(l)); c.stroke();
        if (st === 'bars') { c.beginPath(); c.moveTo(x - w / 2, this.Y(o)); c.lineTo(x, this.Y(o)); c.moveTo(x, this.Y(cl)); c.lineTo(x + w / 2, this.Y(cl)); c.stroke(); continue; }
        const y1 = this.Y(Math.max(o, cl)), y2 = this.Y(Math.min(o, cl)), hh = Math.max(1.5, y2 - y1);
        if (w >= 3) {
          c.shadowColor = col; c.shadowBlur = bw > 6 ? 6 * glow : 0;
          if (st === 'hollow' && up) { c.globalAlpha = live ? .6 : 1; c.lineWidth = 1.4; c.strokeRect(x - w / 2, y1, w, hh); }
          else { c.globalAlpha = live ? .55 : .92; c.fillRect(x - w / 2, y1, w, hh); }
          c.shadowBlur = 0; c.globalAlpha = 1;
        }
        if (live) { c.setLineDash([3, 2]); c.strokeStyle = T.col.ink; c.lineWidth = 1; c.strokeRect(x - w / 2 - 1, y1 - 1, w + 2, hh + 2); c.setLineDash([]); }
      }
    }
    drawFutureCandles() {
      if (!this.layers.fc) return; const c = this.ctx, w = Math.max(1, Math.min(this.bw * 0.7, 16));
      this.fut.forEach(k => {
        const i = this.idx(k.t), x = this.X(i), up = k.close >= k.open, col = up ? UP : DN;
        c.strokeStyle = rgba(col, .75); c.lineWidth = 1; c.beginPath(); c.moveTo(Math.round(x) + .5, this.Y(k.high)); c.lineTo(Math.round(x) + .5, this.Y(k.low)); c.stroke();
        const y1 = this.Y(Math.max(k.open, k.close)), y2 = this.Y(Math.min(k.open, k.close)), hh = Math.max(1.5, y2 - y1);
        if (w >= 3) { const fk = T.st('ch_fut'); if (fk !== 'outline') { c.fillStyle = rgba(col, fk === 'solid' ? .8 : .22); c.fillRect(x - w / 2, y1, w, hh); } if (fk !== 'solid') { c.setLineDash([2, 2]); c.strokeStyle = rgba(col, .9); c.strokeRect(x - w / 2, y1, w, hh); c.setLineDash([]); } }
      });
    }
    drawVolume(a, b) {
      const c = this.ctx; let mx = 0; for (let i = Math.max(0, a); i <= Math.min(this.n - 1, b); i++) mx = Math.max(mx, this.d.klines[i].v);
      for (let i = Math.max(0, a); i <= Math.min(this.n - 1, b); i++) { const k = this.d.klines[i], h = k.v / (mx || 1) * this.vh, x = this.X(i), w = Math.max(1, this.bw * 0.7); c.fillStyle = rgba(k.c >= k.o ? BULL : BEAR, .35); c.fillRect(x - w / 2, this.vy0 + this.vh - h, w, h); }
    }
    drawLast() {
      if (!T.st('ch_last')) return; const k = this.d.klines[this.n - 1]; if (!k || k.c < this.lo || k.c > this.hi) return; const c = this.ctx, y = Math.round(this.Y(k.c)) + .5, col = k.c >= k.o ? UP : DN;
      c.save(); c.strokeStyle = T.rgba(col, .6); c.setLineDash([1, 3]); c.beginPath(); c.moveTo(this.pad.l, y); c.lineTo(this.pad.l + this.pw, y); c.stroke(); c.restore();
    }
    drawNow() {
      const c = this.ctx, x = this.X(this.n - 1) + this.bw / 2;
      c.strokeStyle = 'rgba(255,200,97,.55)'; c.lineWidth = 1; c.setLineDash([2, 3]); c.beginPath(); c.moveTo(x, this.pt); c.lineTo(x, this.pt + this.ph); c.stroke(); c.setLineDash([]);
    }
    drawPatternBoxes() {
      if (!this.layers.pat || !this.d.pats) return; const c = this.ctx;
      this.d.pats.filter(p => p.alive && p.bias !== 0).slice(0, 6).forEach(p => {
        const x0 = this.X(this.idx(p.t_start)) - this.bw / 2, x1 = this.X(this.idx(p.valid_until)) - this.bw / 2, col = p.bias > 0 ? BULL : BEAR;
        const y0 = this.Y(p.pat_hi), y1 = this.Y(p.pat_lo);
        c.fillStyle = rgba(col, .06); c.fillRect(x0, y0, x1 - x0, y1 - y0); c.setLineDash([4, 3]); c.strokeStyle = rgba(col, .55); c.lineWidth = 1; c.strokeRect(x0 + .5, y0 + .5, x1 - x0, y1 - y0); c.setLineDash([]);
        if (p.invalid_level) { const yy = this.Y(p.invalid_level); c.strokeStyle = rgba(WARN, .7); c.setLineDash([2, 3]); c.beginPath(); c.moveTo(x0, yy); c.lineTo(x1, yy); c.stroke(); c.setLineDash([]); }
        c.fillStyle = rgba(col, .95); c.font = '600 10px system-ui,sans-serif'; c.textAlign = 'left';
        put(c, `${p.fa} · تا ${T.time(p.valid_until)}`, x0 + 4, p.bias > 0 ? y1 + 12 : y0 - 4, 'left');
      });
    }
    drawMarkers() {
      if (!this.layers.pat || !this.d.pats) return; const c = this.ctx;
      this.d.pats.forEach(p => {
        const i = this.idx(p.t); if (i < 0 || i > this.n - 1) return; const x = this.X(i), col = p.bias > 0 ? BULL : p.bias < 0 ? BEAR : WARN, k = this.d.klines[Math.round(i)]; if (!k) return;
        const up = p.bias >= 0, y = up ? this.Y(k.l) + 10 : this.Y(k.h) - 10, s = p.alive ? 6 : 4;
        c.globalAlpha = p.alive ? 1 : .4; c.fillStyle = col; c.shadowColor = col; c.shadowBlur = p.alive ? 10 : 0; c.beginPath();
        if (p.bias === 0) { c.arc(x, y, s * .7, 0, 7); } else if (up) { c.moveTo(x, y - s); c.lineTo(x - s, y + s * .7); c.lineTo(x + s, y + s * .7); } else { c.moveTo(x, y + s); c.lineTo(x - s, y - s * .7); c.lineTo(x + s, y - s * .7); }
        c.fill(); c.shadowBlur = 0; c.globalAlpha = 1;
      });
    }
    drawStructs() {
      if (!this.layers.struct || !this.d.structs) return; const c = this.ctx;
      this.d.structs.filter(s => s.alive).slice(0, 3).forEach((s, si) => {
        const col = s.bias > 0 ? BULL : s.bias < 0 ? BEAR : WARN;
        (s.lines_t || []).forEach((ln, li) => {
          const x0 = this.X(this.idx(ln[0])), x1 = this.X(this.idx(ln[2])), sl = (ln[3] - ln[1]) / ((ln[2] - ln[0]) || 1);
          const te = Math.min(s.valid_until, ln[2] + (s.valid_until - ln[2]) * (s.k.includes('tri') || s.k.includes('wedge') ? 1 : 0.0001));
          const ye = ln[3] + sl * (te - ln[2]), xe = this.X(this.idx(te));
          c.strokeStyle = rgba(col, li < 2 ? .95 : .55); c.lineWidth = li < 2 ? 2 : 1.3; c.shadowColor = col; c.shadowBlur = 8; c.beginPath(); c.moveTo(x0, this.Y(ln[1])); c.lineTo(x1, this.Y(ln[3])); c.stroke();
          c.setLineDash([5, 4]); c.beginPath(); c.moveTo(x1, this.Y(ln[3])); c.lineTo(xe, this.Y(ye)); c.stroke(); c.setLineDash([]); c.shadowBlur = 0;
        });
        const x = this.X(this.idx(s.valid_until)), y = this.pt + 18 + si * 16;
        c.fillStyle = rgba(col, .95); c.font = '700 11px system-ui,sans-serif'; put(c, `${s.fa} · معتبر تا ${T.date(s.valid_until)} ${T.time(s.valid_until)}`, Math.min(x, this.pad.l + this.pw - 6), y, 'right');
        if (s.target) { const yy = this.Y(s.target); if (yy > this.pt && yy < this.pt + this.ph) { c.strokeStyle = rgba(col, .8); c.setLineDash([2, 4]); c.beginPath(); c.moveTo(this.X(this.n - 1), yy); c.lineTo(this.pad.l + this.pw, yy); c.stroke(); c.setLineDash([]); c.fillStyle = rgba(col, .95); c.font = '600 10px system-ui'; put(c, 'هدف الگو ' + T.price(s.target) + (s.target_eta_t ? ' · حدود ' + T.time(s.target_eta_t) : ''), this.pad.l + this.pw - 6, yy - 4, 'right'); } }
      });
    }
    drawAxes(a, b) {
      const c = this.ctx, p = this.pad, H = this.h, step = nice((this.hi - this.lo) / 6);
      c.font = '11px ui-monospace,Menlo,monospace'; c.textAlign = 'left'; c.fillStyle = T.rgba(T.col.ink, .75);
      for (let v = Math.ceil(this.lo / step) * step; v < this.hi; v += step) c.fillText(T.price(v), p.l + this.pw + 7, this.Y(v) + 4);
      // time axis: two lines per label (time / date) — for 1d: date / weekday
      const ms = this.ms, bw = this.bw; let sb = 1; for (const s of [1, 2, 3, 4, 6, 8, 12, 16, 24, 48, 96]) { sb = s; if (s * bw >= 84) break; }
      const y0 = H - p.b + 14; c.textAlign = 'center'; let prevDay = null;
      c.strokeStyle = 'rgba(255,255,255,.1)'; c.beginPath(); c.moveTo(p.l, H - p.b + 1.5); c.lineTo(p.l + this.pw, H - p.b + 1.5); c.stroke();
      for (let i = Math.max(0, Math.floor(this.vs) - 1); i <= b; i++) {
        const t = this.tAt(i); if (Math.round(t / ms) % sb !== 0) continue; const x = this.X(i); if (x < p.l + 24 || x > p.l + this.pw - 24) continue;
        const day = T.jnum(t), fut = i > this.n - 1;
        c.fillStyle = fut ? 'rgba(150,200,255,.95)' : 'rgba(200,212,245,.95)'; c.font = '600 11px ui-monospace,Menlo,monospace';
        put(c, ms >= 864e5 ? T.date(t) : T.time(t), x, y0, 'center');
        c.fillStyle = 'rgba(130,146,190,.9)'; c.font = '10px system-ui,sans-serif';
        put(c, ms >= 864e5 ? T.wday(t) : (day !== prevDay ? T.date(t) : ''), x, y0 + 13, 'center');
        c.strokeStyle = 'rgba(255,255,255,.18)'; c.beginPath(); c.moveTo(x, H - p.b + 1.5); c.lineTo(x, H - p.b + 5); c.stroke(); prevDay = day;
      }
    }
    drawLevelTags() {
      const pl = this.d.plan, c = this.ctx, p = this.pad, L = this.layers; if (!L.lv || !pl || !pl.side || pl.side === 'WAIT') return;
      const tag = (v, txt, col) => { if (!v || v < this.lo || v > this.hi) return; const y = this.Y(v); c.fillStyle = col; c.beginPath(); c.roundRect ? c.roundRect(p.l + this.pw + 2, y - 9, p.r - 4, 18, 6) : c.rect(p.l + this.pw + 2, y - 9, p.r - 4, 18); c.fill(); c.fillStyle = '#031'; c.font = '700 10.5px ui-monospace,Menlo,monospace'; c.textAlign = 'left'; c.fillText(T.price(v), p.l + this.pw + 6, y + 4); c.fillStyle = col; c.font = '700 10px system-ui'; c.textAlign = 'left'; c.fillText(txt, p.l + 8, y - 5); };
      tag(pl.entry, 'ENTRY', INFO); tag(pl.stop, 'SL' + (pl.eta && pl.eta.stop ? ' · ~' + T.time(pl.eta.stop) : ''), BEAR);
      ['tp1', 'tp2', 'tp3'].forEach(k => tag(pl[k], k.toUpperCase() + (pl.p && pl.p[k] != null ? ' · ' + Math.round(pl.p[k] * 100) + '%' : '') + (pl.eta && pl.eta[k] ? ' · ~' + T.time(pl.eta[k]) : ''), BULL));
    }
    drawHeader() {
      const c = this.ctx, k = this.hover ? this.hover.k : this.d.klines[this.n - 1]; if (!k) return;
      c.textAlign = 'left'; c.font = '11px ui-monospace,Menlo,monospace'; const ch = (k.c / k.o - 1) * 100, col = k.c >= k.o ? UP : DN;
      let x = this.pad.l + 8; const items = [['O', k.o], ['H', k.h], ['L', k.l], ['C', k.c]];
      items.forEach(([n, v]) => { c.fillStyle = 'rgba(130,146,190,.95)'; c.fillText(n, x, 14); x += 11; c.fillStyle = col; const s = T.price(v); c.fillText(s, x, 14); x += c.measureText(s).width + 12; });
      c.fillStyle = col; c.fillText((ch >= 0 ? '+' : '') + ch.toFixed(2) + '%', x, 14);
      c.fillStyle = 'rgba(200,212,245,.9)'; put(c, T.date(k.t) + '  ' + T.time(k.t), x + 62, 14, 'left');
    }
    drawCross() {
      if (!this.mouse || this.drag && this.drag.moved || T.st('ch_cross') === 'off') return; const c = this.ctx, p = this.pad, { x, y } = this.mouse;
      if (x < p.l || x > p.l + this.pw || y < this.pt || y > this.h - p.b) return;
      const i = Math.round(this.vs + (x - p.l) / this.bw - 0.5), cx = this.X(i);
      c.strokeStyle = T.rgba(T.col.ink, .4); c.setLineDash([3, 3]); c.lineWidth = 1; c.beginPath(); if (T.st('ch_cross') === 'dot') { c.arc(cx, y, 4, 0, 7); } else { c.moveTo(cx, this.pt); c.lineTo(cx, this.h - p.b); c.moveTo(p.l, y); c.lineTo(p.l + this.pw, y); } c.stroke(); c.setLineDash([]);
      if (y < this.pt + this.ph) { const pv = this.hi - (y - this.pt) / this.ph * (this.hi - this.lo); c.fillStyle = '#e9efff'; c.fillRect(p.l + this.pw + 2, y - 9, p.r - 4, 18); c.fillStyle = '#06102a'; c.font = '700 10.5px ui-monospace,monospace'; c.textAlign = 'left'; c.fillText(T.price(pv), p.l + this.pw + 6, y + 4); }
      const t = this.tAt(i), lab = T.date(t) + '  ' + T.time(t); c.font = '700 10.5px ui-monospace,monospace'; const w = c.measureText(lab).width + 14;
      c.fillStyle = '#e9efff'; c.fillRect(T.clamp(cx - w / 2, p.l, p.l + this.pw - w), this.h - p.b + 3, w, 17); c.fillStyle = '#06102a'; put(c, lab, T.clamp(cx, p.l + w / 2, p.l + this.pw - w / 2), this.h - p.b + 15, 'center');
    }
    /* ── tooltip: full date + time range of the candle under the pointer ── */
    showTip() {
      const m = this.mouse, p = this.pad, tip = this.tipEl; this.hover = null;
      if (!m || m.x < p.l || m.x > p.l + this.pw || m.y < this.pt || m.y > this.h - p.b) { tip.hidden = true; return; }
      const i = Math.round(this.vs + (m.x - p.l) / this.bw - 0.5), t = this.tAt(i), ms = this.ms, future = i > this.n - 1;
      let h = `<div class="hd"><b>${T.wday(t)} ${T.date(t, true)}</b><span class="mono">${T.time(t)}→${T.time(t + ms)}</span></div>`;
      const kv = (a, b, cls) => `<div class="kv"><span class="mut">${a}</span><b class="mono ${cls || ''}">${b}</b></div>`;
      if (!future && this.d.klines[i]) {
        const k = this.d.klines[i], live = i === this.n - 1, ch = (k.c / k.o - 1) * 100; this.hover = { k };
        h += `<div class="mb-1">${live ? T.chip('کندل جاری (در حال تشکیل)', 'warn', 'clock') : T.chip('کندل بسته‌شده', 'info')}</div>` + kv('باز', T.price(k.o)) + kv('بالا', T.price(k.h)) + kv('پایین', T.price(k.l)) + kv('بسته', T.price(k.c), ch >= 0 ? 'bull' : 'bear') + kv('تغییر', T.pct(ch), ch >= 0 ? 'bull' : 'bear') + kv('حجم', T.big(k.v));
        const f0 = this.fcAll.find(c => c.t === k.t); if (live && f0 && this.d.fc && this.d.fc.bands) { const j = this.fcAll.indexOf(f0); h += kv('پیش‌بینی بسته‌شدن', T.price(f0.close)) + kv('بازه ۱۰–۹۰٪', T.price(this.d.fc.bands.p10[j]) + ' – ' + T.price(this.d.fc.bands.p90[j])); }
      } else if (future) {
        const j = this.fcAll.findIndex(c => c.t === t), k = this.fcAll[j];
        if (k) { const bd = this.d.fc.bands, sp = this.d.fc.step_prob, last = this.d.klines[this.n - 1].c; this.hover = { k: { o: k.open, h: k.high, l: k.low, c: k.close, t, v: 0 } };
          h += `<div class="mb-1">${T.chip('پیش‌بینی · کندل ' + T.fa(k.step) + ' از ' + T.fa(this.fut.length), 'ai', 'cone')}</div>` + kv('باز (نوعی)', T.price(k.open)) + kv('بالا', T.price(k.high)) + kv('پایین', T.price(k.low)) + kv('بسته (نوعی)', T.price(k.close), k.close >= k.open ? 'bull' : 'bear')
            + kv('بازه ۱۰–۹۰٪', T.price(bd.p10[j]) + ' – ' + T.price(bd.p90[j])) + kv('میانه', T.price(bd.p50[j])) + (sp ? kv('احتمال بالاتر از قیمت فعلی', Math.round(sp[j] * 100) + '٪', sp[j] >= .5 ? 'bull' : 'bear') : '') + kv('فاصله از اکنون', T.dur(t - this.d.klines[this.n - 1].t));
        } else { tip.hidden = true; return; }
      } else { tip.hidden = true; return; }
      const pats = (this.d.pats || []).filter(q => Math.abs(this.idx(q.t) - i) < 0.6);
      pats.forEach(q => { h += `<div style="margin-top:6px;padding-top:5px;border-top:1px solid var(--gl2)"><b class="${T.biasCls(q.bias)}">${q.fa}</b> <span class="mut xs">${q.state_fa}</span><br><span class="xs mut">معتبر تا</span> <span class="mono xs">${T.date(q.valid_until)} ${T.time(q.valid_until)}</span></div>`; });
      tip.innerHTML = h; tip.hidden = false;
      const hw = this.host.clientWidth, tw = tip.offsetWidth, th = tip.offsetHeight;
      tip.style.left = (m.x + 16 + tw > hw ? m.x - tw - 16 : m.x + 16) + 'px'; tip.style.top = T.clamp(m.y - 20, 6, this.h - th - 6) + 'px';
      this.draw();
    }
  }
  T.Chart = Chart;
})(window);
