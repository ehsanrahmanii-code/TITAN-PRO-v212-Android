/* TITAN v2.1 · per-coin trend statement (analysis tab + dashboard block) and "learning from mistakes" page. */
(function (W) {
  'use strict';
  const T = W.TT, S = T.S, V = T.V, TABS = T.TABS, esc = T.esc, view = () => T.$('#view');
  const cls = k => (k === 'up2' || k === 'up1') ? 'bull' : (k === 'dn1' || k === 'dn2') ? 'bear' : 'warn';
  const arw = { up2: '⇈', up1: '↑', flat: '↔', dn1: '↓', dn2: '⇊' };
  const kv = (a, b, c) => `<div class="row sb sm" style="padding:3px 0"><span class="mut">${a}</span><b class="mono ${c || ''}">${b}</b></div>`;
  const f2 = (v, d) => (v == null || !isFinite(v)) ? '—' : Number(v).toFixed(d == null ? 2 : d);

  /* ── data for dashboard / learning (cached, refreshed lazily) ── */
  const X = S.v2 = { trend: null, pm: null, autov: null, t: 0, busy: false };
  T.v2 = {
    async ensure(force) {
      if (X.busy || (!force && Date.now() - X.t < 20000)) return; X.busy = true; X.t = Date.now();
      try {
        const [tr, pm, av] = await Promise.all([`/api/trend/${S.sym}?tf=${S.tf}`, '/api/postmortem', '/api/auto/overview'].map(p => T.api(p).catch(() => null)));
        X.trend = tr; X.pm = pm; X.autov = av;
        if (S.route === 'dash' && V.dash && V.dash.render) V.dash.render();
      } finally { X.busy = false; }
    },
    dashTrend() { return T.panel('روند ' + esc(T.base(S.sym)), 'compass', X.trend && X.trend.ok !== false && !X.trend.error ? trendBody(X.trend, false) : T.skel(1, 120), { sub: `<a data-open="${S.sym}" data-go-sub="trend" style="cursor:pointer;color:var(--info)">جزئیات</a>` }); },
    dashLearn() {
      const pm = X.pm; if (!pm) return T.panel('یادگیری از اشتباه', 'brain', T.skel(1, 120));
      const wr = pm.n ? Math.round(pm.wins / pm.n * 100) : null;
      return T.panel('یادگیری از اشتباه', 'brain', `<div class="kpis" style="grid-template-columns:repeat(3,1fr)">${T.kpi('تحلیل‌شده', T.fa(pm.n || 0), { ic: 'ledger' })}${T.kpi('نرخ برد', wr == null ? '—' : T.fa(wr) + '٪', { ic: 'flag', c: wr >= 50 ? T.col.bull : T.col.bear })}${T.kpi('قانون فعال', T.fa((pm.rules || []).length), { ic: 'shield', c: T.col.warn })}</div>
        <div class="col sm" style="margin-top:10px;gap:6px">${(pm.causes || []).slice(0, 3).map(c => `<div class="row sb"><span>${esc(c.fa)}</span><b class="mono bear">${T.fa(c.n)}×</b></div>`).join('') || '<span class="mut">هنوز ضرری ثبت نشده.</span>'}</div>
        <div class="row" style="margin-top:10px"><button class="btn sm" data-go="learn">${T.ic('brain')}جزئیات</button></div>`);
    }
  };

  T.theme && T.theme.onChange(() => { if (S.route === 'dash' && V.dash && V.dash.render) V.dash.render(); });

  /* ── trend card ── */
  function trendBody(t, full) {
    const c = cls(t.k), lv = t.levels || {}, col = T.col[c];
    const tfs = (t.tfs || []).map(x => `<div class="tfcell tr-${x.k.startsWith('up') ? 'up' : x.k.startsWith('dn') ? 'dn' : 'flat'}" style="--tc:${T.col[cls(x.k)]}"><div class="xs mut">${esc(x.tf_fa)}</div><b>${arw[x.k] || ''} ${esc(x.fa)}</b><div class="xs mut">ADX ${f2(x.adx, 0)} · ${esc(x.power)}${x.prob_up != null ? ' · ↑' + T.fa(Math.round(x.prob_up * 100)) + '٪' : ''}</div></div>`).join('');
    const lvl = a => (a || []).map(v => `<span class="chip mono">${T.price(v)}</span>`).join(' ') || '<span class="mut">—</span>';
    const reasons = (arr, k, ic) => (arr || []).map(x => T.callout(esc(x), k, ic)).join('');
    const head = `<div class="trend-hero"><div>${T.gauge(t.certainty, { size: 92, color: col, label: 'اطمینان' })}</div><div class="col" style="gap:4px"><div class="tname ${c}">${arw[t.k] || ''} روند ${esc(t.trend)}</div>
      <div class="sm mut">${esc(T.base(t.symbol))} · ${T.fa(t.agree ? t.agree.n : 0)} تایم‌فریم · ${t.verdict && t.verdict !== 'WAIT' ? 'سیگنال فعال ' + T.sideBadge(t.verdict) : 'بدون سیگنال تاییدشده'}</div></div></div>
      <div style="margin:12px 0;line-height:2;font-weight:600">${esc(t.main)}</div>`;
    if (!full) return head + `<div class="sm ink2">${esc(t.action)}</div>`;
    return head + `<div class="grid g4" style="margin:12px 0">${tfs}</div>
      <div class="grid g2"><div class="col" style="gap:6px"><div class="ph">${T.ic('ruler')}سطوح تصمیم</div><div class="row wrap" style="gap:6px"><span class="bull sm" style="width:70px">حمایت‌ها</span>${lvl(lv.support)}</div><div class="row wrap" style="gap:6px"><span class="bear sm" style="width:70px">مقاومت‌ها</span>${lvl(lv.resistance)}</div>
        ${kv('ابطال این دید', lv.invalidation ? T.price(lv.invalidation) : '—', 'warn')}${t.alt ? T.callout(esc(t.alt), 'info', 'info') : ''}</div>
        <div class="col" style="gap:8px"><div class="ph">${T.ic('target')}چه کنم؟</div>${T.callout(esc(t.action), c === 'warn' ? 'warn' : 'good', 'target')}${t.forecast ? `<div class="sm mut">${esc(t.forecast)}</div>` : ''}</div></div>
      <div class="ph" style="margin-top:14px">${T.ic('shield')}چرا این میزان اطمینان؟</div><div class="grid g2" style="gap:8px">${reasons(t.why_sure, 'good', 'check')}${reasons(t.why_not, 'warn', 'alert')}</div>
      <div class="xs mut" style="margin-top:8px">${esc(t.disclaimer || '')}</div>`;
  }
  const trendPanel = (D, full) => { const t = D.trend; if (!t) return T.skel(2, 140); if (t.error || t.ok === false) return T.callout('تحلیل روند در دسترس نیست: ' + esc(t.error || ''), 'warn'); return `<div class="glass pn trend-card tr-${t.k.startsWith('up') ? 'up' : t.k.startsWith('dn') ? 'dn' : 'flat'}">${trendBody(t, full)}</div>`; };

  TABS.trend = { title: 'روند', ic: 'compass', build(D) { return trendPanel(D, true); } };
  const sigTab = TABS.signal;
  if (sigTab) { const ob = sigTab.build; sigTab.build = function (D, w) { const t = D.trend; const mini = t && !t.error && t.ok !== false ? `<div style="margin-bottom:14px;cursor:pointer" data-trendtab="1">${trendPanel(D, false)}</div>` : ''; return mini + ob.call(this, D, w); }; }
  document.addEventListener('click', e => { if (e.target.closest('[data-trendtab]')) { const b = T.$('#wk-tabs [data-t="trend"]'); if (b) b.click(); } const g = e.target.closest('[data-go-sub]'); if (g) { S.sub = g.dataset.goSub; T.openCoin(g.dataset.open || S.sym); } });

  /* ── learning page ── */
  const ICON = { win: '✔', wrong_entry: '✕', stop_fast: '⚡', gave_back: '↩', dead_trade: '⏱', flip: '⇄', extended_entry: '⇱', counter_btc: '₿', low_agree: '≠', vol_hot: '🔥', unknown: '?' };
  const RULE = { max_ext_atr: v => `حداکثر فاصله از EMA21: ${v} ATR`, no_market: () => 'ورود فوری ممنوع (فقط پولبک)', btc_align: () => 'بیت‌کوین باید هم‌جهت/خنثی باشد', min_agree: v => `حداقل هم‌سویی ${Math.round(v * 100)}٪`, calm_only: () => 'در نوسان شدید ریسک نصف', early_partial: () => 'خروج پلکانی زودتر', min_vol_ratio: () => 'حجم کافی لازم است' };
  V.learn = {
    async mount() { view().innerHTML = '<div id="ln">' + T.skel(4, 110) + '</div>'; T.on(T.$('#ln'), '[data-open]', 'click', (e, t) => T.openCoin(t.dataset.open)); await this.tick(); },
    async tick() {
      const [pm, av, ac] = await Promise.all(['/api/postmortem', '/api/auto/overview', '/api/exchange'].map(p => T.api(p).catch(() => null))); const el = T.$('#ln'); if (!el || !pm) return;
      const wr = pm.n ? Math.round(pm.wins / pm.n * 100) : null, auto = ac && ac.auto_trade;
      const rules = (pm.rules || []).map(r => `<div class="row" style="align-items:flex-start;gap:10px;padding:6px 0;border-bottom:1px dashed var(--gl2)"><b class="mono" style="width:60px">${esc(T.base(r.symbol))}</b>${T.sideBadge(r.side)}<div class="row wrap" style="flex:1;gap:6px">${Object.keys(RULE).filter(k => r[k]).map(k => `<span class="rulechip">${esc(RULE[k](r[k]))}</span>`).join('')}</div><span class="xs mut">${T.fa(Math.round(r.left_h || 0))} ساعت</span></div>`).join('');
      const causes = (pm.causes || []).map(c => `<div class="row" style="gap:10px;padding:6px 0"><span style="width:26px;text-align:center">${ICON[c.cause] || '•'}</span><div style="flex:1"><div class="sm">${esc(c.fa)}</div><div class="xs mut">اصلاح: ${esc(c.fix || '—')}</div></div><b class="mono bear">${T.fa(c.n)}×</b></div>`).join('');
      const lessons = (pm.lessons || []).slice(0, 16).map(l => `<div class="lesson ${l.win ? 'win' : 'loss'}"><span class="${l.win ? 'bull' : 'bear'}" style="font-size:18px;text-align:center">${ICON[l.cause] || '•'}</span><div><div class="row" style="gap:8px"><b>${esc(T.base(l.symbol))}</b>${T.sideBadge(l.side)}<b class="mono ${l.win ? 'bull' : 'bear'}">${f2(l.r)}R</b></div><div class="sm ink2" style="margin-top:4px">${esc(l.text)}</div>${l.fix ? `<div class="xs mut">⮕ ${esc(l.fix)}</div>` : ''}</div><span class="xs mut">${esc(T.rel(l.t * 1000))}</span></div>`).join('');
      const pool = (arr, title, ic) => arr && arr.length ? T.panel(title, ic, arr.map(x => `<div class="row sb sm" style="padding:3px 0"><span class="mono" style="direction:ltr">${esc(x.key.replace('*|', '').replace('plan:', 'طرح '))}</span><span class="mut">${T.fa(x.n)}× · ${T.fa(x.win)}٪</span><b class="mono ${x.avg_r >= 0 ? 'bull' : 'bear'}">${x.avg_r >= 0 ? '+' : ''}${f2(x.avg_r)}R</b></div>`).join('')) : '';
      const cand = av && (av.candidates || []).length ? T.panel('نامزدهای ثبت خودکار', 'target', av.candidates.slice(0, 9).map(c => `<div class="row" data-open="${c.symbol}" style="cursor:pointer;gap:10px;padding:6px 0;border-bottom:1px dashed var(--gl2)"><b style="width:56px" class="mono">${esc(c.base)}</b>${T.sideBadge(c.side)}${T.grade(c.grade)}<span class="xs" style="flex:1">${c.memory && c.memory.reasons && c.memory.reasons.length ? '<span class="bear">⛔ ' + esc(c.memory.reasons[0]) + '</span>' : c.memory && c.memory.notes && c.memory.notes.length ? '<span class="warn">⚠ ' + esc(c.memory.notes[0]) + '</span>' : '<span class="bull">✔ تکرار اشتباه نیست</span>'}</span></div>`).join(''), { sub: 'بهترین‌ها اول ثبت می‌شوند' }) : '';
      const log = av && (av.log || []).length ? T.panel('گزارش ثبت خودکار', 'list', `<div class="col xs" style="gap:4px;max-height:240px;overflow:auto">${av.log.slice(0, 14).map(x => `<div class="row" style="gap:8px"><span class="${x.ok ? 'bull' : 'mut'}">${x.ok ? '●' : '○'}</span><b class="mono" style="width:50px">${esc(T.base(x.symbol || '*'))}</b><span class="ink2">${esc(x.text || '')}</span></div>`).join('')}</div>`) : '';
      el.innerHTML = `<div class="kpis">${T.kpi('معاملهٔ تحلیل‌شده', T.fa(pm.n || 0), { ic: 'ledger', c: T.col.info })}${T.kpi('نرخ برد', wr == null ? '—' : T.fa(wr) + '٪', { ic: 'flag', c: wr >= 50 ? T.col.bull : T.col.bear })}${T.kpi('قانون فعال', T.fa((pm.rules || []).length), { ic: 'shield', c: T.col.warn })}${T.kpi('ثبت خودکار', auto === false ? '<span class="bear">خاموش</span>' : '<span class="bull">روشن</span>', { ic: 'bolt', c: T.col.ai })}</div>
        <div class="sm mut" style="margin:10px 4px">هر معامله بعد از بسته‌شدن کالبدشکافی می‌شود؛ علت ضرر به قانون تبدیل می‌شود تا دفعهٔ بعد همان اشتباه تکرار نشود.</div>
        <div class="grid g2">${T.panel('قوانین یادگرفته‌شده برای دفعهٔ بعد', 'shield', rules || '<div class="mut sm">هنوز قانونی لازم نشده.</div>')}${T.panel('علت ضررها', 'alert', causes || '<div class="mut sm">هنوز ضرری ثبت نشده.</div>')}</div>
        <div class="grid g2" style="margin-top:14px">${cand}${T.panel('کالبدشکافی آخرین معاملات', 'book', lessons || T.empty('هنوز معامله‌ای بسته نشده.', 'book'))}</div>
        <div class="grid g3" style="margin-top:14px">${pool(pm.worst, 'ضعیف‌ترین ستاپ‌ها', 'down')}${pool(pm.best, 'بهترین ستاپ‌ها', 'up')}${log}</div>`;
    }
  };
})(window);
