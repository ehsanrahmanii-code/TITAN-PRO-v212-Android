"""TITAN Central Core (هسته مرکزی).

Every part of the system (data, analysis, forecast, patterns, governor, learning, AI, paper exchange ...) is
registered here with its role and tasks. The core

* measures every call (count, errors, latency, last run, last error) — via `record`, `track` or `guard`,
* runs optional parts through `guard` so one failing part can never stop the scan loop,
* lets the user switch controllable parts on/off (state persists in YYY/core_state.json),
* describes the pipeline (who feeds whom) and reports the health of the whole system,
* checks that all persistent data lives only inside YYY/.

It has no dependency on other app modules (so everything can import it without cycles).
"""
from __future__ import annotations
import json
import os
import threading
import time
from functools import wraps

from app.config import DATA_DIR, SECRET_DIR

_FILE = DATA_DIR / "core_state.json"
_LOCK = threading.RLock()
_T0 = time.time()

# id: (title, group, role, tasks, depends_on, controllable)
_REG: dict[str, dict] = {}


def _reg(mid: str, title: str, group: str, role: str, tasks: list[str], deps: list[str], controllable: bool = False, icon: str = "cube") -> None:
    _REG[mid] = {"id": mid, "title": title, "group": group, "role": role, "tasks": tasks, "deps": deps, "controllable": controllable, "icon": icon}


GROUPS = {
    "data": "داده و حافظه",
    "analysis": "تحلیل",
    "decision": "تصمیم",
    "learn": "یادگیری و ارزیابی",
    "action": "اجرا و هشدار",
}

_reg("storage", "حافظهٔ YYY", "data", "تنها محل ذخیرهٔ داده‌ها، حافظه، تنظیمات، لاگ‌ها و کلیدها.",
     ["نگه‌داری تنظیمات و لیست پیگیری", "ذخیرهٔ لاگ سیگنال‌ها و نتیجهٔ آن‌ها", "ذخیرهٔ حساب کاغذی و یادگیری حاکم"], [], False, "db")
_reg("market", "داده بازار", "data", "دریافت کندل‌ها، قیمت زنده، دفتر سفارش و مشتقات از چند صرافی با مدار-قطع‌کن.",
     ["کندل ۱۵د/۱س/۴س/۱روز", "قیمت زنده و حجم ۲۴س", "دفتر سفارش، فاندینگ، OI"], ["storage"], False, "wave")
_reg("scanner", "اسکنر", "data", "هماهنگ‌کنندهٔ چرخهٔ اسکن؛ هر ارز × هر تایم‌فریم را به ترتیب به موتورهای تحلیل می‌دهد.",
     ["اسکن پس‌زمینه", "کش کندل‌های بسته", "ثبت پیشرفت و خطاها"], ["market"], False, "radar")
_reg("analysis", "موتور تحلیل", "analysis", "بیش از ۴۰ جزء تکنیکال (روند، مومنتوم، حجم، ساختار، نوسان) با وزن‌دهی بر اساس رژیم بازار.",
     ["امتیاز −۱۰۰ تا +۱۰۰", "ورود/حدضرر/سه هدف", "ناحیه‌های حمایت و مقاومت"], ["scanner"], False, "pulse")
_reg("smc", "ساختار هوشمند (SMC)", "analysis", "اوردر‌بلاک و شکاف ارزش منصفانه؛ همبستگی با بیت‌کوین.",
     ["تشخیص OB/FVG", "تعدیل امتیاز هم‌جهت"], ["analysis"], True, "layers")
_reg("forecast", "پیش‌بینی ۴۸ کندل", "analysis", "شبیه‌سازی احتمالاتی؛ ۴۸ کندل آیندهٔ هر تایم‌فریم با زمان دقیق باز/بسته‌شدن، مخروط احتمال و احتمال رسیدن به اهداف.",
     ["مسیر نوعی ۴۸ کندل", "مخروط ۱۰/۵۰/۹۰٪", "زمان تقریبی رسیدن به TP/SL"], ["analysis"], False, "cone")
_reg("patterns", "الگوها", "analysis", "الگوهای کندلی و ساختاری (دوقلو، سر و شانه، مثلث، گوه، کانال) با بازهٔ زمانی و تاریخ اعتبار.",
     ["شروع/پایان الگو", "اعتبار تا چه زمانی", "سطح ابطال و هدف"], ["analysis"], False, "shapes")
_reg("context", "بافت بازار", "analysis", "وضعیت کلی بازار: نقدینگی، اسپرد، گرایش کل بازار و مشتقات.",
     ["امتیاز بافت", "فیلتر نقدینگی"], ["market"], False, "globe")
_reg("governor", "حاکم مرکزی (Governor)", "decision", "تنها منتشرکنندهٔ سیگنال؛ لبه، حاشیه، اعتماد، وتو، تضاد و R:R را می‌سنجد.",
     ["حکم نهایی LONG/SHORT/WAIT", "دلایل و وتوها", "درجه A تا D"], ["analysis", "forecast", "patterns", "context", "smc"], False, "crown")
_reg("gemini", "هوش مصنوعی Gemini", "decision", "نظر مکمل هوش مصنوعی؛ بدون کلید به‌صورت محلی خلاصه می‌دهد.",
     ["جمع‌بندی فارسی", "یادداشت ریسک"], ["governor"], True, "spark")
_reg("siglog", "ثبت و ارزیابی سیگنال", "learn", "هر سیگنال منتشرشده با ورود/حدضرر ثبت و نتیجهٔ واقعی آن (TP/SL/بازده) سنجیده می‌شود.",
     ["ثبت سیگنال تازه", "تعیین سرنوشت سیگنال", "نرخ برد"], ["governor", "storage"], False, "ledger")
_reg("learn", "یادگیری حاکم", "learn", "ضریب اعتماد هر خانوادهٔ شواهد را از نتایج واقعی به‌آرامی تنظیم می‌کند.",
     ["تنظیم وزن‌ها", "گیت هم‌پوشانی همان‌سمت"], ["siglog"], True, "brain")
_reg("evidence", "شواهد تاریخی", "learn", "رفتار واقعی هر ارز پس از سیگنال‌های مشابه؛ ورودی کیفیت برای حاکم.",
     ["آمار تاریخی هر ارز"], ["market"], True, "flask")
_reg("paper", "صرافی کاغذی", "action", "حساب شبیه‌سازی‌شده با مدیریت ریسک، حدضرر پلکانی و حد روزانه.",
     ["باز و بستن پوزیشن", "سفارش‌های در انتظار", "عملکرد و منحنی سرمایه"], ["market", "storage"], False, "wallet")
_reg("auto", "معامله خودکار", "action", "ثبت خودکار پوزیشن کاغذی فقط وقتی همهٔ گیت‌ها (درجه، R:R، تازگی داده، بافت) تأیید کنند.",
     ["گیت‌های ورود", "خروج در برگشت سیگنال"], ["governor", "paper"], True, "bolt")
_reg("alerts", "هشدارها", "action", "هشدار قیمت و تغییر حکم برای ارزهای پیگیری‌شده.",
     ["بررسی شرط‌ها", "اعلان در رابط"], ["scanner"], True, "bell")

_STATS: dict[str, dict] = {k: {"calls": 0, "errors": 0, "ms_sum": 0.0, "last_ms": 0.0, "last_ok": 0.0, "last_err_t": 0.0, "last_err": ""} for k in _REG}
_EVENTS: list[dict] = []
_DISABLED: set[str] = set()
_LOADED = False


def _load() -> None:
    global _LOADED
    if _LOADED:
        return
    _LOADED = True
    try:
        raw = json.loads(_FILE.read_text(encoding="utf-8"))
        for m in raw.get("disabled", []):
            if m in _REG and _REG[m]["controllable"]:
                _DISABLED.add(m)
    except Exception:                                            # noqa: BLE001
        pass


def _save() -> None:
    try:
        tmp = _FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps({"disabled": sorted(_DISABLED), "ts": time.time()}, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, _FILE)
    except OSError:
        pass


def log(level: str, mod: str, text: str) -> None:
    with _LOCK:
        _EVENTS.append({"t": int(time.time() * 1000), "level": level, "mod": mod, "text": str(text)[:200]})
        del _EVENTS[:-80]


def record(mod: str, ms: float, ok: bool = True, err: str = "") -> None:
    st = _STATS.get(mod)
    if st is None:
        return
    with _LOCK:
        st["calls"] += 1
        st["ms_sum"] += ms
        st["last_ms"] = ms
        if ok:
            st["last_ok"] = time.time()
        else:
            st["errors"] += 1
            st["last_err_t"] = time.time()
            st["last_err"] = str(err)[:160]
            _EVENTS.append({"t": int(time.time() * 1000), "level": "err", "mod": mod, "text": str(err)[:200]})
            del _EVENTS[:-80]


def enabled(mod: str) -> bool:
    _load()
    return mod not in _DISABLED


def set_enabled(mod: str, flag: bool) -> dict:
    _load()
    if mod not in _REG:
        return {"ok": False, "error": "بخش ناشناخته"}
    if not _REG[mod]["controllable"]:
        return {"ok": False, "error": "این بخش هستهٔ سیستم است و خاموش نمی‌شود"}
    with _LOCK:
        (_DISABLED.discard if flag else _DISABLED.add)(mod)
        _save()
    log("info", mod, ("روشن شد" if flag else "خاموش شد") + " توسط هسته")
    return {"ok": True, "mod": mod, "enabled": flag}


def guard(mod: str, fn, *args, default=None, **kw):
    """Run `fn` as part `mod`: skipped when the core switched it off, measured, and never raises."""
    if not enabled(mod):
        return default
    t0 = time.time()
    try:
        out = fn(*args, **kw)
        record(mod, (time.time() - t0) * 1000, True)
        return out
    except Exception as e:                                       # noqa: BLE001
        record(mod, (time.time() - t0) * 1000, False, f"{type(e).__name__}: {e}")
        return default


def track(mod: str):
    """Decorator: measure a function as part `mod` (exceptions are recorded and re-raised)."""
    def deco(fn):
        @wraps(fn)
        def w(*a, **k):
            t0 = time.time()
            try:
                r = fn(*a, **k)
                record(mod, (time.time() - t0) * 1000, True)
                return r
            except Exception as e:                               # noqa: BLE001
                record(mod, (time.time() - t0) * 1000, False, f"{type(e).__name__}: {e}")
                raise
        return w
    return deco


PIPELINE = [
    ("market", "دریافت کندل و قیمت"),
    ("analysis", "تحلیل تکنیکال ۴۰+ جزء"),
    ("smc", "ساختار SMC"),
    ("forecast", "پیش‌بینی ۴۸ کندل"),
    ("patterns", "الگوها و اعتبار زمانی"),
    ("context", "بافت بازار"),
    ("governor", "حکم حاکم مرکزی"),
    ("gemini", "نظر هوش مصنوعی"),
    ("siglog", "ثبت و ارزیابی سیگنال"),
    ("learn", "یادگیری از نتایج"),
    ("paper", "معاملات کاغذی"),
]


def _status(mid: str, st: dict) -> str:
    if mid in _DISABLED:
        return "off"
    if st["calls"] == 0:
        return "idle"
    recent_err = st["last_err_t"] and time.time() - st["last_err_t"] < 600 and st["last_err_t"] >= st["last_ok"]
    rate = st["errors"] / max(1, st["calls"])
    if recent_err and rate > 0.5:
        return "error"
    if recent_err or rate > 0.15:
        return "warn"
    return "ok"


def storage_report() -> dict:
    files, total = [], 0
    try:
        for f in sorted(DATA_DIR.rglob("*")):
            if f.is_file() and f.name != "gemini_api_key.txt" and "secret" not in f.parts:
                sz = f.stat().st_size
                total += sz
                files.append({"name": str(f.relative_to(DATA_DIR)), "size": sz, "mtime": int(f.stat().st_mtime * 1000)})
    except OSError:
        pass
    inside = True
    try:
        for p in (SECRET_DIR, _FILE):
            p.resolve().relative_to(DATA_DIR.resolve())
    except ValueError:
        inside = False
    return {"dir": DATA_DIR.name, "path": str(DATA_DIR), "files": files[:40], "bytes": total, "only_here": inside}


def snapshot(extra: dict | None = None) -> dict:
    _load()
    mods = []
    with _LOCK:
        for mid, meta in _REG.items():
            st = _STATS[mid]
            stt = _status(mid, st)
            avg = st["ms_sum"] / st["calls"] if st["calls"] else 0.0
            mods.append({**meta, "status": stt, "enabled": mid not in _DISABLED, "calls": st["calls"], "errors": st["errors"],
                         "avg_ms": round(avg, 1), "last_ms": round(st["last_ms"], 1), "last_ok": int(st["last_ok"] * 1000) if st["last_ok"] else None,
                         "last_err": st["last_err"], "last_err_at": int(st["last_err_t"] * 1000) if st["last_err_t"] else None})
        events = list(_EVENTS[-40:])[::-1]
    live = [m for m in mods if m["status"] != "off"]
    score = 100.0
    for m in live:
        score -= {"error": 14, "warn": 5}.get(m["status"], 0)
    score = max(0.0, score)
    out = {"modules": mods, "groups": GROUPS, "pipeline": [{"mod": m, "title": t} for m, t in PIPELINE], "events": events,
           "health": round(score), "uptime": int(time.time() - _T0), "now": int(time.time() * 1000), "storage": storage_report()}
    if extra:
        out.update(extra)
    return out
