"""Unified final decision — all layers contribute, one coherent voice.
Governor-aware: when Central Governor has already published/vetoed, this refines action labels.
Layers: multi-TF fusion + market context + grade + planner + Gemini.
"""
from __future__ import annotations
from typing import Any


def final_voice(
    side: str,
    consensus: float,
    grade: dict | None,
    ctx: dict | None,
    plan: dict | None,
    gemini: dict | None = None,
    readiness: dict | None = None,
) -> dict[str, Any]:
    """Produce a single actionable opinion.

    Returns:
        side: LONG | SHORT | WAIT
        confidence: 0-100
        action: ENTER_NOW | PULLBACK | WAIT | AVOID
        reasons: list[str]
        vetoes: list[str]
    """
    grade = grade or {}
    ctx = ctx or {}
    plan = plan or {}
    gemini = gemini or {}
    readiness = readiness or {}

    reasons: list[str] = []
    vetoes: list[str] = []
    conf = float(grade.get("score") or abs(consensus) or 50)
    conf = max(0.0, min(100.0, conf))

    # 1) Hard vetoes from higher structure / context
    if side != "WAIT" and ctx.get("bias") is not None:
        bias = float(ctx["bias"])
        if (side == "LONG" and bias <= -0.55) or (side == "SHORT" and bias >= 0.55):
            vetoes.append("بافت بازار (فاندینگ/OI/احساسات) به‌شدت مخالف است")
            side = "WAIT"

    if not ctx.get("liq_ok", True) and side != "WAIT":
        vetoes.append("نقدینگی/اسپرد نامناسب")
        side = "WAIT"

    # 2) Grade gate
    g = str(grade.get("grade") or "D")
    if side != "WAIT" and g == "D":
        vetoes.append(f"درجه سیگنال {g} برای ورود کافی نیست")
        side = "WAIT"
    elif side != "WAIT" and g == "C":
        reasons.append("درجه C: ورود کم‌حجم و محتاطانه")

    # 3) Planner expected R
    best_r = None
    if plan:
        for key in ("recommended", "best", "market"):
            p = plan.get(key) or plan.get(side.lower()) or {}
            if isinstance(p, dict) and p.get("exp_r") is not None:
                best_r = float(p["exp_r"])
                break
        if best_r is not None and best_r < 0.9 and side != "WAIT":
            vetoes.append(f"امید ریاضی طرح ورود ضعیف است ({best_r:.2f}R)")
            side = "WAIT"
        elif best_r is not None and best_r >= 1.4:
            reasons.append(f"امید ریاضی طرح ورود مناسب ({best_r:.2f}R)")

    # 4) Readiness / live performance feedback
    if readiness.get("block_auto"):
        vetoes.append("کارنامه زنده فعلاً اجازه ترید خودکار نمی‌دهد")
        # do not force WAIT for manual view, only note it

    # 5) Gemini soft influence (never sole authority)
    g_side = (gemini.get("side") or gemini.get("bias") or "").upper()
    if g_side in ("LONG", "SHORT", "WAIT") and side != "WAIT":
        if g_side == side:
            conf = min(100, conf + 4)
            reasons.append("نظر Gemini هم‌راستا است")
        elif g_side == "WAIT":
            conf = max(0, conf - 6)
            reasons.append("Gemini احتیاط می‌کند")
        else:
            conf = max(0, conf - 10)
            reasons.append("Gemini مخالف جهت است")

    # 6) Action label
    if side == "WAIT":
        action = "WAIT" if not vetoes else "AVOID"
    else:
        # prefer pullback if consensus is only moderate
        if abs(consensus) < 28 and best_r and best_r < 1.8:
            action = "PULLBACK"
            reasons.append("اجماع متوسط → ترجیح ورود در پولبک")
        else:
            action = "ENTER_NOW"
            reasons.append("اجماع و طرح ورود هم‌راستا هستند")

    if grade.get("note"):
        reasons.append(str(grade["note"])[:120])

    return {
        "side": side,
        "confidence": round(conf, 1),
        "action": action,
        "grade": g,
        "consensus": round(float(consensus), 1),
        "exp_r": round(best_r, 2) if best_r is not None else None,
        "reasons": reasons[:6],
        "vetoes": vetoes[:6],
        "ctx_bias": ctx.get("bias"),
        "gemini_used": bool(gemini.get("side") or gemini.get("text")),
    }
