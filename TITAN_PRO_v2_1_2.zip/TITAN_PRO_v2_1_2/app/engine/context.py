"""Market context: derivatives (funding, open interest, long/short), order book and sentiment turned into ONE decision factor.

Before v3.3 this data was display-only. Now `evaluate()` produces a bias in [-1, +1] (bullish > 0) plus liquidity facts that
(1) shift the multi-timeframe consensus, (2) add/remove grade points, (3) gate automatic trading in the policy, and
(4) are shown in the dashboard with the reason for every part. Every part is optional: a missing source contributes 0
(it never invents a view), and the total is divided by the weight of ALL parts so thin data yields a small bias.
"""
from __future__ import annotations

import threading
import time
from concurrent.futures import ThreadPoolExecutor

from app.data.market import fetch_depth, fetch_derivs, fetch_global

W = {"funding": 1.0, "ls": 0.6, "oi": 1.0, "book": 0.7, "sent": 0.5, "basis": 0.4}
W_TOTAL = sum(W.values())
MIN_DEPTH_USD = 40_000.0           # min(bid, ask) liquidity within 1 % of mid
MAX_SPREAD_PCT = 0.15

_LOCK = threading.Lock()
_STORE: dict[str, dict] = {}
_META = {"ts": 0.0, "n": 0, "ok": 0}


def _clip(x: float, lo: float = -1.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


def evaluate(derivs: dict | None, depth: dict | None, chg24: float | None, glob: dict | None) -> dict:
    """Pure function. Returns {"bias", "parts", "liq_ok", "crowd", "coverage", ...}."""
    d, b, g = derivs or {}, depth or {}, glob or {}
    parts: list[dict] = []

    def part(key: str, v: float, text: str):
        parts.append({"k": key, "v": round(_clip(v), 3), "w": W[key], "t": text})

    if d.get("ok"):
        apr = float(d.get("funding_apr", 0.0) or 0.0)
        if abs(apr) > 12:                                     # ≈ the 0.01 %/8 h baseline is normal
            v = -_clip((abs(apr) - 12) / 60) * (1 if apr > 0 else -1)
            part("funding", v, f"فاندینگ {apr:+.0f}٪ سالانه → " + ("لانگ‌ها شلوغ‌اند (ریسک ریزش)" if apr > 0 else "شورت‌ها شلوغ‌اند (ریسک شورت‌اسکوییز)"))
        r = d.get("ls_buy")
        if r is not None and abs(float(r) - 0.5) > 0.04:
            r = float(r)
            part("ls", -_clip((r - 0.5) / 0.12), f"نسبت حساب‌های لانگ {r * 100:.0f}٪ → " + ("ازدحام لانگ" if r > 0.5 else "ازدحام شورت"))
        oi = d.get("oi_chg_24h")
        if oi is not None and abs(float(oi)) >= 2 and chg24 is not None and abs(chg24) >= 0.5:
            oi = float(oi); up = chg24 > 0; k = min(1.0, abs(oi) / 8)
            if oi > 0:
                part("oi", (0.7 if up else -0.7) * k, f"OI {oi:+.1f}٪ و قیمت {chg24:+.1f}٪ → " + ("پول تازه، تایید صعود" if up else "فشار فروش تازه، تایید نزول"))
            else:
                part("oi", (-0.3 if up else 0.3) * k, f"OI {oi:+.1f}٪ و قیمت {chg24:+.1f}٪ → " + ("صعود با بسته‌شدن پوزیشن (ضعیف)" if up else "تخلیه/اشباع فروش"))
        bs = d.get("basis_pct")
        if bs is not None and abs(float(bs)) > 0.12:
            part("basis", _clip(float(bs) / 0.4) * -0.5, f"بیس {float(bs):+.2f}٪ → " + ("بازار آتی داغ" if float(bs) > 0 else "بازار آتی سرد"))
    if b.get("ok"):
        imb = float(b.get("imb_1pct", 0.0))
        if abs(imb) >= 0.1:
            part("book", _clip(imb / 0.4), f"عمق دفتر سفارش ±۱٪: {imb:+.2f} → " + ("خریدار غالب" if imb > 0 else "فروشنده غالب"))
    fng = g.get("fng")
    if fng is not None:
        fng = float(fng)
        if fng <= 25:
            part("sent", _clip((25 - fng) / 25) * 0.9, f"ترس شدید بازار ({fng:.0f}) → فرصت واکنشی صعودی")
        elif fng >= 75:
            part("sent", -_clip((fng - 75) / 25) * 0.9, f"طمع شدید بازار ({fng:.0f}) → احتیاط در خرید")

    bias = sum(p["v"] * p["w"] for p in parts) / W_TOTAL
    liq = {}
    if b.get("ok"):
        depth_min = min(float(b.get("bid_usd_1pct", 0)), float(b.get("ask_usd_1pct", 0)))
        liq = {"spread_pct": b.get("spread_pct"), "depth_usd": round(depth_min), "imb": b.get("imb_1pct")}
        liq["ok"] = float(b.get("spread_pct", 0)) <= MAX_SPREAD_PCT and depth_min >= MIN_DEPTH_USD
    crowd = None
    funding_p = next((p for p in parts if p["k"] == "funding"), None)
    if funding_p and abs(funding_p["v"]) >= 0.5:
        crowd = "longs" if funding_p["v"] < 0 else "shorts"
    return {"bias": round(_clip(bias), 3), "parts": parts, "liq": liq, "liq_ok": liq.get("ok", True), "crowd": crowd,
            "coverage": round(sum(p["w"] for p in parts) / W_TOTAL, 2), "fng": g.get("fng"), "fng_label": g.get("fng_label"),
            "btc_dom": g.get("btc_dom"), "funding_apr": d.get("funding_apr"), "oi_usd": d.get("oi_usd"),
            "oi_chg_24h": d.get("oi_chg_24h"), "ls_buy": d.get("ls_buy"), "basis_pct": d.get("basis_pct"), "ts": time.time()}


def refresh(symbols: list[str], chg_of, max_seconds: float = 25.0) -> None:
    """Refresh context for the watchlist (parallel, time-boxed, failure tolerant). chg_of(sym) -> 24h change % or None."""
    t0 = time.time()
    try:
        glob = fetch_global()
    except Exception:                                         # noqa: BLE001
        glob = {}

    def one(sym: str):
        if time.time() - t0 > max_seconds:
            return sym, None
        try:
            return sym, evaluate(fetch_derivs(sym), fetch_depth(sym), chg_of(sym), glob)
        except Exception:                                     # noqa: BLE001
            return sym, None
    ok = 0
    with ThreadPoolExecutor(max_workers=6) as ex:
        for sym, res in ex.map(one, symbols):
            if res is not None:
                with _LOCK:
                    _STORE[sym] = res
                ok += 1
    with _LOCK:
        _META.update(ts=time.time(), n=len(symbols), ok=ok)


def get(sym: str, max_age: float = 900.0) -> dict | None:
    with _LOCK:
        c = _STORE.get(sym)
    return c if c and time.time() - c["ts"] <= max_age else None


def overview() -> dict:
    with _LOCK:
        items = {k: dict(v) for k, v in _STORE.items() if time.time() - v["ts"] <= 900}
        meta = dict(_META)
    glob = fetch_global() if items else {}
    return {"global": glob, "meta": meta, "symbols": {k: {"bias": v["bias"], "crowd": v["crowd"], "liq_ok": v["liq_ok"], "coverage": v["coverage"]} for k, v in items.items()}}
