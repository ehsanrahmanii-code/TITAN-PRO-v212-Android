"""Post-mortem + mistake memory.

Every closed paper trade (and every resolved published signal) is dissected: WHY did it win or lose? The answer is
stored as a short lesson AND as a concrete rule that the auto-trader must obey the next time the same situation
appears, so the same mistake is not repeated:

* cooldown after a loss on the same coin+side, growing with the loss streak (the exact same setup is blocked,
  a clearly different setup is allowed with reduced risk);
* per-coin tightening derived from the cause (extended entry → smaller allowed extension, counter-BTC → BTC must
  agree, never-worked entry → pull-back only, low agreement → higher agreement needed);
* pooled statistics per (side, regime, grade) and (side, plan): clearly losing setups are blocked / down-sized;
* rules decay by time and are released after two wins in a row on that coin+side.

State is one small JSON file inside the data folder (no database, nothing heavy on the scan path).
"""
from __future__ import annotations
import json
import os
import threading
import time

from app.config import DATA_DIR

_FILE = DATA_DIR / "postmortem.json"
_LOCK = threading.RLock()
_ST: dict | None = None

LESSONS_MAX = 120
PROCESSED_MAX = 600
RULE_TTL = 48 * 3600
BASE_COOLDOWN = 90 * 60
MAX_COOLDOWN = 12 * 3600

CAUSES = {
    "win": "معامله موفق",
    "wrong_entry": "قیمت هرگز به نفع پوزیشن حرکت نکرد (ورود زودهنگام یا جهت اشتباه)",
    "stop_fast": "حدضرر خیلی زود خورد (نوسان از فاصلهٔ حدضرر بیشتر بود)",
    "gave_back": "پوزیشن سود خوبی داشت ولی برگشت و ضرر شد (خروج/تریل دیر)",
    "dead_trade": "بازار حرکت نکرد و معامله با محدودیت زمانی بسته شد",
    "flip": "تحلیل چندتایم‌فریم برعکس شد و زود خارج شد",
    "extended_entry": "ورود وقتی قیمت از میانگین کشیده شده بود (تعقیب حرکت)",
    "counter_btc": "ورود برخلاف جهت بیت‌کوین",
    "low_agree": "هم‌سویی اندیکاتورها پایین بود",
    "vol_hot": "نوسان بازار در اوج بود",
    "unknown": "علت مشخصی پیدا نشد (ضرر عادی در چارچوب ریسک)",
}
FIXES = {
    "wrong_entry": "ورود فقط در پولبک (سفارش لیمیت) و نه ورود فوری",
    "stop_fast": "حدضرر بر اساس ATR بازتر و حجم پوزیشن کمتر",
    "gave_back": "خروج پلکانی زودتر و تریل بعد از TP1",
    "dead_trade": "ورود فقط با حجم/نوسان کافی",
    "flip": "صبر برای تایید تایم‌فریم بالاتر",
    "extended_entry": "حداکثر فاصلهٔ مجاز از EMA21 کمتر شد",
    "counter_btc": "ورود فقط وقتی بیت‌کوین هم‌جهت یا خنثی است",
    "low_agree": "حداقل هم‌سویی اندیکاتورها بالاتر رفت",
    "vol_hot": "ریسک در نوسان شدید نصف می‌شود",
}
PRIORITY = ["extended_entry", "counter_btc", "low_agree", "vol_hot", "flip", "gave_back", "dead_trade", "stop_fast", "wrong_entry"]


def _defaults() -> dict:
    return {"lessons": [], "memory": {}, "rules": {}, "processed": [], "sig_processed": [], "ts": 0.0}


def _load() -> dict:
    global _ST
    if _ST is not None:
        return _ST
    st = _defaults()
    try:
        raw = json.loads(_FILE.read_text(encoding="utf-8"))
        if isinstance(raw, dict):
            for k in st:
                if k in raw and isinstance(raw[k], type(st[k])):
                    st[k] = raw[k]
    except Exception:                                        # noqa: BLE001
        pass
    _ST = st
    return st


def _save(st: dict) -> None:
    st["lessons"] = st["lessons"][-LESSONS_MAX:]
    st["processed"] = st["processed"][-PROCESSED_MAX:]
    st["sig_processed"] = st["sig_processed"][-PROCESSED_MAX:]
    st["ts"] = time.time()
    tmp = _FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(st, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, _FILE)


def reset_for_tests() -> None:
    global _ST
    with _LOCK:
        _ST = None


def _base(sym: str) -> str:
    return str(sym).replace("USDT", "")


def _mem(st: dict, key: str) -> dict:
    return st["memory"].setdefault(key, {"n": 0.0, "w": 0.0, "l": 0.0, "sum_r": 0.0, "streak": 0, "last_loss_t": 0.0,
                                         "last_loss_fp": "", "last_tags": [], "sn": 0.0, "sw": 0.0})


def fingerprint(plan: str, regime: str, grade: str) -> str:
    return f"{plan or '-'}|{regime or '-'}|{grade or '-'}"


# ── analysis of ONE closed trade ───────────────────────────────────────────────────────────────────────────────
def analyze_trade(h: dict) -> dict:
    """Return {tags, cause, win, r, text, fix}. Pure function (no state)."""
    r = float(h.get("r") or 0.0)
    entry, stop0 = float(h.get("entry") or 0), float(h.get("stop0") or 0)
    risk_pct = abs(entry - stop0) / entry * 100 if entry and stop0 else 0.0
    mfe_r = (float(h.get("mfe") or 0) / risk_pct) if risk_pct else 0.0
    mae_r = (abs(float(h.get("mae") or 0)) / risk_pct) if risk_pct else 0.0
    dur_min = max(0.0, (float(h.get("closed_at") or 0) - float(h.get("opened_at") or 0)) / 60)
    reason = str(h.get("reason") or "")
    meta = h.get("meta") or {}
    d = 1 if h.get("side") == "LONG" else -1
    win = r > 0.05 or float(h.get("pnl") or 0) > 0
    out = {"win": bool(win), "r": round(r, 2), "mfe_r": round(mfe_r, 2), "mae_r": round(mae_r, 2), "dur_min": round(dur_min), "reason": reason}
    if win:
        out.update(tags=["win"], cause="win", text=f"موفق ({r:+.2f}R): طرح «{h.get('plan') or '—'}» با درجه {h.get('grade') or '—'} کار کرد؛ در شرایط مشابه تکرار می‌شود.", fix="")
        return out
    tags = []
    if float(meta.get("ext_atr") or 0) > 2.0 and meta.get("mode") != "limit":
        tags.append("extended_entry")
    btc = meta.get("btc_cons")
    if btc is not None and float(btc) * d < -20 and h.get("symbol") != "BTCUSDT":
        tags.append("counter_btc")
    if meta.get("agree") is not None and float(meta["agree"]) < 0.62:
        tags.append("low_agree")
    if meta.get("vol_hot"):
        tags.append("vol_hot")
    if reason == "signal_flip":
        tags.append("flip")
    if reason == "time":
        tags.append("dead_trade")
    if mfe_r >= 1.0 and r < 0:
        tags.append("gave_back")
    if reason in ("stop", "liquidation"):
        if mfe_r < 0.3:
            tags.append("wrong_entry")
        if dur_min < 45:
            tags.append("stop_fast")
    cause = next((t for t in PRIORITY if t in tags), "unknown")
    if not tags:
        tags = ["unknown"]
    fix = FIXES.get(cause, "")
    out.update(tags=tags, cause=cause,
               text=f"ضرر ({r:+.2f}R) · {CAUSES[cause]}" + (f" · بیشترین سود لحظه‌ای {mfe_r:.1f}R" if mfe_r >= 0.3 else "") + (f" · مدت {dur_min:.0f} دقیقه" if dur_min else ""),
               fix=fix)
    return out


# ── state update from one analysed trade ───────────────────────────────────────────────────────────────────────
def _apply(st: dict, h: dict, a: dict) -> None:
    sym, side = h.get("symbol", ""), h.get("side", "")
    now = float(h.get("closed_at") or time.time())
    fp = fingerprint(h.get("plan"), h.get("regime"), h.get("grade"))
    keys = [f"{sym}|{side}", f"*|{side}|{h.get('regime') or '-'}|{h.get('grade') or '-'}", f"*|{side}|plan:{h.get('plan') or '-'}"]
    for i, k in enumerate(keys):
        m = _mem(st, k)
        m["n"] += 1
        m["sum_r"] += a["r"]
        if a["win"]:
            m["w"] += 1
            if i == 0:
                m["streak"] = 0
        else:
            m["l"] += 1
            if i == 0:
                m["streak"] += 1
                m["last_loss_t"] = now
                m["last_loss_fp"] = fp
                m["last_tags"] = a["tags"]
    rules = st["rules"].setdefault(f"{sym}|{side}", {})
    m0 = st["memory"][keys[0]]
    if a["win"]:
        if m0["streak"] == 0 and m0["w"] >= 2 and rules:
            last2 = [x for x in st["lessons"] if x.get("key") == keys[0]][-1:]
            if last2 and last2[-1].get("win"):               # two wins in a row release the tightening
                st["rules"].pop(f"{sym}|{side}", None)
        return
    meta = h.get("meta") or {}
    exp = now + RULE_TTL
    for t in a["tags"]:
        if t == "extended_entry":
            cur = float(rules.get("max_ext_atr", 99))
            rules["max_ext_atr"] = round(min(cur, max(0.6, float(meta.get("ext_atr") or 2.0) * 0.7)), 2)
        elif t == "counter_btc":
            rules["btc_align"] = True
        elif t in ("wrong_entry", "stop_fast"):
            rules["no_market"] = True
        elif t == "low_agree":
            rules["min_agree"] = round(min(0.85, max(float(rules.get("min_agree", 0)), float(meta.get("agree") or 0.6) + 0.06)), 2)
        elif t == "vol_hot":
            rules["calm_only"] = True
        elif t == "gave_back":
            rules["early_partial"] = True
        elif t == "dead_trade":
            rules["min_vol_ratio"] = 1.0
    if rules:
        rules["exp"] = exp
        rules["why"] = a["cause"]


def ingest(history: list[dict]) -> int:
    """Process closed paper trades not seen before. Returns how many were analysed."""
    n = 0
    with _LOCK:
        st = _load()
        seen = set(st["processed"])
        for h in history:
            hid = h.get("id")
            if not hid or hid in seen:
                continue
            a = analyze_trade(h)
            _apply(st, h, a)
            st["lessons"].append({"id": hid, "t": float(h.get("closed_at") or time.time()), "symbol": h.get("symbol"), "side": h.get("side"),
                                  "key": f"{h.get('symbol')}|{h.get('side')}", "plan": h.get("plan"), "grade": h.get("grade"), "regime": h.get("regime"),
                                  "source": h.get("source"), "win": a["win"], "r": a["r"], "cause": a["cause"], "tags": a["tags"],
                                  "text": a["text"], "fix": a["fix"], "mfe_r": a["mfe_r"], "dur_min": a["dur_min"], "reason": a["reason"]})
            st["processed"].append(hid)
            seen.add(hid)
            n += 1
        if n:
            _save(st)
    return n


def ingest_signals(entries: list[dict]) -> int:
    """Published signals that resolved (hit TP1 / SL) teach the memory too — even when no trade was taken."""
    n = 0
    with _LOCK:
        st = _load()
        seen = set(st["sig_processed"])
        for e in entries:
            eid, hit = e.get("id"), e.get("hit")
            if not eid or eid in seen or hit not in ("TP1", "SL"):
                continue
            m = _mem(st, f"{e.get('symbol')}|{e.get('verdict')}")
            m["sn"] += 1
            m["sw"] += 1 if hit == "TP1" else 0
            st["sig_processed"].append(eid)
            seen.add(eid)
            n += 1
        if n:
            _save(st)
    return n


# ── gate used by the auto-trader ───────────────────────────────────────────────────────────────────────────────
def check(symbol: str, side: str, grade: str = "", regime: str = "", plan: str = "", meta: dict | None = None, now: float | None = None) -> dict:
    """{ok, risk_mult, reasons[], notes[]} — ok=False means 'this is a repeat of a known mistake'."""
    now = now or time.time()
    meta = meta or {}
    reasons: list[str] = []
    notes: list[str] = []
    mult = 1.0
    with _LOCK:
        st = _load()
        m = st["memory"].get(f"{symbol}|{side}")
        fp = fingerprint(plan, regime, grade)
        if m and m["streak"] >= 1:
            cd = min(MAX_COOLDOWN, BASE_COOLDOWN * (2 ** (m["streak"] - 1)))
            left = m["last_loss_t"] + cd - now
            if left > 0:
                if m["last_loss_fp"] == fp:
                    reasons.append(f"تکرار همان ستاپ بعد از ضرر ({_base(symbol)} {side}، {m['streak']} ضرر پیاپی) — {int(left / 60)} دقیقهٔ دیگر مجاز می‌شود")
                else:
                    mult *= 0.6
                    notes.append(f"ضرر اخیر روی {_base(symbol)} {side}؛ ستاپ فرق دارد → ریسک ۶۰٪")
        if m and m["n"] >= 4 and m["sum_r"] / m["n"] < -0.4:
            mult *= 0.5
            notes.append(f"میانگین {m['sum_r'] / m['n']:+.2f}R روی {m['n']:.0f} معاملهٔ {_base(symbol)} {side} → ریسک نصف")
        if m and m["sn"] >= 4 and m["sw"] / m["sn"] < 0.25:
            mult *= 0.6
            notes.append("سیگنال‌های اخیر این ارز/سمت اغلب به حدضرر خورده‌اند → ریسک ۶۰٪")
        for k, label in ((f"*|{side}|{regime or '-'}|{grade or '-'}", f"ستاپ {side}/{regime or '-'}/درجه {grade or '-'}"), (f"*|{side}|plan:{plan or '-'}", f"طرح «{plan}»")):
            g = st["memory"].get(k)
            if g and g["n"] >= 6 and g["w"] / g["n"] < 0.30 and g["sum_r"] / g["n"] < -0.2:
                reasons.append(f"{label} در {g['n']:.0f} معاملهٔ اخیر فقط {g['w'] / g['n'] * 100:.0f}٪ برد داشته")
            elif g and g["n"] >= 4 and g["sum_r"] / g["n"] < -0.4:
                mult *= 0.7
                notes.append(f"{label} میانگین {g['sum_r'] / g['n']:+.2f}R دارد → ریسک ۷۰٪")
        rl = st["rules"].get(f"{symbol}|{side}")
        if rl and rl.get("exp", 0) > now:
            d = 1 if side == "LONG" else -1
            if "max_ext_atr" in rl and float(meta.get("ext_atr") or 0) > rl["max_ext_atr"] and meta.get("mode") != "limit":
                reasons.append(f"قانون یادگرفته‌شده: فاصله از EMA21 باید ≤ {rl['max_ext_atr']} ATR باشد (الان {float(meta.get('ext_atr') or 0):.1f})")
            if rl.get("no_market") and meta.get("mode") == "market":
                reasons.append("قانون یادگرفته‌شده: ورود فوری ممنوع؛ فقط پولبک/شکست تاییدشده")
            if rl.get("btc_align") and meta.get("btc_cons") is not None and float(meta["btc_cons"]) * d < 0 and symbol != "BTCUSDT":
                reasons.append("قانون یادگرفته‌شده: بیت‌کوین باید هم‌جهت یا خنثی باشد")
            if "min_agree" in rl and meta.get("agree") is not None and float(meta["agree"]) < rl["min_agree"]:
                reasons.append(f"قانون یادگرفته‌شده: هم‌سویی ≥ {rl['min_agree'] * 100:.0f}٪ لازم است")
            if rl.get("calm_only") and meta.get("vol_hot"):
                mult *= 0.5
                notes.append("نوسان شدید و ضرر قبلی ناشی از آن → ریسک نصف")
    return {"ok": not reasons, "risk_mult": round(max(0.25, mult), 3), "reasons": reasons, "notes": notes}


def status(limit: int = 40) -> dict:
    """Everything the dashboard needs: lessons, active rules, worst/best setups, headline numbers."""
    with _LOCK:
        st = _load()
        now = time.time()
        les = list(st["lessons"])[-limit:][::-1]
        rules = [{"symbol": k.split("|")[0], "side": k.split("|")[1], **{kk: vv for kk, vv in v.items()}, "left_h": round((v.get("exp", 0) - now) / 3600, 1)}
                 for k, v in st["rules"].items() if v.get("exp", 0) > now]
        pooled = []
        for k, v in st["memory"].items():
            if v["n"] >= 3:
                pooled.append({"key": k, "n": int(v["n"]), "win": round(v["w"] / v["n"] * 100), "avg_r": round(v["sum_r"] / v["n"], 2), "streak": v["streak"]})
        pooled.sort(key=lambda x: x["avg_r"])
        causes: dict[str, int] = {}
        for x in st["lessons"]:
            if not x.get("win"):
                causes[x["cause"]] = causes.get(x["cause"], 0) + 1
        losses = [x for x in st["lessons"] if not x.get("win")]
        wins = [x for x in st["lessons"] if x.get("win")]
        return {"n": len(st["lessons"]), "wins": len(wins), "losses": len(losses), "lessons": les, "rules": rules, "worst": pooled[:6], "best": pooled[::-1][:6],
                "causes": [{"cause": k, "fa": CAUSES.get(k, k), "n": v, "fix": FIXES.get(k, "")} for k, v in sorted(causes.items(), key=lambda kv: -kv[1])],
                "ts": st["ts"]}
