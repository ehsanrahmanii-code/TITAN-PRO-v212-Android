"""Live signal track record: every NEW directional multi-timeframe verdict is logged with its grade and price, and
its real outcome (side-adjusted % move after 1h / 4h / 24h) is filled in later from live prices. This is the honest
answer to "do the A/B-grade signals actually work on my coins?"."""
from __future__ import annotations
import json
import os
import threading
import time

from app.config import DATA_DIR, SIGLOG_MAX

_FILE = DATA_DIR / "siglog.json"
_LOCK = threading.RLock()
_STATE: dict = {"loaded": False, "entries": [], "last": {}}
HORIZONS = (("1h", 3600), ("4h", 14400), ("24h", 86400))
MAX = SIGLOG_MAX


def _load() -> None:
    if _STATE["loaded"]:
        return
    try:
        raw = json.loads(_FILE.read_text(encoding="utf-8"))
        _STATE["entries"] = raw.get("entries", []) if isinstance(raw, dict) else []
        _STATE["last"] = raw.get("last", {}) if isinstance(raw, dict) else {}
    except Exception:                                      # noqa: BLE001
        _STATE["entries"], _STATE["last"] = [], {}
    _STATE["loaded"] = True


def _save() -> None:
    tmp = _FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps({"entries": _STATE["entries"][-MAX:], "last": _STATE["last"]}, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, _FILE)


def entries_copy() -> list[dict]:
    with _LOCK:
        _load()
        return [dict(e) for e in _STATE["entries"]]


def current(sym: str) -> str | None:
    """Verdict of the signal that is live for `sym` right now (None / WAIT when none)."""
    with _LOCK:
        _load()
        return _STATE["last"].get(sym)


def active_entry(sym: str, side: str) -> dict | None:
    """The logged entry of the signal that started the current LONG/SHORT run of `sym` (None when the verdict is not live)."""
    with _LOCK:
        _load()
        if _STATE["last"].get(sym) != side:
            return None
        for e in reversed(_STATE["entries"]):
            if e["symbol"] == sym and e["verdict"] == side:
                return {k: e.get(k) for k in ("id", "t", "price", "stop", "tp1", "hit", "grade", "mfe_pct", "mae_pct")}
    return None


def is_new(sym: str, verdict: str) -> bool:
    """True when `verdict` would be logged as a new entry on the next tick (lets the caller attach stop/TP only then)."""
    with _LOCK:
        _load()
        return verdict in ("LONG", "SHORT") and _STATE["last"].get(sym) != verdict


def tick(rows: dict[str, dict], prices: dict[str, float], now: float | None = None) -> int:
    """rows: symbol -> {verdict, grade, cons, stop?, tp1?}. Returns number of new entries.

    Stores entry price and optional planned SL/TP so later evaluation can measure
    whether price hit stop before target (not just horizon returns)."""
    now = now or time.time()
    new = 0
    with _LOCK:
        _load()
        for sym, f in rows.items():
            v = f.get("verdict", "WAIT")
            px = prices.get(sym)
            if not px:
                continue
            prev = _STATE["last"].get(sym)
            if v in ("LONG", "SHORT") and prev != v:
                entry = {
                    "id": f"{sym}-{int(now)}", "t": int(now), "symbol": sym, "verdict": v,
                    "grade": f.get("grade", "—"), "cons": f.get("cons", 0.0), "price": px,
                    "stop": f.get("stop"), "tp1": f.get("tp1"), "res": {},
                    "mfe_pct": 0.0, "mae_pct": 0.0, "hit": None,
                    # snapshots for lightweight learning (governor families)
                    "edge": f.get("edge"), "margin": f.get("margin"),
                    "support": f.get("support"), "contradiction": f.get("contradiction"),
                    "components": f.get("components") or {},
                    "confidence": f.get("confidence"),
                }
                _STATE["entries"].append(entry)
                new += 1
            _STATE["last"][sym] = v if v in ("LONG", "SHORT") else "WAIT"
        dirty = new > 0
        for e in _STATE["entries"]:
            px = prices.get(e["symbol"])
            if not px:
                continue
            d = 1 if e["verdict"] == "LONG" else -1
            move = (px / e["price"] - 1) * 100 * d
            e["mfe_pct"] = max(float(e.get("mfe_pct") or 0), move)
            e["mae_pct"] = min(float(e.get("mae_pct") or 0), move)
            # Path outcome vs planned levels (best-effort; no intra-bar path)
            if e.get("hit") is None and e.get("stop") and e.get("tp1"):
                if d > 0:
                    if px <= e["stop"]:
                        e["hit"] = "SL"; dirty = True
                    elif px >= e["tp1"]:
                        e["hit"] = "TP1"; dirty = True
                else:
                    if px >= e["stop"]:
                        e["hit"] = "SL"; dirty = True
                    elif px <= e["tp1"]:
                        e["hit"] = "TP1"; dirty = True
            for k, sec in HORIZONS:
                if k not in e["res"] and now - e["t"] >= sec:
                    e["res"][k] = round(move, 3); dirty = True
        _STATE["entries"] = _STATE["entries"][-MAX:]
        if dirty:
            _save()
    return new


def view(limit: int = 60) -> dict:
    with _LOCK:
        _load()
        es = list(_STATE["entries"])
    by: dict = {}
    for e in es:
        r = e["res"].get("4h")
        if r is None:
            continue
        g = by.setdefault(e["grade"], {"n": 0, "win": 0, "sum": 0.0})
        g["n"] += 1; g["win"] += r > 0; g["sum"] += r
    stats = {g: {"n": v["n"], "win": round(v["win"] / v["n"] * 100, 1), "avg": round(v["sum"] / v["n"], 3)} for g, v in by.items() if v["n"]}
    tot = [e["res"]["4h"] for e in es if "4h" in e["res"]]
    hits = [e for e in es if e.get("hit")]
    sl_n = sum(1 for e in hits if e["hit"] == "SL")
    tp_n = sum(1 for e in hits if e["hit"] == "TP1")
    path = {"resolved": len(hits), "sl": sl_n, "tp1": tp_n,
            "sl_rate": round(sl_n / len(hits) * 100, 1) if hits else None,
            "tp1_rate": round(tp_n / len(hits) * 100, 1) if hits else None}
    return {"entries": es[-limit:][::-1], "stats": stats, "resolved": len(tot), "total": len(es),
            "path": path,
            "overall": {"win": round(sum(1 for r in tot if r > 0) / len(tot) * 100, 1), "avg": round(sum(tot) / len(tot), 3)} if tot else None}
