"""Multi-timeframe fusion: weighted consensus, higher-TF veto, coherent verdict + narrative."""
from __future__ import annotations
import threading
from collections import OrderedDict
from typing import Any
import pandas as pd

from app.config import TF_WEIGHT, SIDE_THRESHOLD, FORECAST_CANDLES
from app.analysis.technicals import analyze
from app.analysis.forecast import build_forecast
from app.analysis.grade import fuse, grade_from
from app.engine.governor import govern

REGIME_FA = {"trend": "روندی", "range": "رنج", "neutral": "گذار", "unknown": "نامشخص"}
SIDE_SHORT = {"LONG": "خرید", "SHORT": "فروش", "WAIT": "انتظار"}
SIDE_FA = {"LONG": "خرید (LONG)", "SHORT": "فروش (SHORT)", "WAIT": "انتظار"}


# ── memo: one analysis per (coin, timeframe, last closed candle, live price) ────────────────────────────────────
# The scanner, the auto-trader, the matrix and /api/deep all need the same per-timeframe result; before v2.0 each of
# them recomputed it (≈0.1 s per timeframe), which was the main reason deep analysis appeared late on screen.
_MEMO: "OrderedDict[tuple, Any]" = OrderedDict()
_MEMO_LOCK = threading.Lock()
_MEMO_MAX = 900


def _df_key(df: pd.DataFrame):
    try:
        last = df["open_time"].iloc[-1]
        return (int(last.value) if hasattr(last, "value") else str(last), len(df), round(float(df["close"].iloc[-1]), 10))
    except Exception:                                        # noqa: BLE001
        return (id(df), len(df))


def _memo_get(key):
    with _MEMO_LOCK:
        v = _MEMO.get(key)
        if v is not None:
            _MEMO.move_to_end(key)
        return v


def _memo_put(key, val):
    with _MEMO_LOCK:
        _MEMO[key] = val
        _MEMO.move_to_end(key)
        while len(_MEMO) > _MEMO_MAX:
            _MEMO.popitem(last=False)
    return val


def cached_analyze(df: pd.DataFrame, symbol: str, tf: str, price: float | None = None, force_side: str | None = None):
    key = ("a", symbol, tf, _df_key(df), None if price is None else float(price), force_side)
    hit = _memo_get(key)
    if hit is not None:
        return hit
    kw = {"force_side": force_side} if force_side else {}
    return _memo_put(key, analyze(df, symbol, tf, price=price, **kw))


def cached_forecast(df: pd.DataFrame, side: str, tf: str, symbol: str, levels: dict | None):
    """build_forecast (48 future candles + exact times + validity window) memoised per candle/price/levels."""
    lv = tuple(sorted((k, float(v)) for k, v in levels.items())) if levels else None
    key = ("f", symbol, tf, side, _df_key(df), lv)
    hit = _memo_get(key)
    if hit is not None:
        return dict(hit)
    return dict(_memo_put(key, build_forecast(df, side, tf, symbol, levels)))


def memo_clear() -> None:
    with _MEMO_LOCK:
        _MEMO.clear()


def deep_analyze(frames: dict[str, pd.DataFrame], symbol: str, primary_tf: str = "1h",
                 prices: dict[str, float] | None = None, ctx: dict | None = None) -> dict[str, Any]:
    prices = prices or {}
    sigs, fcs = {}, {}
    for tf, df in frames.items():
        if df is None or len(df) < 60:
            continue
        s = cached_analyze(df, symbol, tf, price=prices.get(tf))
        sigs[tf] = s
        lv = {"entry": s.entry, "stop": s.stop, "tp1": s.tp1, "tp2": s.tp2, "tp3": s.tp3} if s.side != "WAIT" else None
        fcs[tf] = cached_forecast(df, s.side, tf, symbol, lv)
    if not sigs:
        return {"symbol": symbol, "primary_tf": primary_tf, "signal": None, "all_tf": {}, "verdict": "WAIT",
                "consensus_score": 0, "conviction": 0, "agreement": "mixed", "regime": "unknown", "narrative": "داده کافی نیست"}

    consensus, side, note = fuse({t: x.score for t, x in sigs.items()}, (ctx or {}).get("bias", 0.0))
    wsum = sum(TF_WEIGHT.get(t, .2) for t in sigs)
    sides = [s.side for s in sigs.values()]
    ln, sn = sides.count("LONG"), sides.count("SHORT")
    agreement = ("strong_long" if ln >= 3 else "strong_short" if sn >= 3 else
                 "lean_long" if ln > sn else "lean_short" if sn > ln else "mixed")
    aligned = sum(TF_WEIGHT.get(t, .2) for t, s in sigs.items() if (s.score > 10) == (consensus > 0) and abs(s.score) > 10) / wsum
    conviction = round(min(0.97, 0.55 * min(1, abs(consensus) / 70) + 0.45 * aligned), 3)

    ptf = primary_tf if primary_tf in sigs else next(iter(sigs))
    prim = sigs[ptf]
    sd = {t: x.to_dict() for t, x in sigs.items()}
    _plans: dict[str, Any] = {prim.side: prim}

    def plan_for(side_c: str):
        if side_c not in _plans:
            _plans[side_c] = cached_analyze(frames[ptf], symbol, ptf, price=prices.get(ptf), force_side=side_c)
        return _plans[side_c]

    def grade_fn(side_c: str) -> dict:
        """Grade computed for the governor's own candidate side with a real plan for that side."""
        pl = plan_for(side_c)
        sdd = dict(sd)
        sdd[ptf] = pl.to_dict()
        gr_ = grade_from(sdd, fcs, side_c, consensus, ptf, ctx)
        if isinstance(gr_, dict):
            gr_["rr"] = pl.risk_reward
        return gr_

    # Central Governor — sole publisher (grade follows ITS candidate side, not the legacy fuse side)
    gov = govern(sd, fcs, ctx, {}, symbol=symbol, grade_fn=grade_fn)
    pub_side = gov.get("side") or "WAIT"
    if not gov.get("published"):
        pub_side = "WAIT"

    plan = plan_for(pub_side) if pub_side in ("LONG", "SHORT") else prim
    regime = prim.regime
    pf = fcs[ptf]
    if pub_side in ("LONG", "SHORT"):                               # re-run path statistics for the plan actually proposed
        pf = cached_forecast(frames[ptf], pub_side, ptf, symbol,
                             {"entry": plan.entry, "stop": plan.stop, "tp1": plan.tp1, "tp2": plan.tp2, "tp3": plan.tp3})
        fcs[ptf] = pf
        sd[ptf] = plan.to_dict()
    gr = gov.get("grade") if pub_side != "WAIT" and isinstance(gov.get("grade"), dict) else grade_from(sd, fcs, side, consensus, ptf, ctx)

    parts = [f"رژیم {REGIME_FA.get(regime, regime)} · اجماع وزنی {consensus:+.0f} → {SIDE_FA[side]}"]
    if note:
        parts.append(note)
    if gov.get("vetoes"):
        parts.append("وتوی حاکم: " + " · ".join(gov["vetoes"][:3]))
    if gov.get("reasons"):
        parts.append("حاکم: " + " · ".join(gov["reasons"][:3]))
    # V84-hardened diagnostics
    if gov.get("published") and gov.get("support") is not None:
        parts.append(f"پشتیبانی {gov.get('support')} · تضاد {gov.get('contradiction', 0):.0%}")
    parts.append("تایم‌فریم‌ها: " + " | ".join(f"{t}: {SIDE_SHORT[s.side]} {s.score:+.0f}" for t, s in sigs.items()))
    n_fc = int(pf.get("n_future") or pf.get("valid_bars") or FORECAST_CANDLES)
    parts.append(f"احتمال صعود ({ptf}، {n_fc} کندل) {pf['prob_up'] * 100:.0f}٪ · حرکت میانه {pf['expected_move_pct']:+.2f}٪")
    if pub_side != "WAIT":
        parts.append(f"ورود {plan.entry} · حدضرر {plan.stop} · اهداف {plan.tp1}/{plan.tp2}/{plan.tp3} · R:R {plan.risk_reward}")
    if ctx and ctx.get("parts"):
        parts.append(f"بافت بازار {ctx['bias']:+.2f}: " + " · ".join(p_["t"] for p_ in sorted(ctx["parts"], key=lambda x: -abs(x["v"] * x["w"]))[:2]))
    if prim.reasons:
        parts.append("دلایل: " + " · ".join(prim.reasons[:4]))

    # If governor publishes WAIT, keep plan levels but mark verdict WAIT for consistency
    out_signal = plan.to_dict()
    if pub_side == "WAIT" and out_signal.get("side") in ("LONG", "SHORT"):
        out_signal = dict(out_signal)
        out_signal["side"] = "WAIT"
        out_signal["warnings"] = list(out_signal.get("warnings") or []) + list(gov.get("vetoes") or [])

    # both-side plans + the price triggers that would turn a WAIT into a trade (so a WAIT is never an empty card)
    plans: dict = {}
    for sd_ in ("LONG", "SHORT"):
        try:
            pl = prim if prim.side == sd_ else (plan if plan.side == sd_ else plan_for(sd_))
            plans[sd_] = {"entry": pl.entry, "stop": pl.stop, "tp1": pl.tp1, "tp2": pl.tp2, "tp3": pl.tp3, "rr": pl.risk_reward,
                          "entry_zone": (pl.levels or {}).get("entry_zone")}
        except Exception:                                                  # noqa: BLE001
            continue
    lv0, px0 = prim.levels or {}, float(prim.entry or 0)
    res_up = sorted(x for x in (lv0.get("resistance") or []) if px0 and x > px0 * 1.0005)
    sup_dn = sorted((x for x in (lv0.get("support") or []) if px0 and x < px0 * 0.9995), reverse=True)
    triggers = {"LONG": {"above": res_up[0] if res_up else (prim.indicators or {}).get("donch_hi")},
                "SHORT": {"below": sup_dn[0] if sup_dn else (prim.indicators or {}).get("donch_lo")}}
    return {"plans": plans, "triggers": triggers, "symbol": symbol, "primary_tf": ptf, "signal": out_signal, "primary": prim.to_dict(),
            "forecast": pf, "all_tf": {t: s.to_dict() for t, s in sigs.items()}, "all_forecasts": fcs, "grade": gr,
            "consensus_score": round(consensus, 1), "conviction": conviction, "verdict": pub_side, "veto": note,
            "agreement": agreement, "regime": regime, "narrative": " — ".join(parts),
            "governor": gov, "fuse_side": side,
            "ctx": ctx, "long_count": ln, "short_count": sn, "wait_count": sides.count("WAIT")}
