"""Walk-forward check of the signal engine on the coin's own history.
At every step only candles up to that bar are visible; the trade is entered at the NEXT candle's open,
exits replay the paper-exchange rules (staged 40/35/25 targets, break-even stop after TP1, stop-first
when stop and target share a candle) and costs (fees + slippage) are charged in R."""
from __future__ import annotations
import numpy as np
import pandas as pd

from app.config import PARTIALS, FEE_TAKER, SLIPPAGE
from app.analysis.technicals import analyze


def _replay(df: pd.DataFrame, j0: int, side: str, entry: float, stop: float, tps: tuple, horizon: int) -> dict:
    d = 1.0 if side == "LONG" else -1.0
    risk = abs(entry - stop)
    H, L, C = df["high"].values, df["low"].values, df["close"].values
    end = min(len(df), j0 + horizon)
    stage, R, rem_used = 0, 0.0, 0.0
    mfe = mae = 0.0
    out, bars = "open", end - j0
    for j in range(j0, end):
        hi, lo = (H[j], L[j]) if side == "LONG" else (-L[j], -H[j])           # work in "long" space
        e, s, t = d * entry, d * stop, [d * x for x in tps]
        mfe = max(mfe, (hi - e) / risk); mae = min(mae, (lo - e) / risk)
        cur_stop = e if stage >= 1 else s
        # Conservative same-bar rule: if both stop and a target are tagged in
        # one candle, assume stop was hit first (path inside the bar unknown).
        stop_hit = lo <= cur_stop
        tp_hit = any(stage == k and hi >= t[k] for k in range(3))
        if stop_hit and tp_hit:
            if stage == 0:
                R += -1.0; out = "stop"
            else:
                out = f"BE بعد از TP{stage}"
            bars, stage = j - j0 + 1, 9
            break
        if stop_hit:
            if stage == 0:
                R += -1.0; out = "stop"
            else:
                out = f"BE بعد از TP{stage}"
            bars, stage = j - j0 + 1, 9
            break
        for k in range(3):
            if stage == k and hi >= t[k]:
                R += PARTIALS[k] * (t[k] - e) / risk
                rem_used += PARTIALS[k]; stage = k + 1
        if stage == 3:
            out, bars = "TP3", j - j0 + 1
            break
    if stage < 9 and stage != 3:                                          # horizon reached -> mark to market
        R += (1 - rem_used) * d * (C[end - 1] - entry) / risk
        out = f"زمان‌پایان" if stage == 0 else f"زمان‌پایان بعد از TP{stage}"
    if stage == 3 or (stage not in (0, 9) and out.startswith("TP")):
        out = "TP3"
    cost = 2 * (FEE_TAKER + SLIPPAGE) * entry / risk
    return {"r": R - cost, "gross": R, "out": out, "bars": bars, "mfe": mfe, "mae": mae}


def run(df: pd.DataFrame, symbol: str, tf: str, start: int = 150, step: int = 3, horizon: int = 32) -> dict:
    n = len(df)
    if n < start + 40:
        return {"error": "تاریخچه برای بک‌تست کافی نیست", "n": 0}
    trades, busy = [], -1
    for i in range(start, n - 2, step):
        if i <= busy:
            continue
        sub = df.iloc[:i + 1]
        sig = analyze(sub, symbol, tf, price=float(sub["close"].iloc[-1]))
        if sig.side == "WAIT":
            continue
        entry = float(df["open"].iloc[i + 1])
        dx = entry - sig.entry
        stop, tps = sig.stop + dx, tuple(x + dx for x in (sig.tp1, sig.tp2, sig.tp3))
        if abs(entry - stop) <= entry * 1e-5:
            continue
        res = _replay(df, i + 1, sig.side, entry, stop, tps, horizon)
        busy = i + res["bars"]
        trades.append({"t": int(df["open_time"].iloc[i + 1].timestamp() * 1000), "side": sig.side, "score": sig.score,
                       "conf": sig.confidence, "entry": float(f"{entry:.8g}"), "r": round(res["r"], 3), "out": res["out"],
                       "bars": int(res["bars"]), "mfe": round(res["mfe"], 2), "mae": round(res["mae"], 2)})
    first_px, last_px = float(df["close"].iloc[start]), float(df["close"].iloc[-1])
    bh = (last_px / first_px - 1) * 100
    if not trades:
        return {"n": 0, "trades": [], "equity": [], "buy_hold_pct": round(bh, 2), "bars_tested": n - start,
                "note": "در این بازه سیگنال معتبری صادر نشد"}
    r = np.array([t["r"] for t in trades])
    wins, losses = r[r > 0], r[r <= 0]
    pf = float(wins.sum() / abs(losses.sum())) if len(losses) and losses.sum() != 0 else float("inf") if len(wins) else 0.0
    eq = np.cumsum(r)
    peak = np.maximum.accumulate(np.r_[0.0, eq])[1:]
    dd = float((peak - eq).max()) if len(eq) else 0.0
    streak = cur = 0
    for x in r:
        cur = cur + 1 if x <= 0 else 0
        streak = max(streak, cur)
    t_stat = float(r.mean() / (r.std(ddof=1) / np.sqrt(len(r)))) if len(r) > 2 and r.std(ddof=1) > 0 else 0.0

    def agg(sel):
        x = np.array([t["r"] for t in sel])
        return {"n": len(x), "win": round(float((x > 0).mean() * 100), 1) if len(x) else 0, "avg_r": round(float(x.mean()), 3) if len(x) else 0}
    buckets = {"36-50": [t for t in trades if abs(t["score"]) < 50], "50-70": [t for t in trades if 50 <= abs(t["score"]) < 70],
               "70+": [t for t in trades if abs(t["score"]) >= 70]}
    return {"n": len(trades), "win_rate": round(float((r > 0).mean() * 100), 1), "avg_r": round(float(r.mean()), 3),
            "total_r": round(float(r.sum()), 2), "pf": round(pf, 2) if np.isfinite(pf) else 99.0, "max_dd_r": round(dd, 2),
            "worst_streak": int(streak), "t_stat": round(t_stat, 2), "significant": bool(len(r) >= 20 and t_stat >= 1.64),
            "avg_bars": round(float(np.mean([t["bars"] for t in trades])), 1), "buy_hold_pct": round(bh, 2),
            "bars_tested": n - start, "equity": [round(float(x), 3) for x in eq],
            "by_side": {"LONG": agg([t for t in trades if t["side"] == "LONG"]), "SHORT": agg([t for t in trades if t["side"] == "SHORT"])},
            "by_score": {k: agg(v) for k, v in buckets.items()}, "trades": trades[-40:]}
