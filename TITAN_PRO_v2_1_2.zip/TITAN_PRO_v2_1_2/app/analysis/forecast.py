"""Probabilistic projection v2.

* Filtered historical simulation: bootstrap of volatility-standardised returns, EWMA volatility that
  mean-reverts to the long-run level over the horizon, shrunk momentum drift + pull to EMA21.
* Every simulated path also gets intrabar wicks (bootstrapped from the coin's own history), so we can
  answer first-passage questions honestly: "does price touch TP1 before the stop?".
* The drawn future candles are the *typical* path (the simulated path closest to the median path whose
  roughness is also typical) - it looks like a real chart yet follows the expected trajectory.
Deterministic per candle (seeded by symbol + last bar). It is a distribution, not a promise.
"""
from __future__ import annotations
import zlib
from typing import Any
import numpy as np
import pandas as pd

from app.config import FORECAST_CANDLES, MC_PATHS, PARTIALS, EDGE_HORIZON, TF_MS, SIGNAL_VALID_BARS

QS = (5, 10, 25, 50, 75, 90, 95)
QN = tuple(f"p{q}" for q in QS)


def _r(x: float) -> float:
    """Round to 8 significant digits (round(x, 8) destroys SHIB/PEPE-class prices)."""
    return float(f"{float(x):.8g}")


def _atr_arr(df) -> float:
    h, l, c = df["high"].values, df["low"].values, df["close"].values
    tr = np.maximum(h[1:] - l[1:], np.maximum(np.abs(h[1:] - c[:-1]), np.abs(l[1:] - c[:-1])))
    return float(np.mean(tr[-14:])) if len(tr) >= 14 else float(np.mean(tr)) if len(tr) else 0.0


def simulate(df: pd.DataFrame, n_ahead: int = FORECAST_CANDLES, n_paths: int = MC_PATHS, seed_key: str = "") -> dict | None:
    if df is None or len(df) < 40:
        return None
    close = df["close"].values.astype(float)
    op = df["open"].values.astype(float)
    hi_h = df["high"].values.astype(float)
    lo_h = df["low"].values.astype(float)
    lr = np.diff(np.log(np.clip(close, 1e-12, None)))[-300:]
    lam, var, zs = 0.94, float(np.var(lr[:20])) + 1e-12, []
    for r in lr:
        zs.append(r / np.sqrt(var))
        var = lam * var + (1 - lam) * r * r
    sigma = float(np.sqrt(var))
    long_sigma = float(np.std(lr)) + 1e-12
    z = np.clip(np.array(zs[20:]), -4, 4)
    z = (z - z.mean()) / (z.std() + 1e-12)

    last = float(close[-1])
    ema21 = float(pd.Series(close).ewm(span=21, adjust=False).mean().iloc[-1])
    mu = 0.25 * float(np.mean(lr[-40:])) + 0.15 * float(np.mean(lr[-10:]))
    # how directional is the recent path? (t-stat of the log-price slope over 60 bars) -> persistent drift, weak pull to the mean
    yy = np.log(np.clip(close[-60:], 1e-12, None)); xx = np.arange(len(yy), dtype=float)
    slope, icpt = np.polyfit(xx, yy, 1)
    res_sd = float(np.std(yy - (slope * xx + icpt))) + 1e-12
    tstat = slope / (res_sd / (np.std(xx) * np.sqrt(len(xx)) + 1e-12))
    trend = float(np.clip(abs(tstat) / 12.0, 0.0, 1.0))
    mu_keep = 0.92 + 0.055 * trend
    pull0 = 0.035 * (1.0 - 0.8 * trend)
    seed = zlib.crc32(f"{seed_key}|{df['open_time'].iloc[-1]}".encode()) & 0x7FFFFFFF
    rng = np.random.default_rng(seed)

    steps = np.arange(n_ahead)
    sig_i = long_sigma + (sigma - long_sigma) * (0.96 ** steps)            # vol term-structure
    shocks = z[rng.integers(0, len(z), size=(n_paths, n_ahead))] * sig_i[None, :]
    tgt = np.log(max(ema21, 1e-12))
    cur = np.full(n_paths, np.log(last))
    logp = np.empty((n_paths, n_ahead))
    for i in range(n_ahead):
        cur = cur + mu * (mu_keep ** i) + pull0 * (0.9 ** i) * (tgt - cur) + shocks[:, i]
        logp[:, i] = cur
    closes = np.exp(logp)
    opens = np.concatenate([np.full((n_paths, 1), last), closes[:, :-1]], axis=1)

    # intrabar wicks bootstrapped from the coin's own last 250 candles, scaled to the current vol
    k = slice(-250, None)
    cc = np.clip(close[k], 1e-12, None)
    uw_h = np.clip((hi_h[k] - np.maximum(op[k], close[k])) / cc, 0, None)
    lw_h = np.clip((np.minimum(op[k], close[k]) - lo_h[k]) / cc, 0, None)
    scale = float(np.clip(sig_i.mean() / long_sigma, 0.6, 1.8))
    uw = uw_h[rng.integers(0, len(uw_h), size=(n_paths, n_ahead))] * scale
    lw = lw_h[rng.integers(0, len(lw_h), size=(n_paths, n_ahead))] * scale
    highs = np.maximum(opens, closes) * (1 + uw)
    lows = np.minimum(opens, closes) * (1 - lw)

    # typical path: closest to the median trajectory AND with typical roughness
    med = np.median(logp, axis=0)
    d = (((logp - med[None, :]) / (sig_i[None, :] * np.sqrt(steps + 1)[None, :])) ** 2).sum(axis=1)
    step_ret = np.diff(np.concatenate([np.full((n_paths, 1), np.log(last)), logp], axis=1), axis=1)
    rough = step_ret.std(axis=1) / (sig_i.mean() + 1e-12)
    cand = np.argsort(d)[:max(12, n_paths // 8)]
    pick = int(cand[np.argmin(np.abs(rough[cand] - 1.0))])
    return {"last": last, "sigma": sigma, "n": n_ahead, "opens": opens, "highs": highs, "lows": lows, "closes": closes,
            "pick": pick, "atr": _atr_arr(df), "mu": mu, "ema21": ema21}


def _stage_sim(sim: dict, side: str, entry: float, stop: float, tps: tuple, fr=PARTIALS) -> dict:
    """Vectorised replay of the paper-exchange exit logic on every simulated path.
    Conservative: if stop and a target are inside the same candle, the stop is assumed first."""
    H, L, C = sim["highs"], sim["lows"], sim["closes"]
    P, N = C.shape
    d = 1.0 if side == "LONG" else -1.0
    risk = abs(entry - stop)
    if risk <= 0:
        return {}
    r_of = [d * (tp - entry) / risk for tp in tps]
    alive = np.ones(P, bool)
    stage = np.zeros(P, int)
    R = np.zeros(P)
    first_tp1 = np.full(P, -1); first_tp2 = np.full(P, -1); first_tp3 = np.full(P, -1); first_stop = np.full(P, -1)
    hit1 = np.zeros(P, bool); hit2 = np.zeros(P, bool); hit3 = np.zeros(P, bool); stopped0 = np.zeros(P, bool)
    for i in range(N):
        if side == "LONG":
            adverse = np.where(stage >= 1, L[:, i] <= entry, L[:, i] <= stop)
            fav = [H[:, i] >= tp for tp in tps]
        else:
            adverse = np.where(stage >= 1, H[:, i] >= entry, H[:, i] >= stop)
            fav = [L[:, i] <= tp for tp in tps]
        hs = alive & adverse
        stopped0 |= hs & (stage == 0)
        first_stop = np.where(hs & (stage == 0) & (first_stop < 0), i, first_stop)
        R += np.where(hs & (stage == 0), -1.0, 0.0)
        alive &= ~hs
        m = alive & (stage == 0) & fav[0]
        R += np.where(m, fr[0] * r_of[0], 0.0); first_tp1 = np.where(m & (first_tp1 < 0), i, first_tp1)
        hit1 |= m; stage = np.where(m, 1, stage)
        m = alive & (stage == 1) & fav[1]
        R += np.where(m, fr[1] * r_of[1], 0.0); first_tp2 = np.where(m & (first_tp2 < 0), i, first_tp2); hit2 |= m; stage = np.where(m, 2, stage)
        m = alive & (stage == 2) & fav[2]
        R += np.where(m, fr[2] * r_of[2], 0.0); first_tp3 = np.where(m & (first_tp3 < 0), i, first_tp3); hit3 |= m; stage = np.where(m, 3, stage); alive &= ~m
    rem = np.where(stage == 0, 1.0, np.where(stage == 1, 1 - fr[0], np.where(stage == 2, 1 - fr[0] - fr[1], 0.0)))
    R += np.where(alive, rem * d * (C[:, -1] - entry) / risk, 0.0)
    ev = float(R.mean())
    var = float(R.var()) + 1e-9
    def _med(a):
        a = a[a >= 0]
        return int(np.median(a)) + 1 if len(a) else None
    t1 = first_tp1[first_tp1 >= 0]
    return {"t_tp2": _med(first_tp2), "t_tp3": _med(first_tp3), "t_stop": _med(first_stop), "horizon": int(N),"p_tp1": round(float(hit1.mean()), 3), "p_tp2": round(float(hit2.mean()), 3), "p_tp3": round(float(hit3.mean()), 3),
            "p_stop": round(float(stopped0.mean()), 3), "p_open": round(float((alive & (stage == 0)).mean()), 3),
            "p_win": round(float((R > 0).mean()), 3), "ev_r": round(ev, 3), "med_r": round(float(np.median(R)), 3),
            "worst_r": round(float(np.percentile(R, 5)), 3), "best_r": round(float(np.percentile(R, 95)), 3),
            "kelly": round(float(np.clip(ev / var, 0, 1)), 3),
            "t_tp1": int(np.median(t1)) + 1 if len(t1) else None,
            "r_tp": [round(x, 2) for x in r_of]}


def level_probs(sim: dict | None, side: str, levels: dict | None) -> dict | None:
    if not sim or side not in ("LONG", "SHORT") or not levels:
        return None
    try:
        e, s = float(levels["entry"]), float(levels["stop"])
        tps = (float(levels["tp1"]), float(levels["tp2"]), float(levels["tp3"]))
    except (KeyError, TypeError, ValueError):
        return None
    h = max(4, min(int(sim["n"]), EDGE_HORIZON))
    cut = dict(sim, n=h, opens=sim["opens"][:, :h], highs=sim["highs"][:, :h], lows=sim["lows"][:, :h], closes=sim["closes"][:, :h])
    return _stage_sim(cut, side, e, s, tps) or None


def _pack(sim: dict) -> dict:
    C, H, L, O = sim["closes"], sim["highs"], sim["lows"], sim["opens"]
    last, n = sim["last"], sim["n"]
    q = np.percentile(C, QS, axis=0)
    prob_up = float(np.mean(C[:, -1] > last))
    step_prob = (C > last).mean(axis=0)
    p = sim["pick"]
    candles = [{"step": i + 1, "open": _r(O[p, i]), "close": _r(C[p, i]), "high": _r(H[p, i]), "low": _r(L[p, i])} for i in range(n)]
    ret = (C[:, -1] / last - 1) * 100
    lo_e, hi_e = np.percentile(ret, [1, 99])
    if hi_e - lo_e < 1e-9:
        lo_e, hi_e = lo_e - 0.5, hi_e + 0.5
    edges = np.linspace(lo_e, hi_e, 26)
    counts, _ = np.histogram(np.clip(ret, lo_e, hi_e), bins=edges)
    return {"candles": candles, "bands": {k: [_r(x) for x in row] for k, row in zip(QN, q)},
            "prob_up": prob_up, "sigma_pct": sim["sigma"] * 100, "step_prob": [round(float(x), 3) for x in step_prob],
            "hist": {"edges": [round(float(x), 3) for x in edges], "counts": [int(c) for c in counts]},
            "range": {"hi": _r(np.median(H.max(axis=1))), "lo": _r(np.median(L.min(axis=1)))},
            "p_up10": round(float(np.mean(ret > 1.0)), 3), "p_dn10": round(float(np.mean(ret < -1.0)), 3)}


def monte_carlo(df: pd.DataFrame, n_ahead: int = FORECAST_CANDLES, n_paths: int = MC_PATHS, seed_key: str = "") -> dict | None:
    sim = simulate(df, n_ahead, n_paths, seed_key)
    return _pack(sim) if sim else None


def forecast_summary(df: pd.DataFrame, signal_side: str, n_ahead: int = FORECAST_CANDLES, seed_key: str = "",
                     levels: dict | None = None) -> dict[str, Any]:
    sim = simulate(df, n_ahead=n_ahead, seed_key=seed_key)
    if not sim:
        return {"direction": "neutral", "expected_move_pct": 0.0, "alignment": "neutral", "candles": [], "prob_up": 0.5,
                "confidence": 0.0, "bands": {}, "cone": {}, "n": n_ahead, "step_prob": [], "hist": {}, "range": {}, "edge": None}
    mc = _pack(sim)
    last = float(df["close"].iloc[-1])
    b = mc["bands"]
    end = b["p50"][-1]
    move = (end - last) / last * 100
    pu = mc["prob_up"]
    direction = "bullish" if pu >= 0.57 else "bearish" if pu <= 0.43 else "sideways"
    if signal_side == "LONG" and direction == "bullish": al = "aligned"
    elif signal_side == "SHORT" and direction == "bearish": al = "aligned"
    elif signal_side == "WAIT": al = "neutral"
    else: al = "divergent"
    return {"direction": direction, "expected_move_pct": round(move, 3), "prob_up": round(pu, 3),
            "confidence": round(min(1.0, abs(pu - 0.5) * 2.2), 3), "alignment": al, "sigma_pct": round(mc["sigma_pct"], 3),
            "candles": mc["candles"], "bands": b, "n": n_ahead, "step_prob": mc["step_prob"], "hist": mc["hist"],
            "range": mc["range"], "p_up10": mc["p_up10"], "p_dn10": mc["p_dn10"],
            "cone": {"upper": max(b["p90"]), "lower": min(b["p10"]), "mid": end},
            "edge": level_probs(sim, signal_side, levels)}


# ── time stamping (every future candle carries its own open/close time) ─────
def stamp_fc_times(fc: dict | None, last_open_ms: int | None, tf: str = "1h") -> dict | None:
    """Give each projected candle its open/close time.

    `last_open_ms` MUST be the open time of the LAST CLOSED candle that the projection was built on
    (the first projected candle is the one that opens right after it)."""
    if not fc or not isinstance(fc, dict):
        return fc
    ms = TF_MS.get(tf, 3_600_000)
    candles = fc.get("candles") or []
    if not candles:
        return fc
    base = int(last_open_ms or 0)
    if base <= 0:
        import time
        base = (int(time.time() * 1000) // ms - 1) * ms
    out = []
    for i, c in enumerate(candles):
        cc = dict(c) if isinstance(c, dict) else {"close": c}
        cc["t"] = base + ms * (i + 1)
        cc["t_close"] = cc["t"] + ms
        out.append(cc)
    fc = dict(fc)
    fc["candles"] = out
    fc["band_t"] = [c["t"] for c in out]
    return fc


def attach_validity(fc: dict | None, tf: str = "1h", n_ahead: int | None = None) -> dict | None:
    """Explicit validity window of a projection: it starts when the last closed candle ended and expires
    when the projected horizon is over. Also tells how far ahead the *trade* statistics reach."""
    if not fc or not isinstance(fc, dict):
        return fc
    ms = TF_MS.get(tf, 3_600_000)
    cs = fc.get("candles") or []
    n = int(n_ahead or len(cs) or 8)
    fc = dict(fc)
    fc["tf"] = tf
    cur = bool(cs and cs[0].get("current"))
    if cs and cs[0].get("t"):
        fc["valid_from"] = int(cs[1 if cur and len(cs) > 1 else 0]["t"])          # first FUTURE candle
        fc["valid_until"] = int(cs[-1]["t_close"])
    else:
        import time
        now = int(time.time() * 1000)
        fc["valid_from"], fc["valid_until"] = now, now + ms * n
    fc["valid_bars"] = n
    fc["bar_ms"] = ms
    trade_bars = min(n, EDGE_HORIZON)
    fc["edge_until"] = int((cs[0]["t"] if cs and cs[0].get("t") else fc["valid_from"]) + ms * trade_bars)
    fc["edge_bars"] = trade_bars
    fc["valid_label"] = f"پیش‌بینی {n} کندل {tf} آینده"
    return fc


def signal_timing(tf: str, last_open_ms: int | None, edge: dict | None = None) -> dict:
    """Time block of a signal: which candle it was computed on, when it becomes stale and when the levels are expected to be reached."""
    ms = TF_MS.get(tf, 3_600_000)
    if not last_open_ms:
        import time
        last_open_ms = (int(time.time() * 1000) // ms - 1) * ms
    as_of_close = int(last_open_ms) + ms                       # the moment the analysed candle closed
    bars = SIGNAL_VALID_BARS.get(tf, 4)
    out = {"tf": tf, "bar_ms": ms, "last_open": int(last_open_ms), "as_of": as_of_close, "next_close": as_of_close + ms,
           "valid_from": as_of_close, "valid_bars": bars, "valid_until": as_of_close + ms * bars}
    if edge:
        for k, key in (("tp1", "t_tp1"), ("tp2", "t_tp2"), ("tp3", "t_tp3"), ("stop", "t_stop")):
            b = edge.get(key)
            out[f"eta_{k}"] = int(as_of_close + ms * b) if b else None
        out["eta_basis"] = "میانهٔ شبیه‌سازی (مسیرهایی که به آن سطح رسیدند)"
    return out


def _last_open_ms(df) -> int | None:
    try:
        t = df["open_time"].iloc[-1]
        return int(t.timestamp() * 1000)
    except Exception:                                            # noqa: BLE001
        return None


def build_forecast(df: pd.DataFrame, side: str, tf: str, symbol: str, levels: dict | None = None,
                   n_ahead: int = FORECAST_CANDLES) -> dict:
    """forecast_summary + exact candle times + validity window. `df` must hold CLOSED candles only."""
    import time as _t
    _t0 = _t.time()
    fc = forecast_summary(df, side, n_ahead=n_ahead + 1, seed_key=f"{symbol}{tf}", levels=levels)     # +1: the candle that is forming right now
    fc = stamp_fc_times(fc, _last_open_ms(df), tf)
    if fc.get("candles"):
        cs = [dict(c, step=i, current=(i == 0)) for i, c in enumerate(fc["candles"])]
        fc["candles"] = cs
    fc["n_future"] = n_ahead
    fc = attach_validity(fc, tf, n_ahead)
    fc["timing"] = signal_timing(tf, _last_open_ms(df), fc.get("edge"))
    try:
        from app import core
        core.record("forecast", (_t.time() - _t0) * 1000, True)
    except Exception:                                            # noqa: BLE001
        pass
    return fc
