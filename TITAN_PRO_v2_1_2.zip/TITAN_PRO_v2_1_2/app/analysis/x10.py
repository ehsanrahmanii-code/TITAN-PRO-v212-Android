"""TITAN x10 — ten complementary indicators that sharpen the core engine.

None of these duplicate what the core already computes (EMA/ST/ADX/MACD/RSI/StochRSI/MFI/CMF/OBV/Ichimoku/SMC/Aroon/
TRIX/CVD/Chandelier/ER/Keltner). They answer three different questions the core cannot answer alone:

  QUALITY  - is this market even tradable by trend rules?       Hurst · Choppiness · LinReg R² · Volatility expansion
  TIMING   - is NOW a good moment to enter (not chasing)?       Connors RSI · Fisher · VWAP σ-bands · Squeeze momentum · LinReg channel position
  FLOW     - is real participation behind the move?             Klinger · Vortex

Every indicator returns {v, s (-1..+1 directional vote), t (Persian note), role}. compute() additionally returns:
  quality  0..100   (trade-ability of the current regime: used to modulate confidence and to gate auto-trading)
  timing  -100..100 (positive = good moment for a LONG entry, negative = good moment for a SHORT entry)
  entry_zone / exit_refs  (price zones from VWAP-σ and the regression channel for better entries and exits)
Everything is defensive: a failing indicator is skipped, never raised.
"""
from __future__ import annotations
import numpy as np
import pandas as pd

KEYS = ["hurst", "chop", "linreg", "vol_exp", "crsi", "fisher", "vwapz", "sqz", "klinger", "vortex"]
NAMES = {
    "hurst": "نمای هرست", "chop": "شاخص چاپی (Choppiness)", "linreg": "کانال رگرسیون خطی", "vol_exp": "انبساط نوسان (Garman-Klass)",
    "crsi": "Connors RSI", "fisher": "تبدیل فیشر", "vwapz": "باندهای σ‑VWAP", "sqz": "مومنتوم اسکوییز", "klinger": "اسیلاتور کلینگر", "vortex": "ویتکس (Vortex)",
}
ROLES = {"hurst": "quality", "chop": "quality", "linreg": "quality", "vol_exp": "quality", "crsi": "timing", "fisher": "timing",
         "vwapz": "timing", "sqz": "timing", "klinger": "flow", "vortex": "flow"}
ROLE_FA = {"quality": "کیفیت بازار", "timing": "زمان‌بندی ورود", "flow": "جریان مشارکت"}


def _c(x, a=-1.0, b=1.0) -> float:
    return float(max(a, min(b, x)))


def _f(x, nd=4):
    try:
        x = float(x)
        return round(x, nd) if np.isfinite(x) else None
    except (TypeError, ValueError):
        return None


def _ema(a: np.ndarray, n: int) -> np.ndarray:
    return pd.Series(a).ewm(span=n, adjust=False).mean().values


# ─────────────────────────────────── QUALITY ───────────────────────────────────
def hurst(close: np.ndarray, window: int = 200) -> dict:
    """Rescaled-range Hurst exponent on log-returns (0.5 random, >0.55 persistent trend, <0.45 mean-reverting)."""
    r = np.diff(np.log(close[-(window + 1):]))
    n = len(r)
    if n < 60:
        return {}
    sizes = [s for s in (8, 12, 16, 24, 32, 48, 64) if s <= n // 2]
    xs, ys = [], []
    for s in sizes:
        rs = []
        for i in range(0, n - s + 1, s):
            seg = r[i:i + s]
            sd = seg.std()
            if sd <= 0:
                continue
            z = np.cumsum(seg - seg.mean())
            rs.append((z.max() - z.min()) / sd)
        if rs:
            xs.append(np.log(s)); ys.append(np.log(np.mean(rs)))
    if len(xs) < 3:
        return {}
    h = float(np.clip(np.polyfit(xs, ys, 1)[0], 0.0, 1.0))
    mom = float(np.sign(close[-1] - close[-21]))
    if h >= 0.56:
        s, t = mom * _c((h - 0.5) * 4), f"H={h:.2f} · روند پایدار؛ دنبال‌کردن روند مجاز است"
    elif h <= 0.44:
        s, t = -mom * _c((0.5 - h) * 3), f"H={h:.2f} · بازگشت به میانگین؛ از تعقیب شکست‌ها بپرهیزید"
    else:
        s, t = 0.0, f"H={h:.2f} · رفتار تصادفی؛ لبهٔ آماری کم"
    q = float(np.clip((abs(h - 0.5) - 0.02) / 0.18, 0, 1))
    return {"v": _f(h, 3), "s": round(s, 3), "t": t, "q": q, "mode": "trend" if h >= 0.56 else "revert" if h <= 0.44 else "random"}


def choppiness(df: pd.DataFrame, n: int = 14) -> dict:
    h, l, c = df["high"].astype(float), df["low"].astype(float), df["close"].astype(float)
    tr = pd.concat([h - l, (h - c.shift()).abs(), (l - c.shift()).abs()], axis=1).max(axis=1)
    rng = h.rolling(n).max() - l.rolling(n).min()
    ci = 100 * np.log10(tr.rolling(n).sum() / rng.replace(0, np.nan)) / np.log10(n)
    v = float(ci.iloc[-1])
    if not np.isfinite(v):
        return {}
    if v >= 61.8:
        s, t, q = 0.0, f"CI={v:.0f} · بازار خرد/چاپی؛ سیگنال‌های روندی کم‌اعتبارند", 0.0
    elif v <= 38.2:
        s, t, q = float(np.sign(c.iloc[-1] - c.iloc[-n])), f"CI={v:.0f} · حرکت جهت‌دار و تمیز", 1.0
    else:
        s, t, q = 0.0, f"CI={v:.0f} · گذار بین روند و رنج", 0.55
    return {"v": _f(v, 1), "s": round(s * 0.6, 3), "t": t, "q": q}


def linreg(df: pd.DataFrame, n: int = 50) -> dict:
    """Least-squares channel over the last n closes: slope, R², ±2σ bands and where price sits inside it."""
    c = df["close"].astype(float).values
    if len(c) < n + 5:
        return {}
    y = c[-n:]
    x = np.arange(n)
    b, a = np.polyfit(x, y, 1)
    fit = a + b * x
    res = y - fit
    sd = float(res.std()) or 1e-12
    ss_tot = float(((y - y.mean()) ** 2).sum()) or 1e-12
    r2 = float(1 - (res ** 2).sum() / ss_tot)
    mid = float(fit[-1])
    z = float((y[-1] - mid) / sd)
    slope_pct = float(b / y[-1] * 100)                      # % per candle
    d = 1 if b > 0 else -1
    trend_s = d * _c(r2 * 1.2)
    # inside a good-quality channel: low half = long, high half = short continuation (pullback logic with the slope)
    pos_s = _c(-z / 2.5) * (0.5 if r2 > 0.5 else 1.0)
    s = _c(0.65 * trend_s + 0.35 * pos_s)
    t = f"شیب {slope_pct:+.3f}٪/کندل · R²={r2:.2f} · قیمت {z:+.1f}σ از میانهٔ کانال"
    return {"v": _f(r2, 3), "s": round(s, 3), "t": t, "q": float(np.clip((r2 - 0.25) / 0.6, 0, 1)), "slope_pct": _f(slope_pct, 4), "r2": _f(r2, 3),
            "z": _f(z, 2), "mid": _f(mid, 8), "upper": _f(mid + 2 * sd, 8), "lower": _f(mid - 2 * sd, 8), "sd": _f(sd, 8), "n": n}


def vol_expansion(df: pd.DataFrame) -> dict:
    """Garman-Klass volatility: short (10) vs long (60) window. Expansion confirms breakouts, contraction precedes them."""
    o, h, l, c = (df[k].astype(float).values for k in ("open", "high", "low", "close"))
    gk = 0.5 * np.log(h / l) ** 2 - (2 * np.log(2) - 1) * np.log(c / o) ** 2
    gk = pd.Series(gk).clip(lower=0)
    short, long_ = float(np.sqrt(gk.tail(10).mean())), float(np.sqrt(gk.tail(60).mean()))
    if long_ <= 0 or not np.isfinite(short):
        return {}
    ratio = short / long_
    roll = np.sqrt(gk.rolling(10).mean()).dropna().tail(120)
    pct = float((roll < short).mean() * 100) if len(roll) > 20 else 50.0
    last_dir = float(np.sign(c[-1] - c[-6]))
    if ratio >= 1.35:
        s, t, q = last_dir * _c((ratio - 1) / 1.2), f"نوسان در حال انبساط ×{ratio:.2f} · حرکت تازه معتبرتر است", 0.9
    elif ratio <= 0.7:
        s, t, q = 0.0, f"نوسان منقبض ×{ratio:.2f} · احتمال حرکت ناگهانی (جهت نامشخص)", 0.6
    else:
        s, t, q = 0.0, f"نوسان عادی ×{ratio:.2f}", 0.75
    if pct >= 95:
        q *= 0.7
        t += " · صدک نوسان بسیار بالا (ریسک)"
    return {"v": _f(ratio, 2), "s": round(s, 3), "t": t, "q": q, "pct": _f(pct, 0), "gk_pct": _f(short * 100, 3)}


# ─────────────────────────────────── TIMING ───────────────────────────────────
def connors_rsi(close: np.ndarray) -> dict:
    s = pd.Series(close)

    def rsi(x: pd.Series, n: int) -> pd.Series:
        d = x.diff()
        ag = d.clip(lower=0).ewm(alpha=1 / n, min_periods=n, adjust=False).mean()
        al = (-d.clip(upper=0)).ewm(alpha=1 / n, min_periods=n, adjust=False).mean()
        return 100 - 100 / (1 + ag / al.replace(0, np.nan))
    r3 = rsi(s, 3)
    sign = np.sign(s.diff().fillna(0)).values
    streak = np.zeros(len(s))
    for i in range(1, len(s)):
        streak[i] = (streak[i - 1] + sign[i]) if sign[i] == np.sign(streak[i - 1]) or streak[i - 1] == 0 else sign[i]
    rs = rsi(pd.Series(streak), 2)
    roc = s.pct_change()
    prank = roc.rolling(100).apply(lambda w: (w[:-1] < w[-1]).mean() * 100, raw=True)
    v = float(((r3 + rs + prank) / 3).iloc[-1])
    if not np.isfinite(v):
        return {}
    if v <= 15: sc, t = 1.0, f"CRSI={v:.0f} · اشباع فروش کوتاه‌مدت؛ زمان خوبی برای ورود خرید"
    elif v <= 30: sc, t = 0.5, f"CRSI={v:.0f} · افت کوتاه‌مدت"
    elif v >= 85: sc, t = -1.0, f"CRSI={v:.0f} · اشباع خرید کوتاه‌مدت؛ زمان خوبی برای ورود فروش"
    elif v >= 70: sc, t = -0.5, f"CRSI={v:.0f} · رشد کشیده کوتاه‌مدت"
    else: sc, t = 0.0, f"CRSI={v:.0f} · ناحیهٔ خنثی"
    return {"v": _f(v, 1), "s": sc, "t": t}


def fisher(df: pd.DataFrame, n: int = 10) -> dict:
    hl2 = ((df["high"] + df["low"]) / 2).astype(float).values
    val, f_prev, v_prev = 0.0, 0.0, 0.0
    out = []
    for i in range(len(hl2)):
        w = hl2[max(0, i - n + 1):i + 1]
        lo, hi = w.min(), w.max()
        x = 0.66 * ((hl2[i] - lo) / (hi - lo + 1e-12) - 0.5) + 0.67 * v_prev
        x = max(-0.999, min(0.999, x))
        f = 0.5 * np.log((1 + x) / (1 - x)) + 0.5 * f_prev
        out.append(f); v_prev, f_prev = x, f
    f, fp = float(out[-1]), float(out[-2])
    if f > fp and fp < -1.0: s, t = 1.0, f"Fisher={f:.2f} · چرخش صعودی از ناحیهٔ منفی عمیق"
    elif f < fp and fp > 1.0: s, t = -1.0, f"Fisher={f:.2f} · چرخش نزولی از ناحیهٔ مثبت عمیق"
    elif f > fp and f > 0: s, t = 0.4, f"Fisher={f:.2f} · شتاب صعودی"
    elif f < fp and f < 0: s, t = -0.4, f"Fisher={f:.2f} · شتاب نزولی"
    else: s, t = 0.0, f"Fisher={f:.2f}"
    return {"v": _f(f, 2), "s": s, "t": t, "prev": _f(fp, 2)}


def vwap_bands(df: pd.DataFrame, look: int = 96) -> dict:
    """Rolling VWAP with volume-weighted σ bands: price stretched beyond ±2σ is a poor place to chase and a good place to take profit."""
    d = df.tail(look)
    tp = ((d["high"] + d["low"] + d["close"]) / 3).astype(float).values
    v = d["volume"].astype(float).values
    if v.sum() <= 0:
        return {}
    vw = float((tp * v).sum() / v.sum())
    sd = float(np.sqrt((v * (tp - vw) ** 2).sum() / v.sum())) or 1e-12
    px = float(d["close"].iloc[-1])
    z = (px - vw) / sd
    if z <= -2: s, t = 1.0, f"{z:+.1f}σ زیر VWAP · قیمت ارزان (زمان خوب برای خرید)"
    elif z <= -1: s, t = 0.4, f"{z:+.1f}σ زیر VWAP"
    elif z >= 2: s, t = -1.0, f"{z:+.1f}σ بالای VWAP · قیمت کشیده (تعقیب نکنید)"
    elif z >= 1: s, t = -0.4, f"{z:+.1f}σ بالای VWAP"
    else: s, t = 0.0, f"{z:+.1f}σ نزدیک VWAP"
    return {"v": _f(z, 2), "s": s, "t": t, "vwap": _f(vw, 8), "u1": _f(vw + sd, 8), "u2": _f(vw + 2 * sd, 8), "l1": _f(vw - sd, 8), "l2": _f(vw - 2 * sd, 8), "z": _f(z, 2)}


def squeeze_momentum(df: pd.DataFrame, n: int = 20) -> dict:
    """TTM-style: Bollinger inside Keltner = squeeze; histogram = linear-regression of (close - mean(donchian mid, SMA))."""
    c, h, l = df["close"].astype(float), df["high"].astype(float), df["low"].astype(float)
    sma = c.rolling(n).mean()
    sd = c.rolling(n).std()
    tr = pd.concat([h - l, (h - c.shift()).abs(), (l - c.shift()).abs()], axis=1).max(axis=1)
    atr = tr.rolling(n).mean()
    on = bool(((sma - 2 * sd) > (sma - 1.5 * atr)).iloc[-1] and ((sma + 2 * sd) < (sma + 1.5 * atr)).iloc[-1])
    mid = ((h.rolling(n).max() + l.rolling(n).min()) / 2 + sma) / 2
    src = (c - mid).dropna().tail(n + 3)
    if len(src) < n + 3:
        return {}
    xs = np.arange(n)

    def lr_end(y):
        b, a = np.polyfit(xs, y, 1)
        return a + b * (n - 1)
    arr = src.values
    mom = np.array([lr_end(arr[i:i + n]) for i in range(len(arr) - n + 1)])
    m, mp = float(mom[-1]), float(mom[-2]) if len(mom) > 1 else float(mom[-1])
    a_ = float(atr.iloc[-1]) or 1e-12
    n_m = _c(m / (a_ * 1.5))
    rising = m > mp
    s = n_m * (1.0 if (m > 0) == rising else 0.55)
    t = ("اسکوییز فعال · " if on else "بدون اسکوییز · ") + ("مومنتوم مثبت" if m > 0 else "مومنتوم منفی") + (" و تقویت‌شونده" if (m > 0) == rising else " و ضعیف‌شونده")
    return {"v": _f(n_m, 2), "s": round(s, 3), "t": t, "on": on, "mom": _f(m, 8), "rising": bool(rising)}


# ─────────────────────────────────── FLOW ───────────────────────────────────
def klinger(df: pd.DataFrame) -> dict:
    h, l, c, v = (df[k].astype(float).values for k in ("high", "low", "close", "volume"))
    hlc = h + l + c
    trend = np.where(np.diff(hlc, prepend=hlc[0]) > 0, 1.0, -1.0)
    dm = h - l
    cm = np.zeros(len(c)); cm[0] = dm[0]
    for i in range(1, len(c)):
        cm[i] = cm[i - 1] + dm[i] if trend[i] == trend[i - 1] else dm[i - 1] + dm[i]
    vf = v * np.abs(2 * (dm / np.where(cm == 0, 1, cm) - 1)) * trend * 100
    kvo = _ema(vf, 34) - _ema(vf, 55)
    sig = _ema(kvo, 13)
    scale = float(np.abs(kvo[-100:]).mean()) or 1e-12
    k, ks = float(kvo[-1]), float(sig[-1])
    s = _c((k - ks) / (scale * 1.2)) * (1.0 if (k > 0) == (k > ks) else 0.6)
    t = ("Klinger بالای سیگنال" if k > ks else "Klinger زیر سیگنال") + (" · جریان پول مثبت" if k > 0 else " · جریان پول منفی")
    return {"v": _f(k / scale, 2), "s": round(s, 3), "t": t}


def vortex(df: pd.DataFrame, n: int = 14) -> dict:
    h, l, c = df["high"].astype(float), df["low"].astype(float), df["close"].astype(float)
    vmp = (h - l.shift()).abs()
    vmm = (l - h.shift()).abs()
    tr = pd.concat([h - l, (h - c.shift()).abs(), (l - c.shift()).abs()], axis=1).max(axis=1)
    trs = tr.rolling(n).sum()
    vip, vim = float((vmp.rolling(n).sum() / trs).iloc[-1]), float((vmm.rolling(n).sum() / trs).iloc[-1])
    if not (np.isfinite(vip) and np.isfinite(vim)):
        return {}
    pp = float((vmp.rolling(n).sum() / trs).iloc[-2]) - float((vmm.rolling(n).sum() / trs).iloc[-2])
    diff = vip - vim
    cross = (diff > 0) != (pp > 0)
    s = _c(diff * 3.2) * (1.15 if cross else 1.0)
    t = f"VI+ {vip:.2f} / VI− {vim:.2f}" + (" · تقاطع تازه" if cross else "")
    return {"v": _f(diff, 3), "s": round(_c(s), 3), "t": t, "vip": _f(vip, 3), "vim": _f(vim, 3), "cross": bool(cross)}


# ─────────────────────────────────── fusion ───────────────────────────────────
def compute(df: pd.DataFrame) -> dict:
    close = df["close"].astype(float).values
    fns = {"hurst": lambda: hurst(close), "chop": lambda: choppiness(df), "linreg": lambda: linreg(df), "vol_exp": lambda: vol_expansion(df),
           "crsi": lambda: connors_rsi(close), "fisher": lambda: fisher(df), "vwapz": lambda: vwap_bands(df), "sqz": lambda: squeeze_momentum(df),
           "klinger": lambda: klinger(df), "vortex": lambda: vortex(df)}
    items: dict[str, dict] = {}
    for k, fn in fns.items():
        try:
            r = fn()
        except Exception:                                    # noqa: BLE001 - an indicator must never break a signal
            r = {}
        if r:
            r.update(n=NAMES[k], role=ROLES[k])
            items[k] = r
    if not items:
        return {}
    qs = [items[k].get("q") for k in ("hurst", "chop", "linreg", "vol_exp") if items.get(k) and items[k].get("q") is not None]
    quality = round(float(np.mean(qs)) * 100, 1) if qs else 50.0
    tim = [items[k]["s"] for k in ("crsi", "fisher", "vwapz", "sqz") if k in items]
    lr = items.get("linreg")
    timing = float(np.mean(tim)) * 100 if tim else 0.0
    if lr and lr.get("z") is not None:                       # inside the channel: bottom = long timing, top = short timing
        timing = 0.8 * timing + 0.2 * _c(-lr["z"] / 2.2) * 100
    timing = round(max(-100.0, min(100.0, timing)), 1)
    flow_s = [items[k]["s"] for k in ("klinger", "vortex") if k in items]
    flow = round(float(np.mean(flow_s)) * 100, 1) if flow_s else 0.0
    allv = [it["s"] for it in items.values()]
    bull, bear = sum(1 for x in allv if x >= 0.25), sum(1 for x in allv if x <= -0.25)
    score = round(float(np.mean(allv)) * 100, 1)
    vz, lrz = items.get("vwapz"), items.get("linreg")
    zone, refs = {}, {}
    if vz:
        zone = {"long": [vz["l1"], vz["vwap"]], "short": [vz["vwap"], vz["u1"]], "src": "VWAP"}
        refs.update(vwap=vz["vwap"], vwap_u1=vz["u1"], vwap_u2=vz["u2"], vwap_l1=vz["l1"], vwap_l2=vz["l2"])
    if lrz:
        refs.update(lr_mid=lrz["mid"], lr_upper=lrz["upper"], lr_lower=lrz["lower"])
    label = "کیفیت بالا" if quality >= 65 else "کیفیت متوسط" if quality >= 40 else "کیفیت پایین (بازار نامناسب روند)"
    return {"items": items, "quality": quality, "quality_label": label, "timing": timing, "flow": flow, "score": score,
            "bull": bull, "bear": bear, "n": len(items), "entry_zone": zone, "exit_refs": refs,
            "timing_label": "زمان ورود خرید مناسب" if timing >= 25 else "زمان ورود فروش مناسب" if timing <= -25 else "زمان‌بندی خنثی؛ صبر یا ورود در پولبک"}
