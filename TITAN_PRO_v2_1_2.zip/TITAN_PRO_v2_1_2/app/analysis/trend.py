"""Clear per-coin trend statement for the coin-detail page.

Built ONLY from numbers the engine already computed (all timeframes, the Central Governor, the forecast and the
level map). The output states: the trend of every timeframe, the overall direction, how certain the engine is and WHY
(agreement, contradictions, data quality), the levels that confirm or cancel the view, and what to do now.
Certainty is an honest estimate from agreement and evidence — never a promise.
"""
from __future__ import annotations

from app.config import TF_WEIGHT

TF_FA = {"15m": "۱۵ دقیقه", "1h": "۱ ساعت", "4h": "۴ ساعت", "1d": "روزانه"}
LABELS = [(55, "صعودی قوی", "up2"), (20, "صعودی", "up1"), (-20, "خنثی / رنج", "flat"), (-55, "نزولی", "dn1"), (-101, "نزولی قوی", "dn2")]


def _label(ts: float) -> tuple[str, str]:
    for th, fa, k in LABELS:
        if ts > th:
            return fa, k
    return LABELS[-1][1], LABELS[-1][2]


def _fp(v) -> str:
    try:
        v = float(v)
    except (TypeError, ValueError):
        return "—"
    return f"{v:.6g}"


def tf_trend(sig: dict) -> dict:
    """Trend score in [-100, 100] for one timeframe from score + EMA structure + momentum + directional movement."""
    ind = sig.get("indicators") or {}
    px = float(sig.get("entry") or 0) or float(ind.get("ema21") or 0)
    pts = 0.0
    for k, w in (("ema21", 1.0), ("ema50", 1.0), ("ema200", 1.0)):
        e = ind.get(k)
        if e:
            pts += w if px > float(e) else -w
    if ind.get("ema9") and ind.get("ema21"):
        pts += 0.5 if float(ind["ema9"]) > float(ind["ema21"]) else -0.5
    if ind.get("ema21") and ind.get("ema50"):
        pts += 0.5 if float(ind["ema21"]) > float(ind["ema50"]) else -0.5
    macd = float(ind.get("macd_hist") or 0)
    dm = float(ind.get("pdi") or 0) - float(ind.get("mdi") or 0)
    st = float(ind.get("supertrend") or 0)
    ts = (0.45 * float(sig.get("score") or 0) / 100 + 0.30 * pts / 4 + 0.07 * (1 if macd > 0 else -1 if macd < 0 else 0)
          + 0.08 * (1 if dm > 0 else -1 if dm < 0 else 0) + 0.10 * (1 if st > 0 else -1 if st < 0 else 0)) * 100
    ts = max(-100.0, min(100.0, ts))
    fa, k = _label(ts)
    adx = float(ind.get("adx") or 0)
    power = "قوی" if adx >= 28 else "متوسط" if adx >= 18 else "ضعیف"
    return {"ts": round(ts, 1), "fa": fa, "k": k, "adx": round(adx, 1), "power": power, "pts": round(pts, 1),
            "rsi": ind.get("rsi"), "regime": sig.get("regime"), "side": sig.get("side"), "score": sig.get("score")}


def build(symbol: str, deep: dict, ticker: dict | None = None, struct: list | None = None) -> dict:
    allsig = deep.get("all_tf") or {}
    if not allsig:
        return {"ok": False, "symbol": symbol, "error": "داده کافی برای تعیین روند نیست"}
    fcs = deep.get("all_forecasts") or {}
    gov = deep.get("governor") or {}
    ptf = deep.get("primary_tf") or "1h"
    tfs, wsum, acc = [], 0.0, 0.0
    for tf in ("15m", "1h", "4h", "1d"):
        sg = allsig.get(tf)
        if not sg:
            continue
        t = tf_trend(sg)
        w = TF_WEIGHT.get(tf, 0.2)
        wsum += w
        acc += w * t["ts"]
        f = fcs.get(tf) or {}
        t.update(tf=tf, tf_fa=TF_FA.get(tf, tf), prob_up=f.get("prob_up"), move=f.get("expected_move_pct"))
        t["text"] = (f"{t['fa']} (قدرت {t['power']}، ADX {t['adx']:.0f})" + (f" · RSI {float(t['rsi']):.0f}" if t.get("rsi") is not None else "")
                     + (f" · احتمال صعود {float(f['prob_up']) * 100:.0f}٪" if f.get("prob_up") is not None else ""))
        tfs.append(t)
    overall = acc / wsum if wsum else 0.0
    fa, k = _label(overall)
    ups = sum(1 for t in tfs if t["ts"] > 20)
    dns = sum(1 for t in tfs if t["ts"] < -20)
    n = len(tfs)
    lead = max(ups, dns)
    aligned = (lead / n) if n else 0.0
    # certainty: agreement between timeframes + governor edge/confidence − contradiction − stale data
    gconf = gov.get("confidence")
    gconf = float(gconf) if isinstance(gconf, (int, float)) else None
    if gconf is not None and gconf <= 1.0:
        gconf *= 100
    contra = float(gov.get("contradiction") or 0)
    cert = 38 + 38 * aligned + min(14, abs(overall) / 7) + (0.12 * (gconf - 50) if gconf is not None else 0) - 18 * contra
    notes_ok, notes_bad = [], []
    if lead >= 3:
        notes_ok.append(f"{lead} از {n} تایم‌فریم هم‌جهت‌اند")
    elif lead == 2:
        notes_bad.append(f"فقط {lead} از {n} تایم‌فریم هم‌جهت‌اند")
    else:
        notes_bad.append("تایم‌فریم‌ها هم‌جهت نیستند")
        cert -= 8
    htf = next((t for t in tfs if t["tf"] == "1d"), None) or next((t for t in tfs if t["tf"] == "4h"), None)
    if htf and abs(overall) > 20 and (htf["ts"] > 20) != (overall > 0):
        notes_bad.append("تایم‌فریم بالاتر مخالف جهت کلی است")
        cert -= 10
    if contra >= 0.45:
        notes_bad.append(f"تضاد شواهد {contra * 100:.0f}٪")
    elif gov.get("published"):
        notes_ok.append("حاکم مرکزی سیگنال را منتشر کرده است")
    if gov.get("vetoes"):
        notes_bad.append("وتو: " + " · ".join(gov["vetoes"][:2]))
    adxs = [t["adx"] for t in tfs]
    if adxs and max(adxs) < 18:
        notes_bad.append("همهٔ تایم‌فریم‌ها بدون روند قوی‌اند (ADX پایین)")
        cert -= 6
    cert = int(max(8, min(93, round(cert))))
    stale = any((deep.get("all_tf") or {}).get(tf, {}).get("warnings") for tf in ("1h",))
    prim = allsig.get(ptf) or next(iter(allsig.values()))
    pf = fcs.get(ptf) or {}
    lv = prim.get("levels") or {}
    px = float((ticker or {}).get("price") or prim.get("entry") or 0)
    sup = sorted([float(z["p"]) for z in (lv.get("zones") or []) if z.get("kind") == "S" and float(z["p"]) < px], reverse=True)[:3]
    res = sorted([float(z["p"]) for z in (lv.get("zones") or []) if z.get("kind") == "R" and float(z["p"]) > px])[:3]
    piv = (prim.get("extras") or {}).get("pivots") or {}
    if not sup and piv:
        sup = [float(piv[k]) for k in ("s1", "s2") if piv.get(k) and float(piv[k]) < px]
    if not res and piv:
        res = [float(piv[k]) for k in ("r1", "r2") if piv.get(k) and float(piv[k]) > px]
    side = deep.get("verdict") or "WAIT"
    sg_pub = deep.get("signal") or {}
    bull = overall > 0
    if k == "flat":
        invalid = None
        trig_up, trig_dn = (res[0] if res else None), (sup[0] if sup else None)
        main = (f"بازار در محدودهٔ رنج است؛ تا خروج تاییدشده از بالای {_fp(trig_up)} یا پایین {_fp(trig_dn)} جهت‌گیری مطمئنی وجود ندارد."
                if trig_up and trig_dn else "بازار بدون جهت مشخص است؛ منتظر شکست یک سطح مهم بمان.")
        action = "فعلاً نگاه کن؛ ورود فقط بعد از شکست و تایید کندل بسته‌شده."
        alt = "اگر قیمت از محدوده خارج شود، روند جدید از همان جهت شروع می‌شود."
    else:
        invalid = (sup[0] if bull and sup else res[0] if (not bull) and res else None)
        if side in ("LONG", "SHORT") and sg_pub.get("stop"):
            invalid = float(sg_pub["stop"])
        trig_up, trig_dn = (res[0] if res else None), (sup[0] if sup else None)
        tgt = (res[:2] if bull else sup[:2])
        main = (f"روند {fa} است ({'خریداران' if bull else 'فروشندگان'} کنترل را دارند)"
                + (f"؛ اهداف نزدیک {' و '.join(_fp(v) for v in tgt)}" if tgt else "")
                + (f"؛ این دید با {'بسته‌شدن زیر' if bull else 'بسته‌شدن بالای'} {_fp(invalid)} باطل می‌شود." if invalid else "."))
        alt = (f"اگر قیمت {'زیر' if bull else 'بالای'} {_fp(invalid)} تثبیت شود، روند معکوس را جدی بگیر." if invalid else "")
        if side in ("LONG", "SHORT") and ((side == "LONG") == bull):
            action = (f"سیگنال فعال {side}: ورود {_fp(sg_pub.get('entry'))} · حدضرر {_fp(sg_pub.get('stop'))} · هدف‌ها {_fp(sg_pub.get('tp1'))} / {_fp(sg_pub.get('tp2'))}.")
        else:
            action = f"جهت روند {'صعودی' if bull else 'نزولی'} است ولی هنوز سیگنال تاییدشده‌ای منتشر نشده؛ صبر برای پولبک یا تایید حاکم."
    prob = pf.get("prob_up")
    horizon = int(pf.get("valid_bars") or len(pf.get("candles") or []) or 48)
    fc_txt = (f"پیش‌بینی {horizon} کندل {TF_FA.get(ptf, ptf)}: احتمال صعود {float(prob) * 100:.0f}٪ · حرکت میانه {float(pf.get('expected_move_pct') or 0):+.2f}٪"
              if prob is not None else "")
    headline = f"{fa} · اطمینان {cert}٪"
    return {"ok": True, "symbol": symbol, "price": px, "trend": fa, "k": k, "overall": round(overall, 1), "certainty": cert, "verdict": side,
            "headline": headline, "main": main, "alt": alt, "action": action, "forecast": fc_txt, "tfs": tfs,
            "levels": {"support": sup, "resistance": res, "invalidation": invalid, "trigger_up": trig_up, "trigger_dn": trig_dn},
            "why_sure": notes_ok, "why_not": notes_bad, "agree": {"up": ups, "down": dns, "n": n},
            "disclaimer": "اطمینان یعنی میزان هم‌سویی شواهد؛ تضمین قیمت نیست."}
