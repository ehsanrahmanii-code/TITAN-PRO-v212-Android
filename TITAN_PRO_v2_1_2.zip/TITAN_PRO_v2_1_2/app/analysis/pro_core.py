"""PRO V84 decision core — ported scoring + professional SL/TP levels.

Used by the Clean engine so signals are not AI-only: EMA/VWAP/volume/BTC/funding/OI
and multi-anchor stops from the original PRO logic.
"""
from __future__ import annotations
from typing import Any, Optional

EMA_BONUS = 3.0          # V84.1 reduced (was 5.0) — TF score already embeds trend
VWAP_BONUS = 2.0         # V84.1 reduced (was 4.0)
SCORE_ECHO_CAP = 6.0     # max total additive from EMA+VWAP+volume+funding+OI (anti double-count)


def _f(v: Any, default: float = 0.0) -> float:
    try:
        x = float(v)
        return x if x == x and abs(x) != float("inf") else default
    except (TypeError, ValueError):
        return default


def _clamp(x: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, x))


def funding_bias(funding: Any) -> tuple[float, str]:
    """funding as fraction (e.g. 0.0001) or percent."""
    fr = _f(funding, 0.0)
    # normalize if looks like percent already
    if abs(fr) > 0.05:
        fr = fr / 100.0
    if fr > 0.0003:
        return -2.5, "فاندینگ مثبت → فشار روی لانگ"
    if fr < -0.0002:
        return 2.0, "فاندینگ منفی → حمایت از لانگ"
    return 0.0, "فاندینگ خنثی"


def oi_bias(oi_delta: Any, price_chg_proxy: float) -> tuple[float, str]:
    oi = _f(oi_delta, 0.0)
    if oi > 2 and price_chg_proxy > 0.1:
        return 2.5, "رشد OI با قیمت صعودی → ورود پول"
    if oi > 2 and price_chg_proxy < -0.1:
        return -2.5, "رشد OI با قیمت نزولی → فشار شورت"
    if oi < -2 and price_chg_proxy < -0.1:
        return 1.5, "کاهش OI در نزول → احتمال تخلیه فروش"
    if oi < -2 and price_chg_proxy > 0.1:
        return -1.5, "کاهش OI در صعود → ضعف خرید"
    return 0.0, "OI بدون سیگنال قوی"


def pro_score_adjust(
    base_score: float,
    *,
    price: float,
    rsi: float,
    vwap: float,
    ema20: float,
    ema50: float,
    atr: float,
    volume_spike: bool,
    btc_trend: str = "خنثی",
    symbol: str = "",
    funding: Any = None,
    oi_delta: Any = None,
) -> dict[str, Any]:
    """Apply PRO V84.1 additive scoring on top of existing engine score.

    base_score is expected roughly in [-100,100] or [0,100]; we normalize to 0..100 work space.
    """
    # normalize incoming score to 0..100
    if base_score < 0:
        score = 50.0 + _clamp(base_score, -50, 50)
    else:
        score = _clamp(base_score, 0, 100)

    score_base = score  # for echo-cap (V84.1 honesty)
    reasons_for: list[str] = []
    reasons_against: list[str] = []
    price_change_proxy = ((price / ema20) - 1.0) * 100.0 if ema20 > 0 else 0.0

    if ema20 > ema50:
        score += EMA_BONUS
        reasons_for.append("EMA20 > EMA50")
    elif ema20 < ema50 and ema20 > 0 and ema50 > 0:
        score -= EMA_BONUS
        reasons_against.append("EMA20 < EMA50")

    if vwap > 0:
        if price > vwap:
            score += VWAP_BONUS
            reasons_for.append("قیمت بالای VWAP")
        else:
            score -= VWAP_BONUS
            reasons_against.append("قیمت زیر VWAP")

    if volume_spike:
        if price_change_proxy > 0.15:
            score += 3.0
            reasons_for.append("حجم بالا + حرکت صعودی")
        elif price_change_proxy < -0.15:
            score -= 3.0
            reasons_against.append("حجم بالا + حرکت نزولی")

    sym_u = (symbol or "").upper().replace("/", "")
    if btc_trend == "صعودی" and sym_u not in ("BTCUSDT", "BTC"):
        score += 5.0
        reasons_for.append("روند BTC صعودی")
    elif btc_trend == "نزولی" and sym_u not in ("BTCUSDT", "BTC"):
        score -= 5.0
        reasons_against.append("روند BTC نزولی")

    f_adj, f_reason = funding_bias(funding)
    score += f_adj
    if f_adj > 0:
        reasons_for.append(f_reason)
    elif f_adj < 0:
        reasons_against.append(f_reason)

    o_adj, o_reason = oi_bias(oi_delta, price_change_proxy)
    score += o_adj
    if o_adj > 0:
        reasons_for.append(o_reason)
    elif o_adj < 0:
        reasons_against.append(o_reason)

    if rsi >= 70:
        reasons_against.append("RSI اشباع خرید")
        score -= 1.5
    elif rsi <= 30:
        reasons_for.append("RSI اشباع فروش")
        score += 1.5

    score = _clamp(score, 0, 100)
    # V84.1 anti-echo: total additive from structure/flow adjustments is capped
    delta = score - score_base
    if abs(delta) > SCORE_ECHO_CAP:
        score = score_base + (SCORE_ECHO_CAP if delta > 0 else -SCORE_ECHO_CAP)
    score = _clamp(score, 0, 100)
    bias = "صعودی" if score >= 58 else "نزولی" if score <= 42 else "خنثی"
    # map back toward signed score used by Clean engine (-100..100 style around 0)
    signed = score - 50.0
    return {
        "score_0_100": score,
        "signed_score": signed,
        "bias": bias,
        "reasons_for": reasons_for[:5],
        "reasons_against": reasons_against[:5],
        "vwap_dev": ((price - vwap) / vwap * 100.0) if vwap > 0 else 0.0,
        "engine": "PRO-V84.1-core-echo-capped",
    }


def calculate_levels_pro(
    price: float,
    atr: float,
    side: str,
    *,
    swing_low: float = 0.0,
    swing_high: float = 0.0,
    vwap: float = 0.0,
    ema20: float = 0.0,
    ema50: float = 0.0,
) -> tuple[float, float, float, float]:
    """Professional multi-anchor SL / TP1 / TP2 / TP3 (PRO-style).

    Returns (stop, tp1, tp2, tp3).
    """
    price = _f(price)
    atr = max(_f(atr), price * 0.002 if price > 0 else 0.01)
    rm = 1.15
    rr1, rr2, rr3 = 1.2, 2.2, 3.4
    friction = price * 0.0004

    anchors_below = [x for x in (swing_low, vwap, ema20, ema50) if _f(x) > 0 and _f(x) < price]
    anchors_above = [x for x in (swing_high, vwap, ema20, ema50) if _f(x) > 0 and _f(x) > price]

    if side == "LONG":
        atr_sl = price - rm * atr
        swing_sl = max(anchors_below) - 0.25 * atr if anchors_below else atr_sl
        sl = min(atr_sl, swing_sl) - friction
        if sl >= price:
            sl = price - max(rm * atr, price * 0.004) - friction
        dist = max(price - sl, atr * 0.9)
        tp1 = price + rr1 * dist + friction
        tp2 = price + rr2 * dist + friction
        tp3 = price + rr3 * dist + friction
        sl = max(sl, price * 0.5)
        return float(sl), float(tp1), float(tp2), float(tp3)

    if side == "SHORT":
        atr_sl = price + rm * atr
        swing_sl = min(anchors_above) + 0.25 * atr if anchors_above else atr_sl
        sl = max(atr_sl, swing_sl) + friction
        if sl <= price:
            sl = price + max(rm * atr, price * 0.004) + friction
        dist = max(sl - price, atr * 0.9)
        tp1 = price - rr1 * dist - friction
        tp2 = price - rr2 * dist - friction
        tp3 = price - rr3 * dist - friction
        tp1 = max(tp1, price * 0.05)
        tp2 = max(min(tp1 * 0.99, tp2), price * 0.03)
        tp3 = max(min(tp2 * 0.99, tp3), price * 0.02)
        return float(sl), float(tp1), float(tp2), float(tp3)

    return 0.0, 0.0, 0.0, 0.0
