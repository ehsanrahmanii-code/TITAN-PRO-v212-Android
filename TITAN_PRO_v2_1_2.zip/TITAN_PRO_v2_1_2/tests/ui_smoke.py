"""Browser smoke test (optional, needs `pip install playwright` + chromium): starts the synthetic-data server, opens every page,
changes theme/layout options and fails on any JS error.   python tests/ui_smoke.py"""
import os, subprocess, sys, time, urllib.request
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def main() -> int:
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        print("playwright not installed — skipped"); return 0
    env = dict(os.environ, TITAN_PORT="8097")
    srv = subprocess.Popen([sys.executable, os.path.join(ROOT, "tools", "sim_server.py")], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    errs = []
    try:
        for _ in range(60):
            try:
                urllib.request.urlopen("http://127.0.0.1:8097/api/status", timeout=1); break
            except Exception:                                # noqa: BLE001
                time.sleep(0.5)
        with sync_playwright() as p:
            b = p.chromium.launch(); pg = b.new_page(viewport={"width": 1440, "height": 900})
            pg.on("pageerror", lambda e: errs.append(str(e))); pg.on("console", lambda m: errs.append(m.text) if m.type == "error" else None)
            pg.goto("http://127.0.0.1:8097/", wait_until="networkidle"); pg.wait_for_timeout(2500)
            for r in ["market", "work", "signals", "trade", "learn", "core", "style", "settings", "dash"]:
                pg.evaluate(f"TT.go('{r}')"); pg.wait_for_timeout(1500)
                assert pg.evaluate("document.querySelector('#view').innerText.length") > 200, r
            pg.evaluate("TT.go('work')"); pg.wait_for_timeout(2500); pg.click('#wk-tabs [data-t="trend"]'); pg.wait_for_timeout(500)
            assert "روند" in pg.evaluate("document.querySelector('#wk-body').innerText")
            for pr in ["synth", "pearl", "matrix", "holo", "neon"]:
                pg.evaluate(f"TT.theme.preset('{pr}')"); pg.wait_for_timeout(200)
            pg.evaluate("TT.theme.set('nav','top'); TT.theme.set('ch_style','area'); TT.theme.set('fxmode','net')"); pg.evaluate("TT.go('work')"); pg.wait_for_timeout(2500)
            assert pg.evaluate("TT.theme.count()") >= 120
            pg.set_viewport_size({"width": 360, "height": 800})          # phone: nothing may overflow the screen
            pg.evaluate("TT.theme.preset('neon')")
            for r in ["dash", "work", "trade", "core", "settings", "style", "learn"]:
                pg.evaluate(f"TT.go('{r}')"); pg.wait_for_timeout(1200)
                ov = pg.evaluate("document.querySelector('#view').scrollWidth - document.querySelector('#view').clientWidth")
                assert ov <= 1, f"horizontal overflow on {r}: {ov}px"
            b.close()
    finally:
        srv.terminate()
    print("JS errors:", errs or "none"); return 1 if errs else 0


if __name__ == "__main__":
    sys.exit(main())
